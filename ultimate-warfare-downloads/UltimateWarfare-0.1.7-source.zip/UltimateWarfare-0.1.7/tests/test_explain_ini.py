"""Opt-in line diagnostics on invented data; no game files are distributed."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from explain_ini import explain
from test_project import invented_game_files
from uwmod.archive import write_big


class ExplainIniTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.game = Path(self.temp.name) / "Game"
        self.game.mkdir()
        self.fixture = invented_game_files()
        (self.game / "generals.exe").write_bytes(b"Invented presence marker, never executed")
        (self.game / "game.dat").write_bytes(b"Invented presence marker, never executed")

    def run_fixture(self):
        archive = self.game / "INIZH.big"
        original = write_big(self.fixture)
        archive.write_bytes(original)
        report = explain(self.game)
        self.assertEqual(archive.read_bytes(), original)
        self.assertFalse(report["in_game_tested"])
        return report

    def test_object_error_exposes_only_one_escaped_source_line(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = (
            b"Object FixtureBroken\n  BuildCost = 900\n#unsupported_fixture\nEnd\n")
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["source_virtual_path"], "Data\\INI\\Object\\FixtureBroken.ini")
        self.assertEqual(line["line"], 3)
        self.assertEqual(line["ascii_escaped"], "#unsupported_fixture\n")
        self.assertEqual(bytes.fromhex(line["hex"]), b"#unsupported_fixture\n")
        self.assertNotIn("BuildCost = 900", json.dumps(report))
        self.assertEqual(report["line_detail_status"], "Exact source provenance")

    def test_legacy_control_marker_is_visible_and_line_is_clipped(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = (
            b"Object FixtureBroken\nEnd\n" + b"\x1a" + b"x" * 600 + b"\n")
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertTrue(line["ascii_escaped"].startswith("\x1a"))
        self.assertTrue(line["hex"].startswith("1a"))
        self.assertEqual(len(bytes.fromhex(line["hex"])), 512)
        self.assertTrue(line["truncated"])

    def test_monolithic_error_without_provenance_returns_candidate_source(self):
        self.fixture["Data/INI/Weapon.ini"] += b"#unsupported_fixture\n"
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["source_virtual_path"], "Data\\INI\\Weapon.ini")
        self.assertEqual(line["ascii_escaped"], "#unsupported_fixture\n")
        self.assertIn("Candidate", report["line_detail_status"])

    def test_unmatched_end_trace_shows_headers_and_keys_without_scalar_values(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = b"""Object FixtureBroken
  Behavior = FixtureUpdate FixtureTag
    ScalarText = PrivateFieldValue
    FixtureGroup = PrivateGroupArgument
      Delay = 100
    End
  End
End
"""
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["line"], 8)
        self.assertEqual(line["ascii_escaped"], "End\n")
        context = line["structure_before_error"]
        self.assertEqual(context["scope_header"]["identifier"], "FixtureBroken")
        self.assertEqual(context["module_headers"][0]["module_type"], "FixtureUpdate")
        self.assertIn("FixtureGroup", [item["keyword"] for item in context["previous_keywords"]])
        self.assertNotIn("PrivateFieldValue", json.dumps(report))
        self.assertNotIn("PrivateGroupArgument", json.dumps(report))
        self.assertEqual(report["detail_tool_version"], "1.1")
