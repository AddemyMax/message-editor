import struct
import tempfile
import unittest
from pathlib import Path

from tools.uwmod.archive import BigError, normalize_path, read_big, write_big


def raw_archive(entries, *, magic=b"BIGF", padding=b""):
    """Construct independently, avoiding the writer under test."""
    index_size = 16 + sum(8 + len(name) + 1 for name, payload in entries) + len(padding)
    size = index_size + sum(len(payload) for name, payload in entries)
    result = bytearray(struct.pack(">4sIII", magic, size, len(entries), index_size))
    offset = index_size
    for name, payload in entries:
        result.extend(struct.pack(">II", offset, len(payload)) + name + b"\0")
        offset += len(payload)
    return bytes(result) + padding + b"".join(payload for name, payload in entries)


class BigArchiveTests(unittest.TestCase):
    def test_independent_fixture_bigf_and_big4(self):
        for magic in (b"BIGF", b"BIG4"):
            blob = raw_archive([(b"Data\\INI\\Example.ini", b"Object Fixture\r\nEnd\r\n"),
                                (b"Art\\empty.w3d", b"")], magic=magic, padding=b"L224\0\0\0\0")
            parsed = read_big(blob)
            self.assertEqual(parsed.magic, magic)
            self.assertEqual(parsed.read("data/ini/EXAMPLE.ini"), b"Object Fixture\r\nEnd\r\n")
            self.assertEqual(parsed.read("Art/empty.w3d"), b"")
            self.assertEqual(len(parsed.entries), 2)

    def test_deterministic_canonical_roundtrip_and_big_endian_header(self):
        files = {"Data/INI/Z.ini": b"last", "Data/INI/A.ini": b"first"}
        result = write_big(files)
        self.assertEqual(result, write_big(dict(reversed(list(files.items())))))
        self.assertEqual(struct.unpack(">4sIII", result[:16]),
                         (b"BIGF", len(result), 2, read_big(result).index_size))
        self.assertEqual([entry.name for entry in read_big(result).entries],
                         ["Data\\INI\\A.ini", "Data\\INI\\Z.ini"])
        for name, payload in files.items():
            self.assertEqual(read_big(result).read(name), payload)

    def test_empty_archive(self):
        parsed = read_big(write_big({}))
        self.assertEqual(parsed.entries, ())
        self.assertEqual(parsed.index_size, 16)

    def test_historical_little_endian_total_size_with_big_endian_index(self):
        canonical = raw_archive([(b"Data\\INI\\Fixture.ini", b"Fixture")])
        historical = canonical[:4] + struct.pack("<I", len(canonical)) + canonical[8:]
        archive = read_big(historical)
        self.assertEqual(archive.size_byte_order, "little")
        self.assertEqual(archive.read("Data/INI/Fixture.ini"), b"Fixture")
        self.assertEqual(read_big(canonical).size_byte_order, "big")
        invalid = canonical[:4] + struct.pack("<I", len(canonical) + 1) + canonical[8:]
        with self.assertRaises(BigError):
            read_big(invalid)

    def test_path_reader_is_lazy_and_detects_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "original.big"
            path.write_bytes(raw_archive([(b"Data\\INI\\Original.ini", b"original")]))
            archive = read_big(path)
            self.assertIsNone(archive._data)
            self.assertEqual(archive.read("Data/INI/Original.ini"), b"original")
            path.write_bytes(path.read_bytes() + b"change")
            with self.assertRaisesRegex(BigError, "changed"):
                archive.read("Data/INI/Original.ini")

    def test_reject_traversal_absolute_and_ambiguous_paths(self):
        bad_names = ["../outside", "Data/../outside", "/absolute", "\\absolute", "C:/drive",
                     "Data//file", "Data/./file", "Data/file\0bad", "Data/file\nObject Evil",
                     "Data/trailing.", "Data/ trailing", "Data/name?", "данные/file"]
        for name in bad_names:
            with self.subTest(name=name), self.assertRaises(BigError):
                normalize_path(name)
        for name in (b"..\\outside", b"C:\\drive", b"Data\\\\empty", b"\\absolute"):
            with self.subTest(name=name), self.assertRaises(BigError):
                read_big(raw_archive([(name, b"payload")]))

    def test_reject_duplicate_case_insensitive_or_separator_alias(self):
        with self.assertRaises(BigError):
            write_big({"Data/INI/A.ini": b"a", "data\\ini\\a.INI": b"b"})
        with self.assertRaises(BigError):
            read_big(raw_archive([(b"A.ini", b"a"), (b"a.INI", b"b")]))

    def test_native_compatibility_duplicate_directory_entries_are_last_wins(self):
        blob = raw_archive([(b"Data\\INI\\A.ini", b"first"),
                            (b"data/ini/a.INI", b"last")])
        archive = read_big(blob, strict=False)
        self.assertEqual(len(archive.entries), 2)
        self.assertEqual(archive.read("DATA/INI/A.INI"), b"last")
        self.assertEqual(archive.duplicate_names, ("data\\ini\\a.INI",))
        # Native compatibility still rejects traversal, malformed offsets, and
        # truncated input; it is not a bypass for unbounded directory parsing.
        with self.assertRaises(BigError):
            read_big(raw_archive([(b"..\\escape", b"x")]), strict=False)
        with self.assertRaises(BigError):
            read_big(blob[:-1], strict=False)

    def test_reject_corrupt_header_index_bounds_and_overlap(self):
        valid = raw_archive([(b"one", b"abcd"), (b"two", b"efgh")])
        cases = [b"", valid[:15], b"NOT!" + valid[4:], valid[:-1],
                 valid[:8] + struct.pack(">I", 0xFFFFFFFF) + valid[12:],
                 valid[:12] + struct.pack(">I", 8) + valid[16:],
                 valid[:12] + struct.pack(">I", 0xFFFFFFFF) + valid[16:]]
        # Entry data may neither overlap the index nor exceed the file size.
        cases.append(valid[:16] + struct.pack(">I", 16) + valid[20:])
        cases.append(valid[:20] + struct.pack(">I", 0xFFFFFFFF) + valid[24:])
        # The second entry begins at offset 28 in this independently made index.
        cases.append(valid[:28] + valid[16:20] + valid[32:])
        # A name must terminate inside the index, regardless of payload bytes.
        unterminated = bytearray(raw_archive([(b"only", b"\0")]))
        unterminated[28] = ord("x")
        cases.append(bytes(unterminated))
        for blob in cases:
            with self.subTest(blob=blob[:24]), self.assertRaises(BigError):
                read_big(blob)

    def test_missing_entry_and_nonbytes_content(self):
        with self.assertRaises(KeyError):
            read_big(write_big({"A": b"a"})).read("B")
        with self.assertRaises(TypeError):
            write_big({"A": "text"})

    def test_generated_and_strict_input_paths_fit_native_engine_buffer(self):
        name = "Data\\" + "a" * 255
        with self.assertRaisesRegex(BigError, "native path buffer"):
            write_big({name: b"x"})
        original = raw_archive([(name.encode(), b"x")])
        with self.assertRaisesRegex(BigError, "native path buffer"):
            read_big(original)
        # Bounded offline indexing is still possible for original inputs.
        self.assertEqual(read_big(original, strict=False).read(name), b"x")


if __name__ == "__main__":
    unittest.main()
