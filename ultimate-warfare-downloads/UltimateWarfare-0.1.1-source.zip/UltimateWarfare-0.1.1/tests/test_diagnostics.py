"""Read-only doctor tests using invented inputs; no native game is executed."""

from contextlib import redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "tools"))

from test_project import invented_game_files
from uwmod.archive import write_big
from uwmod.diagnostics import diagnose
from uwmod.project import main


class DoctorTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.game = self.root / "PrivateInstallationPath"
        self.game.mkdir()
        self.fixture = invented_game_files()
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        # Presence markers only: deliberately neither valid nor runnable binaries.
        (self.game / "generals.exe").write_bytes(b"Invented executable presence marker")
        (self.game / "game.dat").write_bytes(b"Invented game-data presence marker")

    def snapshot(self):
        return {str(path.relative_to(self.game)): path.read_bytes()
                for path in self.game.rglob("*") if path.is_file()}

    def cli(self, *arguments):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            status = main(["doctor", *arguments])
        self.assertEqual(stderr.getvalue(), "")
        return status, json.loads(stdout.getvalue())

    def check(self, report, identifier):
        return next(item for item in report["checks"] if item["id"] == identifier)

    def assert_contract(self, report):
        self.assertEqual(report["schema_version"], 1)
        self.assertEqual(report["target_game"], "Zero Hour 1.04")
        self.assertIn(report["status"], ("passed", "failed"))
        self.assertIs(report["game_version_verified"], False)
        self.assertIs(report["in_game_tested"], False)
        self.assertEqual(report["native_runtime"], "unrun")
        self.assertIsInstance(report["source_archive_count"], int)
        self.assertIsInstance(report["units"], list)
        self.assertTrue(report["next_step"])
        for item in report["checks"]:
            self.assertEqual(set(item), {"id", "status", "message"})
            self.assertIn(item["status"], ("passed", "failed", "skipped"))
        serialized = json.dumps(report)
        self.assertNotIn(str(self.game), serialized)
        self.assertNotIn(str(self.root), serialized)
        self.assertNotIn("Original fixture label", serialized)
        self.assertNotIn("PrimaryDamage =", serialized)

    def test_positive_structural_diagnosis_preserves_inputs_and_removes_temporary_big(self):
        before = self.snapshot()
        created = []
        factory = tempfile.TemporaryDirectory

        def tracked_temporary(**kwargs):
            temporary = factory(**kwargs)
            created.append(Path(temporary.name))
            self.assertFalse(Path(temporary.name).resolve().is_relative_to(self.game.resolve()))
            return temporary

        with patch("uwmod.diagnostics.tempfile.TemporaryDirectory", side_effect=tracked_temporary):
            status, report = self.cli("--game-dir", str(self.game))
        self.assertEqual(status, 0)
        self.assertEqual(report["status"], "passed")
        self.assertTrue(all(item["status"] == "passed" for item in report["checks"]))
        self.assertEqual(report["source_archive_count"], 1)
        self.assertEqual(report["units"], [{"id": "ChinaTankUWLongma", "production_slot": 2}])
        self.assertIn("only file presence", self.check(report, "executable_presence")["message"])
        self.assertIn("not version", self.check(report, "game_data_presence")["message"])
        self.assertTrue(created)
        self.assertTrue(all(not path.exists() for path in created))
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_missing_each_binary_fails_presence_but_continues_independent_checks(self):
        for filename, identifier in (("generals.exe", "executable_presence"), ("game.dat", "game_data_presence")):
            with self.subTest(filename=filename):
                marker = self.game / filename
                original = marker.read_bytes()
                marker.unlink()
                before = self.snapshot()
                try:
                    status, report = self.cli("--game-dir", str(self.game))
                    self.assertEqual(status, 1)
                    self.assertEqual(self.check(report, identifier)["status"], "failed")
                    self.assertEqual(self.check(report, "prototype_compilation")["status"], "passed")
                    self.assertEqual(self.check(report, "generated_archive_validation")["status"], "passed")
                    self.assertEqual(self.snapshot(), before)
                    self.assert_contract(report)
                finally:
                    marker.write_bytes(original)

    def test_missing_directory_and_file_as_directory_return_json(self):
        for selected in (self.root / "MissingPrivateFolder", self.game / "game.dat"):
            with self.subTest(selected=selected):
                before = self.snapshot()
                status, report = self.cli("--game-dir", str(selected))
                self.assertEqual(status, 1)
                self.assertEqual(self.check(report, "game_directory")["status"], "failed")
                self.assertEqual(self.check(report, "source_archives")["status"], "skipped")
                self.assertEqual(report["source_archive_count"], 0)
                self.assertEqual(self.snapshot(), before)
                self.assert_contract(report)

    def test_missing_archives_fails_without_writes(self):
        (self.game / "INIZH.big").unlink()
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game))
        self.assertEqual(status, 1)
        self.assertEqual(self.check(report, "source_archives")["status"], "failed")
        self.assertIn("No native BIGF", self.check(report, "source_archives")["message"])
        self.assertEqual(self.check(report, "prototype_compilation")["status"], "skipped")
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_occupied_factory_fails_without_removing_commands(self):
        menu = b"CommandSet FixtureFactoryCommands\n" + b"".join(
            f"  {slot} = Command_Taken{slot}\n".encode() for slot in range(1, 13)
        ) + b"  13 = Command_Rally\n  14 = Command_Sell\nEnd\n"
        self.fixture["Data/INI/CommandSet.ini"] = menu
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game))
        self.assertEqual(status, 1)
        self.assertIn("no free production slot", self.check(report, "prototype_compilation")["message"])
        self.assertEqual(self.check(report, "generated_archive_validation")["status"], "skipped")
        self.assertEqual(report["units"], [])
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_loose_masks_produce_useful_failure_without_paths_or_source_text(self):
        loose = self.game / "Data/INI/Weapon.ini"
        loose.parent.mkdir(parents=True)
        loose.write_bytes(b"Private local file contents")
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game))
        self.assertEqual(status, 1)
        self.assertIn("Loose local files", self.check(report, "prototype_compilation")["message"])
        self.assertEqual(self.snapshot(), before)
        self.assertNotIn("Private local file contents", json.dumps(report))
        self.assert_contract(report)

    def test_malformed_native_big_reports_failed_index(self):
        (self.game / "INIZH.big").write_bytes(b"BIGF" + b"\0" * 12)
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game))
        self.assertEqual(status, 1)
        self.assertEqual(self.check(report, "source_archives")["status"], "failed")
        self.assertIn("malformed", self.check(report, "source_archives")["message"])
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_report_is_json_and_exclusive_outside_installation(self):
        destination = self.root / "Reports/readiness.json"
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game), "--report", str(destination))
        self.assertEqual(status, 0)
        self.assertEqual(json.loads(destination.read_text()), report)
        self.assertEqual(self.check(report, "report_output")["status"], "passed")
        original_report = destination.read_bytes()
        status, failed = self.cli("--game-dir", str(self.game), "--report", str(destination))
        self.assertEqual(status, 1)
        self.assertEqual(self.check(failed, "report_output")["status"], "failed")
        self.assertEqual(destination.read_bytes(), original_report)
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)
        self.assert_contract(failed)

    def test_report_inside_installation_refused_even_for_missing_child_directory(self):
        before = self.snapshot()
        destination = self.game / "MustNotCreate/report.json"
        status, report = self.cli("--game-dir", str(self.game), "--report", str(destination))
        self.assertEqual(status, 1)
        self.assertEqual(self.check(report, "report_output")["status"], "failed")
        self.assertFalse(destination.parent.exists())
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_unwritable_report_returns_failure_json(self):
        # A regular file cannot be used as a destination directory, on every OS.
        parent = self.root / "ExistingParentFile"
        parent.write_bytes(b"User parent file sentinel")
        before = self.snapshot()
        status, report = self.cli("--game-dir", str(self.game), "--report", str(parent / "report.json"))
        self.assertEqual(status, 1)
        self.assertEqual(self.check(report, "report_output")["status"], "failed")
        self.assertEqual(parent.read_bytes(), b"User parent file sentinel")
        self.assertEqual(self.snapshot(), before)
        self.assert_contract(report)

    def test_failed_diagnosis_can_still_be_saved_without_retaining_a_big(self):
        destination = self.root / "failed.json"
        selected = self.root / "NotInstalled"
        status, report = self.cli("--game-dir", str(selected), "--report", str(destination))
        self.assertEqual(status, 1)
        self.assertEqual(json.loads(destination.read_text()), report)
        self.assertEqual(self.check(report, "report_output")["status"], "passed")
        self.assertFalse(selected.exists())
        self.assertEqual(list(self.root.rglob("*.big")), [self.game / "INIZH.big"])
        self.assert_contract(report)

    def test_ini_and_localization_failures_never_echo_private_values(self):
        bad_inputs = (
            ("Data/INI/Weapon.ini", b"Weapon PrivateDefinition\n  PrimaryDamage = PrivateContentMarker\nEnd\n"),
            ("Data/Generals.str", b'ORIGINAL:Fixture\n"PrivateContentMarker"\n'),
        )
        for key, malformed in bad_inputs:
            with self.subTest(key=key):
                self.fixture = invented_game_files()
                self.fixture[key] = malformed
                (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
                before = self.snapshot()
                report = diagnose(self.game)
                self.assertEqual(report["status"], "failed")
                self.assertNotIn("PrivateContentMarker", json.dumps(report))
                self.assertNotIn("PrivateDefinition", json.dumps(report))
                self.assertEqual(self.snapshot(), before)
                self.assert_contract(report)


if __name__ == "__main__":
    unittest.main()
