[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$GameDir,

    [string]$Output
)

$ErrorActionPreference = 'Stop'

function Find-Python {
    foreach ($candidate in @('py', 'python', 'python3')) {
        $commands = @(Get-Command $candidate -CommandType Application -All -ErrorAction SilentlyContinue)
        foreach ($command in $commands) {
            # Windows App Execution Aliases may open the Store instead of Python.
            if ($command.Source -match '[\\/]Microsoft[\\/]WindowsApps[\\/]python(?:3(?:\.\d+)?)?\.exe$') {
                continue
            }
            $prefix = @()
            if ($candidate -eq 'py') { $prefix = @('-3') }
            try {
                $version = & $command.Source @prefix -c 'import sys; print(str(sys.version_info.major) + chr(46) + str(sys.version_info.minor)); sys.exit(0 if sys.version_info >= (3, 10) else 1)'
                $versionExitCode = $LASTEXITCODE
                if ($versionExitCode -eq 0) {
                    Write-Host "Python $version ($($command.Source))"
                    return [pscustomobject]@{ Path = $command.Source; Prefix = $prefix }
                }
            } catch {
                # Continue if a launcher has no interpreter or an executable fails.
            }
        }
    }
    throw 'Python 3.10 or newer is required. Install Python from python.org, then run this script again.'
}

try {
    if (-not (Test-Path -LiteralPath $GameDir -PathType Container)) {
        throw "Game directory does not exist: $GameDir"
    }
    $resolvedGameDir = (Resolve-Path -LiteralPath $GameDir).ProviderPath
    $projectDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
    $builder = Join-Path $projectDir 'tools\build_mod.py'
    if ([string]::IsNullOrWhiteSpace($Output)) {
        $Output = Join-Path $projectDir 'dist\UltimateWarfare.big'
    }
    $outputPath = [System.IO.Path]::GetFullPath($Output)
    $gamePrefix = $resolvedGameDir.TrimEnd([char[]]@('\', '/')) + [System.IO.Path]::DirectorySeparatorChar
    if ($outputPath.StartsWith($gamePrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'Write the mod archive outside the game installation. Original game files must remain unchanged.'
    }
    $python = Find-Python
    $pythonPath = $python.Path
    $prefix = @($python.Prefix)

    & $pythonPath @prefix $builder inspect --game-dir $resolvedGameDir
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    & $pythonPath @prefix $builder build --game-dir $resolvedGameDir --output $outputPath
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    & $pythonPath @prefix $builder validate --archive $outputPath
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    Write-Host "Mod archive: $outputPath"
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
