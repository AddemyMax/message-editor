[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$GameDir,

    [string]$Report
)

$ErrorActionPreference = 'Stop'

function Find-Python {
    foreach ($candidate in @('py', 'python', 'python3')) {
        $commands = @(Get-Command $candidate -CommandType Application -All -ErrorAction SilentlyContinue)
        foreach ($command in $commands) {
            # Windows App Execution Aliases may open the Store instead of Python.
            if ($command.Source -match '[\\/]Microsoft[\\/]WindowsApps[\\/]python(?:3(?:\.\d+)?)?\.exe$') {
                continue
            }
            $prefix = @()
            if ($candidate -eq 'py') { $prefix = @('-3') }
            try {
                $version = & $command.Source @prefix -c 'import sys; print(str(sys.version_info.major) + chr(46) + str(sys.version_info.minor)); sys.exit(0 if sys.version_info >= (3, 10) else 1)'
                $versionExitCode = $LASTEXITCODE
                if ($versionExitCode -eq 0) {
                    Write-Host "Python $version ($($command.Source))"
                    return [pscustomobject]@{ Path = $command.Source; Prefix = $prefix }
                }
            } catch {
                # Continue if a launcher has no interpreter or an executable fails.
            }
        }
    }
    throw 'Python 3.10 or newer is required. Windows Store aliases and older Python versions are skipped.'
}

try {
    $projectDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
    $builder = Join-Path $projectDir 'tools\build_mod.py'
    if (-not (Test-Path -LiteralPath $builder -PathType Leaf)) {
        throw "Project tool is missing: $builder"
    }
    if ([string]::IsNullOrWhiteSpace($Report)) {
        $Report = Join-Path $projectDir 'dist\first-run-report.json'
    }
    if (-not [System.IO.Path]::IsPathRooted($Report)) {
        $Report = Join-Path (Get-Location).ProviderPath $Report
    }
    $reportPath = [System.IO.Path]::GetFullPath($Report)
    if (Test-Path -LiteralPath $reportPath) {
        throw "Report already exists: $reportPath. Choose another -Report path; your earlier report will be preserved."
    }

    $python = Find-Python
    $pythonPath = $python.Path
    $prefix = @($python.Prefix)
    & $pythonPath @prefix $builder doctor --game-dir $GameDir --report $reportPath
    $doctorExitCode = $LASTEXITCODE
    if (Test-Path -LiteralPath $reportPath -PathType Leaf) {
        Write-Host "Diagnostic report: $reportPath"
    }
    exit $doctorExitCode
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
