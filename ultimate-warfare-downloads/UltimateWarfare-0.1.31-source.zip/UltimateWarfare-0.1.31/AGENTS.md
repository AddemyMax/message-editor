# Ultimate Warfare

This is an additive mod for the original Command & Conquer: Generals — Zero
Hour 1.04, not a browser game or replacement engine. The unrelated React
checkout at /workspace/message-editor must remain untouched for this project.

Preserve original factions, generals, buildings, economy, maps, campaigns and
Skirmish mechanics. Add units gradually. The first prototype is a single
original Chinese heavy tank, Longma, for the ordinary Chinese war factory.

Never overwrite an installed game's files. Build a separate BIGF, run the
original game with an absolute -mod path, and preserve every original command
and localization record when producing full-file overlays. Object/CommandSet
names cannot be redefined as additive startup overrides. Stop on occupied
production slots; do not remove original units to make room.

New content belongs in content/catalog.json and per-unit manifests. Artwork
must be authored here or have a documented compatible license. Do not bundle
original game binaries, stock art, private locally generated INI/locale
overlays, other mods' resources, or the external engine-reference checkout in
the distributable source kit.

Use Python 3.10+ standard-library tools for the builder. Blender is optional
for inspecting/editing/rendering the supplied source model; local mod builds
use retained generated assets and do not require Blender.

Run python3 -m unittest discover -s tests -v and
python3 tools/assets/validate_w3d.py after relevant changes. Test fixtures are
authored synthetic data: passing them does not establish native game loading.
Document native tests as unrun unless Windows Zero Hour actually executed the
test. In-game Skirmish, movement/turret/fire/death, AI/campaign regression,
save/load and frame-time checks are required before claiming a working release.
