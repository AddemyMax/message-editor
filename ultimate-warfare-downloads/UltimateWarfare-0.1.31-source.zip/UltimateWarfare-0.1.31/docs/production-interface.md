# Production interface investigation

The user's 0.1.7 diagnostic confirms that ordinary ChinaWarFactory uses
ChinaWarFactoryCommandSet, with every slot 1..14 occupied. Slots 6, 8 and 12
are Chain Guns, Black Napalm and Mines; 13/14 are rally and sell. The builder
must continue refusing to replace these commands.

The native engine's ControlBar.cpp command-set parser supports slots 1..18.
Its initialization looks up ControlBar.wnd:ButtonCommand01 through 18 under
the command context. Rendering code skips missing window controls. Therefore
adding slot 15 alone does not establish a visible, usable production button.

The next investigation is to inspect the installed ControlBar.wnd window names
and geometry with explain_ini.py 1.3. This diagnostic copies no callbacks,
textures, localized text or complete window blocks. Game inputs stay read-only.

If an extended panel is implemented, it must preserve every existing command,
keep rally/sell in place, reject occupied additional slots, and include a
matching usable window control. Full original UI overlays would be generated
privately from local inputs, never distributed in the source kit. Slot 15 is allowed only alongside this matching UI overlay.

Native tests remain required for overlapping controls, resolution scaling,
ordinary and general-specific factions, selection changes, production queues,
Skirmish, campaigns and save/load. Version 0.1.8 implements a conservative compact grid: production buttons
1..12 narrow to 42 design pixels with 47-pixel column spacing; new slot 15
occupies (505,494)-(547,538). Rally/sell stay unchanged. Other layouts fail
closed. The original control bar is read locally and overlaid privately.
Rendering and native interaction remain unverified.
