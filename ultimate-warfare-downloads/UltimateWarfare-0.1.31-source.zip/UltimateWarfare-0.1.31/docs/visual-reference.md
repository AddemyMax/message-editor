# Private source-art comparison

The user's 0.1.17 gameplay photo confirms that player colors now work and the
surface revision is closer, but shows a remaining gap: original tanks have
denser, more varied painted mechanical details, stronger local highlights and
recesses, and distinctive gun/track treatment. Another arbitrary palette shift
does not establish a visual match.

`tools/inspect_stock_art.py` reads the installed ordinary Battlemaster and
Overlord definitions, resolves their first referenced W3D models, collects
texture filenames, and writes PNG previews plus `stock-visual-details.json`.
It supports raw/RLE RGB TGA and DXT1/3/5 or raw RGB DDS using the standard
library. Unsupported inputs are reported; no invented textures are substituted.

```powershell
py -3 .\tools\inspect_stock_art.py --game-dir "<installed Zero Hour folder>"
explorer .\dist\stock-visual-reference
```

Outputs are private copies of the user's original game artwork, not mod-owned
assets. They stay under excluded `dist/` and must not be copied to the public
download branch or source ZIP. Do not request complete game archives or
executables. The tool never runs a game binary or writes into the installation;
existing output folders are preserved. Choose a new `--output` directory to
repeat extraction.

The purpose is to inspect the actual source palette, atlas layout and density
before planning part-specific UVs or locally reusing stock artwork. The native
game's material and lighting still affect appearance; extracted diffuse PNGs
alone are not in-game screenshots. There is no new visual release yet.
