# First native crash: Longma production completion

The user launched 0.1.13 and reached tank production. On completion, the game
raised an access violation during GameEngine::update. Movement, turret/fire,
death, save/load, campaign/AI and performance checks remain unrun.

The supplied crash report identifies EIP 0x007A41FA, with REP MOVSD (F3 A5).
Thyme's published Zero Hour address table maps Render_Mesh_Volume at
0x007A41A0 and the next shadow routine at 0x007A43D0. This is supporting
evidence, not symbol verification of the user's exact executable.

Registers are consistent with a shadow vertex-buffer overflow:

- EAX 0x244E0000, failing destination EDI 0x244EC000: difference 49,152
  bytes, exactly 4096 vertices of 12 bytes.
- EDX 0xF0F0: 61,680 bytes, or 5140 such vertices.
- Remaining ECX 0xC3C: 3132 doublewords = 12,528 bytes;
  61,680 minus 49,152 is also 12,528.

EA's W3DVolumetricShadow.cpp declares SHADOW_VERTEX_SIZE=4096 and
SHADOW_INDEX_SIZE=8192, then copies the generated volume geometry into the
dynamic buffer. The source object's SHADOW_VOLUME setting had been explicitly
applied to Longma's detailed mesh by this builder.

Version 0.1.14 changes only Longma to SHADOW_DECAL, using the engine's standard
`shadow` texture with dimensions 30 by 16 world units. It avoids generating
a stencil volume from the detailed model. Original units and global shadow
settings retain their original configuration. Decal shadows are a visual
compromise; a dedicated low-complexity caster can be investigated later.

Automated checks verify original input preservation and replacement of only
the new object's shadow fields. The fix requires a fresh native build and
production test; resolving this crash is not yet confirmed.

References used read-only; no reference implementation is bundled:

- EA source commit 0a05454d8574207440a5fb15241b98ad0b435590,
  GeneralsMD/Code/GameEngineDevice/Source/W3DDevice/GameClient/Shadow/W3DVolumetricShadow.cpp.
- Thyme source commit ccef1e11c1355c6db577a057c06e7d790f1a0333,
  src/hooker/setuphooks_zh.cpp (address table only).
