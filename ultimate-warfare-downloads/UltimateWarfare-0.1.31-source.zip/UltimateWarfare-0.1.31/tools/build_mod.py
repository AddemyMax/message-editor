#!/usr/bin/env python3
"""Build an isolated Zero Hour BIG from the owner's installed game data."""
from uwmod.project import main

if __name__ == "__main__":
    raise SystemExit(main())
