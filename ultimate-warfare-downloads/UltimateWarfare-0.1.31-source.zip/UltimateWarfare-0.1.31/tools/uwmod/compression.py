"""Bounded decoding of EA payloads, without changing the BIG transport.

The Zero Hour CompressionManager recognizes an eight-byte wrapper: a four-byte
codec name and a little-endian decoded length. EAR contains a RefPack stream;
ZL1 through ZL9 contain zlib streams. Standalone RefPack headers are accepted for
locally exported data too. The engine's generic BIG reader does not itself
decompress entries, and generated mod files should remain uncompressed.

Format references, independently implemented here:
EA's CompressionManager.cpp:103-134,166-188,282-349 and
EAC/refdecode.cpp:35-68,73-182 at commit
0a05454d8574207440a5fb15241b98ad0b435590.
"""

from __future__ import annotations

import struct
import zlib


class CompressionError(ValueError):
    """A compressed payload is damaged, too large, or uses another codec."""


# This tooling reads INI and localization data, rather than large map/art blobs.
MAX_DECODED_SIZE = 64 * 1024 * 1024
_REFPACK_TYPES = (0x10, 0x11, 0x90, 0x91)
_ZLIB_SIGNATURES = tuple(f"ZL{level}\0".encode("ascii") for level in range(1, 10))
_UNSUPPORTED = {b"EAB\0": "BTree", b"EAH\0": "Huffman", b"NOX\0": "NOX LZH"}


def _check_size(size: int) -> None:
    if size > MAX_DECODED_SIZE:
        raise CompressionError("Decoded payload exceeds the 64 MiB text-data limit")


def _refpack(data: bytes, expected_size: int | None = None) -> bytes:
    if len(data) < 2 or data[0] not in _REFPACK_TYPES or data[1] != 0xFB:
        raise CompressionError("Invalid RefPack stream header")
    width = 4 if data[0] & 0x80 else 3
    position = 2 + (width if data[0] & 1 else 0)
    if len(data) < position + width:
        raise CompressionError("Truncated RefPack length header")
    size = int.from_bytes(data[position:position + width], "big")
    position += width
    _check_size(size)
    if expected_size is not None and size != expected_size:
        raise CompressionError("EAR wrapper and RefPack decoded lengths disagree")
    output = bytearray()

    def take(count: int) -> bytes:
        nonlocal position
        if position + count > len(data):
            raise CompressionError("Truncated RefPack command or literal data")
        value = data[position:position + count]
        position += count
        return value

    def literals(count: int) -> None:
        if len(output) + count > size:
            raise CompressionError("RefPack literals exceed the declared decoded length")
        output.extend(take(count))

    def reference(distance: int, count: int) -> None:
        if distance > len(output):
            raise CompressionError("RefPack reference points before the decoded data")
        if len(output) + count > size:
            raise CompressionError("RefPack reference exceeds the declared decoded length")
        # References can overlap: their source repeats with period `distance`.
        start = len(output) - distance
        pattern = output[start:start + min(distance, count)]
        repetitions, remainder = divmod(count, len(pattern))
        output.extend(pattern * repetitions + pattern[:remainder])

    while True:
        first = take(1)[0]
        if first < 0x80:
            second = take(1)[0]
            literals(first & 3)
            reference(((first & 0x60) << 3) + second + 1,
                      ((first >> 2) & 7) + 3)
        elif first < 0xC0:
            second, third = take(2)
            literals(second >> 6)
            reference(((second & 0x3F) << 8) + third + 1,
                      (first & 0x3F) + 4)
        elif first < 0xE0:
            second, third, fourth = take(3)
            literals(first & 3)
            reference(((first & 0x10) << 12) + (second << 8) + third + 1,
                      ((first & 0x0C) << 6) + fourth + 5)
        elif first < 0xFC:
            literals(((first & 0x1F) + 1) * 4)
        else:
            literals(first & 3)
            if len(output) != size:
                raise CompressionError("RefPack decoded length differs from its header")
            if position != len(data):
                raise CompressionError("Trailing bytes after RefPack end marker")
            return bytes(output)


def _zlib(data: bytes, expected_size: int) -> bytes:
    decoder = zlib.decompressobj()
    try:
        output = decoder.decompress(data, expected_size + 1)
    except zlib.error as exc:
        raise CompressionError("Invalid EA zlib payload") from exc
    if len(output) > expected_size:
        raise CompressionError("EA zlib output exceeds its declared decoded length")
    if not decoder.eof:
        raise CompressionError("Truncated EA zlib stream")
    if decoder.unused_data or decoder.unconsumed_tail:
        raise CompressionError("Trailing bytes after EA zlib stream")
    if len(output) != expected_size:
        raise CompressionError("EA zlib decoded length differs from its header")
    return output


def decode_payload(data: bytes) -> bytes:
    """Return ordinary bytes unchanged, or strictly decode a known EA payload.

    Unsupported engine codecs are rejected explicitly, so they cannot be
    mistaken for text. No filesystem access or third-party packages are used.
    """
    if not isinstance(data, bytes):
        raise TypeError("Payload must be bytes")
    signature = data[:4]
    known = signature == b"EAR\0" or signature in _ZLIB_SIGNATURES or signature in _UNSUPPORTED
    if known:
        if len(data) < 8:
            raise CompressionError("Truncated EA compression wrapper")
        size = struct.unpack_from("<I", data, 4)[0]
        _check_size(size)
        if signature in _UNSUPPORTED:
            raise CompressionError(f"Unsupported EA {_UNSUPPORTED[signature]} compression; "
                                   "export this source file uncompressed")
        if signature == b"EAR\0":
            return _refpack(data[8:], size)
        return _zlib(data[8:], size)
    if len(data) >= 2 and data[0] in _REFPACK_TYPES and data[1] == 0xFB:
        return _refpack(data)
    return data
