"""Append authored labels to a user's complete Generals localization source.

The original engine chooses Data/Generals.str OR a language's Generals.csf;
it does not merge a small STR with the original CSF. These helpers therefore
preserve the complete source. They contain no original game text.

Format reference: EA GeneralsMD/Code/GameEngine/Source/GameClient/GameText.cpp
(CSF constants/header: 80-123; reader: 865-1023; STR reader: 1031-1125).
"""

from __future__ import annotations

import struct
from typing import Mapping


class LocalizationError(ValueError):
    """A localization container cannot be patched safely."""


_HEADER = struct.Struct("<4s5I")
_UINT = struct.Struct("<I")
_MAX_INT = 0x7FFFFFFF
_MAX_LABEL_BYTES = 10239
_MAX_TEXT_UNITS = 20479
_MAX_STR_LINE = 10239


def _label_bytes(label: str) -> bytes:
    if not isinstance(label, str) or not label:
        raise LocalizationError("Localization labels must be nonempty strings")
    try:
        encoded = label.encode("ascii")
    except UnicodeEncodeError as exc:
        raise LocalizationError("Localization labels must be ASCII") from exc
    if len(encoded) > _MAX_LABEL_BYTES or any(char < 33 or char > 126 for char in encoded):
        raise LocalizationError("Localization labels must be short printable ASCII without whitespace")
    if label.lower() == "end" or label.startswith(('"', "//")):
        raise LocalizationError("Localization label conflicts with STR syntax")
    return encoded


def _new_labels(labels: Mapping[str, str], existing: set[str]) -> list[tuple[bytes, str]]:
    prepared = []
    seen = set(existing)
    for label, text in labels.items():
        encoded = _label_bytes(label)
        key = label.lower()
        if key in seen:
            raise LocalizationError("Duplicate case-insensitive localization label: " + label)
        if not isinstance(text, str):
            raise LocalizationError("Localization text must be a string")
        if "\x00" in text or "\uffff" in text:
            raise LocalizationError("Localization text cannot contain NUL or U+FFFF")
        seen.add(key)
        prepared.append((encoded, text))
    return sorted(prepared, key=lambda item: (item[0].lower(), item[0]))


def _inspect_csf(data: bytes) -> tuple[tuple, set[str]]:
    if not isinstance(data, bytes):
        raise TypeError("CSF source must be bytes")
    if len(data) < _HEADER.size:
        raise LocalizationError("Truncated CSF header")
    header = _HEADER.unpack_from(data)
    magic, version, label_count, string_count, _, _ = header
    if magic != b" FSC" or version not in (2, 3):
        raise LocalizationError("Only little-endian Generals CSF versions 2 and 3 are supported")
    if label_count > _MAX_INT:
        raise LocalizationError("Invalid CSF counts")
    if label_count > (len(data) - _HEADER.size) // 12:
        raise LocalizationError("CSF label count cannot fit inside the container")

    cursor = _HEADER.size
    labels = set()
    parsed_strings = 0

    def take(size: int) -> bytes:
        nonlocal cursor
        if size > len(data) - cursor:
            raise LocalizationError("Truncated CSF record")
        value = data[cursor:cursor + size]
        cursor += size
        return value

    def uint() -> int:
        return _UINT.unpack(take(_UINT.size))[0]

    for _ in range(label_count):
        if take(4) != b" LBL":
            raise LocalizationError("Invalid CSF label chunk")
        pair_count = uint()
        label_length = uint()
        if not 0 < label_length <= _MAX_LABEL_BYTES:
            raise LocalizationError("Invalid CSF label length")
        raw_label = take(label_length)
        if b"\x00" in raw_label:
            raise LocalizationError("CSF label contains an original-reader terminator")
        # EA reads label bytes directly into Char[]; it does not perform an
        # ASCII decode. Keep legacy/localized identifiers opaque and preserve
        # their bytes. Latin-1 here is reversible bookkeeping, not a guess at
        # the installation's text encoding. Fold only ASCII bytes so legacy
        # high bytes cannot be conflated by Unicode lowercasing.
        label = raw_label.lower().decode("latin-1")
        # Native parseCSF retains repeated source records. This set is only
        # an index to prevent new labels from colliding; never deduplicate or
        # rewrite the original record sequence.
        labels.add(label)
        # Native parseCSF reads each label's pair count, not the aggregate
        # num_strings header field. Bound loops by physical record bytes.
        if pair_count > (len(data) - cursor) // 8:
            raise LocalizationError("CSF string-pair count cannot fit inside the container")
        for _ in range(pair_count):
            tag = take(4)
            if tag not in (b" RTS", b"WRTS"):
                raise LocalizationError("Invalid CSF string chunk")
            unit_count = uint()
            if unit_count > _MAX_TEXT_UNITS:
                raise LocalizationError("CSF text exceeds the original reader's buffer")
            obfuscated = take(unit_count * 2)
            plain = bytes(byte ^ 0xFF for byte in obfuscated)
            try:
                decoded = plain.decode("utf-16-le")
            except UnicodeDecodeError as exc:
                raise LocalizationError("Invalid CSF UTF-16 text") from exc
            if "\x00" in decoded or "\uffff" in decoded:
                raise LocalizationError("CSF text contains an original-reader terminator")
            if tag == b"WRTS":
                extra_length = uint()
                if extra_length > _MAX_LABEL_BYTES:
                    raise LocalizationError("CSF speech data exceeds the original reader's buffer")
                take(extra_length)
            parsed_strings += 1
    if cursor != len(data):
        raise LocalizationError("Trailing CSF bytes or incorrect label count")
    # New overlays carry the observed aggregate count. Source record bytes
    # and the allocation-relevant label count are never repaired or changed.
    observed_header = (*header[:3], parsed_strings, *header[4:])
    return observed_header, labels


def append_labels(data: bytes, labels: Mapping[str, str]) -> bytes:
    """Append unique CSF labels, keeping all original records byte-for-byte.

    Existing duplicate labels, multiple string pairs and STRW speech data are retained. Text is
    UTF-16LE with each stored byte complemented; length counts code units.
    Only the two header count fields change. Language/version/skip are kept.
    """
    header, existing = _inspect_csf(data)
    prepared = _new_labels(labels, existing)
    additions = []
    for label, text in prepared:
        try:
            plain = text.encode("utf-16-le")
        except UnicodeEncodeError as exc:
            raise LocalizationError("Localization text must contain valid Unicode") from exc
        unit_count = len(plain) // 2
        if unit_count > _MAX_TEXT_UNITS:
            raise LocalizationError("CSF text exceeds the original reader's buffer")
        additions.append(
            b" LBL" + _UINT.pack(1) + _UINT.pack(len(label)) + label
            + b" RTS" + _UINT.pack(unit_count) + bytes(byte ^ 0xFF for byte in plain)
        )
    if not additions:
        return data
    magic, version, label_count, string_count, reserved, language = header
    label_count += len(additions)
    string_count += len(additions)
    if label_count > _MAX_INT or string_count > _MAX_INT:
        raise LocalizationError("Appended CSF counts exceed the original reader's limits")
    return (
        _HEADER.pack(magic, version, label_count, string_count, reserved, language)
        + data[_HEADER.size:] + b"".join(additions)
    )


def _inspect_str(data: bytes) -> set[str]:
    if not isinstance(data, bytes):
        raise TypeError("STR source must be bytes")
    if data.startswith((b"\xef\xbb\xbf", b"\xff\xfe", b"\xfe\xff")) or b"\x00" in data:
        raise LocalizationError("STR must be a byte-oriented source without BOM or NUL")
    if any(len(line.rstrip(b"\r")) > _MAX_STR_LINE for line in data.split(b"\n")):
        raise LocalizationError("STR line exceeds the original reader's buffer")
    text = data.decode("latin-1")
    cursor = 0
    labels = set()

    def line() -> tuple[int, str]:
        nonlocal cursor
        start = cursor
        end = text.find("\n", cursor)
        if end < 0:
            cursor = len(text)
        else:
            cursor = end + 1
        return start, text[start:cursor].strip(" \r\n\t\v\f")

    while cursor < len(text):
        _, label = line()
        if not label or label.startswith("//"):
            continue
        _label_bytes(label)
        if label.lower() in labels:
            raise LocalizationError("Duplicate case-insensitive STR label: " + label)
        labels.add(label.lower())
        read_value = False
        closed = False
        while cursor < len(text):
            start, value = line()
            if not value or value.startswith("//"):
                continue
            if value.lower() == "end":
                closed = True
                break
            if not value.startswith('"'):
                raise LocalizationError("Unexpected line inside STR label: " + label)
            if read_value:
                raise LocalizationError("Multiple STR values for label: " + label)
            position = start + text[start:cursor].find('"') + 1
            escaped = False
            while position < len(text):
                char = text[position]
                if char == '"' and not escaped:
                    break
                if char == "\\":
                    escaped = not escaped
                else:
                    escaped = False
                position += 1
            else:
                raise LocalizationError("Unterminated STR quoted text: " + label)
            if position - start > _MAX_STR_LINE:
                raise LocalizationError("STR quoted text exceeds the original reader's buffer")
            end = text.find("\n", position)
            cursor = len(text) if end < 0 else end + 1
            read_value = True
        if not closed or not read_value:
            raise LocalizationError("STR label lacks a quoted value or END: " + label)
    return labels


def append_str_labels(data: bytes, labels: Mapping[str, str]) -> bytes:
    """Append to a complete original STR source without rewriting any bytes.

    The original STR reader maps bytes directly to Unicode U+0000..U+00FF;
    UTF-8 and Unicode escape sequences are unsupported. New text must fit this
    byte encoding. Use CSF for Cyrillic and other Unicode scripts.
    """
    existing = _inspect_str(data)
    prepared = _new_labels(labels, existing)
    if not prepared:
        return data
    newline = b"\r\n" if b"\r\n" in data else b"\n"
    additions = []
    for label, text in prepared:
        if any((ord(char) < 32 and char not in "\n\t") or ord(char) in (127, 255) for char in text):
            raise LocalizationError("STR text contains an unsupported control or EOF byte")
        quoted = text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
        try:
            encoded = quoted.encode("latin-1")
        except UnicodeEncodeError as exc:
            raise LocalizationError("Original STR supports Latin-1 text only; use a complete CSF for Unicode") from exc
        if len(encoded) + 2 > _MAX_STR_LINE:
            raise LocalizationError("STR text exceeds the original reader's buffer")
        additions.append(newline.join((label, b'"' + encoded + b'"', b"END")) + newline)
    separator = b"" if not data or data.endswith(b"\n") else newline
    return data + separator + newline + newline.join(additions)
