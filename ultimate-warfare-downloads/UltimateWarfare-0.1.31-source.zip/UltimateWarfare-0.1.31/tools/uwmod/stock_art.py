"""Assemble a private Longma atlas from the owner's original game artwork.

Only crop coordinates and code are distributed. No original texture data.
"""
from pathlib import Path
import hashlib
import json
import struct
import re
from functools import lru_cache

from .texture_io import decode_dds, decode_tga


def shared_roots(game_dir):
    parent = game_dir.resolve().parent
    candidates = [parent]
    if parent != parent.parent:
        candidates += [path for path in parent.iterdir()
                       if path.is_dir() and not path.is_symlink() and 'general' in path.name.lower()]
    result = []
    for path in candidates:
        if path == game_dir.resolve() or path in result:
            continue
        names = {entry.name.lower() for entry in path.iterdir() if entry.is_file()}
        if names & {'textures.big','w3d.big','texturesenglish.big'} or (path/'Art/Textures').is_dir():
            result.append(path)
    return result


def read_inputs(source, recipe):
    from .project import GameSource, _inside
    roots = [source.game_dir] + shared_roots(source.game_dir)
    sources = [source]
    for root in roots[1:]:
        if any(path.suffix.lower()=='.big' for path in root.iterdir() if path.is_file()):
            sources.append(GameSource(root))
    result, dependencies = {}, []
    for name,candidates in recipe['sources'].items():
        if not candidates or not all(isinstance(path,str) and re.fullmatch(r'Art\\Textures\\[A-Za-z0-9_.-]+\.(?:dds|tga)',path,re.I) for path in candidates):
            raise ValueError('Invalid stock texture source path')
        found = None
        for root in roots:
            for virtual in candidates:
                path = root.joinpath(*virtual.split('\\'))
                if path.is_file() and _inside(path,root) and not path.is_symlink():
                    if path.stat().st_size > 32*1024*1024:
                        raise ValueError('Stock texture exceeds supported size')
                    found = (path.read_bytes(),root,virtual,'loose')
                    break
            if found:
                break
        if not found:
            for selected in sources:
                for virtual in candidates:
                    if virtual.lower() in selected.entries:
                        found = (selected.read(virtual),selected.game_dir,virtual,'archive')
                        break
                if found:
                    break
        if not found:
            raise ValueError('Required original texture unavailable in Zero Hour or nearby Generals: '+name)
        data,root,virtual,kind = found
        result[name] = decode_dds(data) if data[:4]==b'DDS ' else decode_tga(data)
        dependencies.append({'name':name,'candidates':candidates,'root':str(root),'virtual_path':virtual,'kind':kind,
                             'sha256':hashlib.sha256(data).hexdigest()})
    return result,dependencies


def assemble_atlas(fallback, recipe, originals):
    packed = tuple((key,*value) for key,value in sorted(originals.items()))
    return _assemble_cached(fallback,json.dumps(recipe,sort_keys=True),packed)


@lru_cache(maxsize=8)
def _assemble_cached(fallback,recipe_json,packed):
    recipe = json.loads(recipe_json)
    originals = {key:(w,h,data) for key,w,h,data in packed}
    width,height,rgb = decode_tga(fallback)
    if (width,height) != (512,512):
        raise ValueError('Longma atlas must be 512 by 512')
    # Work in top-left RGB, then write the original bottom-left TGA format.
    output = bytearray(rgb)
    seen = set()
    for item in recipe['tiles']:
        tile = item['tile']
        if type(tile) is not int or tile not in range(16) or tile in seen or tile in (8,9,10):
            raise ValueError('Invalid or duplicate stock atlas tile')
        seen.add(tile)
        w,h,pixels = originals[item['source']]
        ref = recipe['reference_size'] if item['source'] != 'treads' else 32
        x0,y0,x1,y1 = item['rect']
        x0,x1 = round(x0*w/ref),round(x1*w/ref)
        y0,y1 = round(y0*h/ref),round(y1*h/ref)
        if not 0<=x0<x1<=w or not 0<=y0<y1<=h:
            raise ValueError('Stock crop exceeds image bounds')
        repeat_x,repeat_y = item.get('repeat',[1,1])
        if not all(type(n) is int and 1<=n<=8 for n in (repeat_x,repeat_y)):
            raise ValueError('Invalid texture repetition')
        for py in range(128):
            for px in range(128):
                u,v = ((px+.5)*repeat_x/128)%1,((py+.5)*repeat_y/128)%1
                if item.get('rotate'):
                    u,v = v,1-u
                sx = min(x1-1,x0+int(u*(x1-x0)))
                sy = min(y1-1,y0+int(v*(y1-y0)))
                src = (sy*w+sx)*3
                # UV tile row 0 is at the bottom of the atlas.
                dst = ((3-tile//4)*128+py)*512*3+(tile%4*128+px)*3
                output[dst:dst+3] = pixels[src:src+3]
    payload = bytearray()
    for y in reversed(range(512)):
        for x in range(512):
            p = (y*512+x)*3
            payload.extend(reversed(output[p:p+3]))
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,512,512,24,0)+payload


def build_atlas(source, project, fallback):
    recipe_path = project/'content/textures/longma-stock.json'
    recipe = json.loads(recipe_path.read_text(encoding='utf-8'))
    originals,deps = read_inputs(source,recipe)
    return assemble_atlas(fallback,recipe,originals),deps


@lru_cache(maxsize=8)
def render_cameo(atlas):
    from assets.generate_longma import tank, cameo_tga
    return cameo_tga(tank(),atlas)


def verify_dependencies(source, records):
    recipe = {'sources':{record['name']:record['candidates'] for record in records}}
    if len(recipe['sources']) != len(records):
        raise ValueError('Duplicate stock source in build manifest')
    _, current = read_inputs(source,recipe)
    if current != records:
        raise ValueError('Original stock artwork changed or is masked since build; rebuild')
