"""Bounded, read-only EA BIGF/BIG4 access and deterministic BIG writing.

Virtual names use the game's backslash convention. Nothing is extracted to a
filesystem, and readers never mutate the original game archive.
"""

from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import struct
from typing import Mapping


class BigError(ValueError):
    """An archive or virtual path is invalid or unsupported."""


_HEADER = struct.Struct(">4sIII")
_ENTRY = struct.Struct(">II")
_MAX_UINT32 = 0xFFFFFFFF
_MAX_INDEX = 64 * 1024 * 1024
_MAX_NAME = 4096
_MAX_GAME_NAME = 259  # EA BIG reader uses a 260-byte _MAX_PATH buffer, incl NUL.


def normalize_path(name: str, *, allow_windows_special: bool = False) -> str:
    """Canonicalize an ASCII virtual name, with strict generated-name rules.

    Native archives may contain Windows-special characters in their virtual
    names. Those entries stay in the read-only VFS and are never extracted.
    """
    if not isinstance(name, str) or not name:
        raise BigError("Archive path must be a nonempty string")
    try:
        encoded = name.encode("ascii")
    except UnicodeEncodeError as exc:
        raise BigError("Archive paths must be ASCII") from exc
    if len(encoded) > _MAX_NAME:
        raise BigError("Archive path is too long")
    if any(c < 32 or c >= 127 for c in encoded):
        raise BigError("Archive paths cannot contain control characters")
    canonical = name.replace("/", "\\")
    if not allow_windows_special and any(char in canonical for char in ':*?"<>|'):
        raise BigError("Archive path contains invalid Windows path characters")
    if len(canonical) >= 2 and canonical[0].isalpha() and canonical[1] == ":":
        raise BigError("Archive path must not contain a drive prefix")
    parts = canonical.split("\\")
    if any(part in ("", ".", "..") or part != part.strip() or part.endswith(".") for part in parts):
        raise BigError("Archive path must be relative without empty/traversal segments")
    return canonical


@dataclass(frozen=True)
class BigEntry:
    name: str
    offset: int
    size: int


def _entry_in_bounds(entry: BigEntry, physical_size: int, index_size: int) -> bool:
    return index_size <= entry.offset <= physical_size and 0 <= entry.size <= physical_size - entry.offset


def _validate_entry_data(entry: BigEntry, physical_size: int, index_size: int) -> None:
    if not _entry_in_bounds(entry, physical_size, index_size):
        error = BigError("BIG entry points outside the data region: " + entry.name)
        error.entry_details = {"entry_name": entry.name, "entry_offset": entry.offset,
                               "entry_size": entry.size, "entry_end": entry.offset + entry.size,
                               "directory_end": index_size}
        raise error


@dataclass(frozen=True)
class BigArchive:
    magic: bytes
    size: int
    index_size: int
    entries: tuple[BigEntry, ...]
    _data: bytes | None = None
    _path: Path | None = None
    _fingerprint: tuple[int, int, int, int] | None = None
    size_byte_order: str = "big"
    duplicate_names: tuple[str, ...] = ()
    invalid_entries: tuple[str, ...] = ()

    def read(self, name: str) -> bytes:
        """Read one entry (case-insensitively), without extracting any files."""
        wanted = normalize_path(name, allow_windows_special=True).lower()
        # Native EA ArchiveFile::addFile uses map assignment: duplicate paths
        # inside one input archive resolve to the final directory entry.
        entry = next((item for item in reversed(self.entries) if item.name.lower() == wanted), None)
        if entry is None:
            raise KeyError(name)
        # Native indexing can retain unused inconsistent records. A requested
        # payload must always be wholly inside the physical data region before
        # any slice, file open, seek or allocation is attempted.
        _validate_entry_data(entry, self.size, self.index_size)
        if self._data is not None:
            return self._data[entry.offset:entry.offset + entry.size]
        assert self._path is not None
        with self._path.open("rb") as handle:
            if _fingerprint(handle) != self._fingerprint:
                raise BigError("Archive changed after its index was read")
            handle.seek(entry.offset)
            result = handle.read(entry.size)
        if len(result) != entry.size:
            raise BigError("Archive entry was truncated")
        return result


def _fingerprint(handle) -> tuple[int, int, int, int]:
    import os
    stat = os.fstat(handle.fileno())
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns


def _native_index(data, path, header, count, actual_size, fingerprint) -> bytes:
    """Read the counted directory without trusting unused native header fields.

    EA's Win32BIGFileSystem seeks directly to 0x10 and reads count records.
    Neither the declared total size nor the final header integer bounds its
    directory. We retain physical-file, directory-size and name-length bounds.
    """
    limit = min(actual_size, _MAX_INDEX)
    if count > (limit - _HEADER.size) // 10:
        raise BigError("Entry count cannot fit inside the bounded BIG directory")
    index = bytearray(header)
    with (BytesIO(data) if data is not None else path.open("rb")) as handle:
        if path is not None and _fingerprint(handle) != fingerprint:
            raise BigError("Archive changed while reading its index")
        handle.seek(_HEADER.size)
        for _ in range(count):
            if len(index) + _ENTRY.size >= limit:
                raise BigError("Truncated or excessively large BIG directory")
            record = handle.read(_ENTRY.size)
            if len(record) != _ENTRY.size:
                raise BigError("Truncated BIG index entry")
            index.extend(record)
            for _ in range(_MAX_NAME + 1):
                if len(index) >= limit:
                    raise BigError("Truncated or excessively large BIG directory")
                character = handle.read(1)
                if not character:
                    raise BigError("Unterminated BIG entry name")
                index.extend(character)
                if character == b"\0":
                    break
            else:
                raise BigError("Oversized BIG entry name")
        if path is not None and _fingerprint(handle) != fingerprint:
            raise BigError("Archive changed while reading its index")
    return bytes(index)


def read_big(source: bytes | str | Path, *, strict: bool = True) -> BigArchive:
    """Parse BIGF/BIG4, loading only the bounded index for Path inputs.

    Strict mode rejects duplicate paths and overlapping data regions. Native
    compatibility mode reads the counted directory as the native loader does,
    ignores unused total/index size fields, and resolves duplicates last-wins.
    Directory and name bounds remain enforced. Source payload bounds are
    enforced when read; strict mode rejects inconsistent payload records at
    indexing as well. No inconsistent payload can be read or extracted.
    """
    data = None
    path = None
    fingerprint = None
    if isinstance(source, bytes):
        data = source
        actual_size = len(data)
        header = data[:_HEADER.size]
    else:
        path = Path(source)
        with path.open("rb") as handle:
            fingerprint = _fingerprint(handle)
            actual_size = fingerprint[2]
            header = handle.read(_HEADER.size)
    if len(header) != _HEADER.size:
        raise BigError("Truncated BIG header")
    magic, size, count, index_size = _HEADER.unpack(header)
    if magic not in (b"BIGF", b"BIG4"):
        raise BigError("Only uncompressed BIGF/BIG4 archives are supported")
    size_byte_order = "big"
    if size != actual_size:
        # Historical BIGF tools also emit a little-endian *total size*.
        # EA's Zero Hour reader ignores that field's value. Strict validation
        # requires a precise match; native compatibility uses physical size.
        # Entry integers remain big-endian. Our writer stays canonical.
        little_size = struct.unpack_from("<I", header, 4)[0]
        if little_size != actual_size and strict:
            raise BigError("BIG declared size does not match the actual file size")
        size = actual_size
        size_byte_order = "little" if little_size == actual_size else "ignored"
    if not strict:
        index = _native_index(data, path, header, count, actual_size, fingerprint)
        index_size = len(index)
    else:
        if not _HEADER.size <= index_size <= size or index_size > _MAX_INDEX:
            raise BigError("Invalid or excessively large BIG index")
        if count > (index_size - _HEADER.size) // 10:
            raise BigError("Entry count cannot fit inside the BIG index")
        if data is not None:
            index = data[:index_size]
        else:
            assert path is not None
            with path.open("rb") as handle:
                if _fingerprint(handle) != fingerprint:
                    raise BigError("Archive changed while reading its index")
                index = handle.read(index_size)
    if len(index) != index_size:
        raise BigError("Truncated BIG index")
    entries = []
    seen = set()
    duplicate_names = []
    invalid_entries = []
    cursor = _HEADER.size
    for _ in range(count):
        if cursor + _ENTRY.size >= index_size:
            raise BigError("Truncated BIG index entry")
        offset, length = _ENTRY.unpack_from(index, cursor)
        cursor += _ENTRY.size
        end = index.find(b"\x00", cursor, min(index_size, cursor + _MAX_NAME + 1))
        if end < 0:
            raise BigError("Unterminated or oversized BIG entry name")
        try:
            name = normalize_path(index[cursor:end].decode("ascii"), allow_windows_special=not strict)
        except UnicodeDecodeError as exc:
            raise BigError("Non-ASCII BIG entry name") from exc
        cursor = end + 1
        if strict and len(name) > _MAX_GAME_NAME:
            raise BigError("Archive path exceeds Zero Hour's native path buffer")
        if name.lower() in seen:
            if strict:
                raise BigError("Duplicate case-insensitive BIG entry: " + name)
            duplicate_names.append(name)
        seen.add(name.lower())
        entry = BigEntry(name, offset, length)
        if strict:
            _validate_entry_data(entry, size, index_size)
        elif not _entry_in_bounds(entry, size, index_size):
            invalid_entries.append(name)
        entries.append(entry)
    if strict:
        occupied = sorted((entry.offset, entry.offset + entry.size) for entry in entries if entry.size)
        if any(a_end > b_start for (_, a_end), (b_start, _) in zip(occupied, occupied[1:])):
            raise BigError("Overlapping BIG file entries")
    return BigArchive(magic, size, index_size, tuple(entries), data, path, fingerprint,
                      size_byte_order, tuple(duplicate_names), tuple(invalid_entries))


def write_big(files: Mapping[str, bytes], *, magic: bytes = b"BIGF") -> bytes:
    """Return canonical deterministic archive bytes; never overwrite an input."""
    if magic not in (b"BIGF", b"BIG4"):
        raise BigError("Archive magic must be BIGF or BIG4")
    normalized = {}
    seen = set()
    for name, content in files.items():
        name = normalize_path(name)
        if len(name) > _MAX_GAME_NAME:
            raise BigError("Archive path exceeds Zero Hour's native path buffer")
        if name.lower() in seen:
            raise BigError("Duplicate case-insensitive BIG entry: " + name)
        if not isinstance(content, bytes):
            raise TypeError("BIG entry content must be bytes")
        seen.add(name.lower())
        normalized[name] = content
    names = sorted(normalized, key=lambda item: (item.lower(), item))
    index_size = _HEADER.size + sum(_ENTRY.size + len(name.encode("ascii")) + 1 for name in names)
    size = index_size + sum(len(normalized[name]) for name in names)
    if index_size > _MAX_INDEX or size > _MAX_UINT32:
        raise BigError("Archive exceeds supported BIG format limits")
    index = bytearray(_HEADER.pack(magic, size, len(names), index_size))
    offset = index_size
    for name in names:
        content = normalized[name]
        index.extend(_ENTRY.pack(offset, len(content)))
        index.extend(name.encode("ascii") + b"\x00")
        offset += len(content)
    return bytes(index) + b"".join(normalized[name] for name in names)
