"""Small original RGB TGA/DDS decoders for private local texture assembly.
No commercial artwork is embedded. Top-left RGB images; PNG for diagnostics.
"""
import struct
import zlib

def _dimensions(w, h):
    if not 0 < w <= 2048 or not 0 < h <= 2048:
        raise ValueError('Reference image dimensions exceed supported limits')


def decode_tga(data: bytes):
    if len(data) < 18 or data[1] != 0 or data[2] not in (2, 10) or data[16] not in (24, 32):
        raise ValueError('Supported TGA formats: RGB/RGBA, raw or RLE')
    w, h = struct.unpack_from('<HH', data, 12)
    _dimensions(w, h)
    step = data[16]//8
    cursor = 18+data[0]
    pixels = []
    def take(n):
        nonlocal cursor
        if cursor+n > len(data):
            raise ValueError('Truncated TGA payload')
        result = data[cursor:cursor+n]
        cursor += n
        return result
    while len(pixels) < w*h:
        packet = take(1)[0] if data[2] == 10 else 0
        count = (packet & 127)+1
        if len(pixels)+count > w*h:
            raise ValueError('TGA packet exceeds image')
        if packet & 128:
            p = take(step)
            pixels.extend([bytes((p[2],p[1],p[0]))]*count)
        else:
            for _ in range(count):
                p = take(step)
                pixels.append(bytes((p[2],p[1],p[0])))
    rows = [pixels[y*w:(y+1)*w] for y in range(h)]
    if not data[17] & 32:
        rows.reverse()
    if data[17] & 16:
        rows = [list(reversed(row)) for row in rows]
    return w, h, b''.join(p for row in rows for p in row)


def decode_dds(data: bytes):
    if len(data) < 128 or data[:4] != b'DDS ' or struct.unpack_from('<I',data,4)[0] != 124:
        raise ValueError('Invalid DDS header')
    h,w = struct.unpack_from('<II',data,12)
    _dimensions(w,h)
    flags = struct.unpack_from('<I',data,80)[0]
    fourcc = data[84:88]
    output = bytearray(w*h*3)
    if flags & 4:
        if fourcc not in (b'DXT1',b'DXT3',b'DXT5'):
            raise ValueError('Supported compressed DDS formats: DXT1/3/5')
        step = 8 if fourcc == b'DXT1' else 16
        cursor = 128
        for by in range(0,h,4):
            for bx in range(0,w,4):
                if cursor+step > len(data):
                    raise ValueError('Truncated DDS blocks')
                color_at = cursor + (0 if step==8 else 8)
                a,b,indices = struct.unpack_from('<HHI',data,color_at)
                def rgb565(c):
                    return ((c>>11)*255//31,((c>>5)&63)*255//63,(c&31)*255//31)
                ca,cb = rgb565(a),rgb565(b)
                if a>b or fourcc != b'DXT1':
                    colors = [ca,cb,tuple((2*x+y)//3 for x,y in zip(ca,cb)),tuple((x+2*y)//3 for x,y in zip(ca,cb))]
                else:
                    colors = [ca,cb,tuple((x+y)//2 for x,y in zip(ca,cb)),(0,0,0)]
                for index in range(16):
                    x,y = bx+index%4,by+index//4
                    if x<w and y<h:
                        start = (y*w+x)*3
                        output[start:start+3] = bytes(colors[(indices>>(2*index))&3])
                cursor += step
    else:
        bits = struct.unpack_from('<I',data,88)[0]
        if not flags & 64 or bits not in (24,32):
            raise ValueError('Supported raw DDS: 24/32-bit RGB')
        masks = struct.unpack_from('<III',data,92)
        if any(not mask for mask in masks):
            raise ValueError('Invalid DDS color masks')
        has_pitch = struct.unpack_from('<I',data,8)[0] & 8
        pitch = max(w*(bits//8),struct.unpack_from('<I',data,20)[0]) if has_pitch else w*(bits//8)
        if pitch*h > len(data)-128:
            raise ValueError('Truncated raw DDS image')
        for y in range(h):
            for x in range(w):
                start = 128+y*pitch+x*(bits//8)
                value = int.from_bytes(data[start:start+bits//8],'little')
                output[(y*w+x)*3:(y*w+x)*3+3] = bytes(((value&mask)*255//mask) for mask in masks)
    return w,h,bytes(output)


def png(w,h,rgb):
    if len(rgb) != w*h*3:
        raise ValueError('RGB size mismatch')
    def chunk(name,data):
        return struct.pack('>I',len(data))+name+data+struct.pack('>I',zlib.crc32(name+data)&0xffffffff)
    scan = b''.join(b'\x00'+rgb[y*w*3:(y+1)*w*3] for y in range(h))
    return (b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))
            +chunk(b'IDAT',zlib.compress(scan))+chunk(b'IEND',b''))

