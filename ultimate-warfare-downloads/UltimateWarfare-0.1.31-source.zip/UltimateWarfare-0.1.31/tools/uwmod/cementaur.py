"""Cementaur: local Nuclear Cannon chassis, Overlord turret and statistics."""
from .ini import parse_ini, patch_command_set, IniError
from .interface import compact_production_panel
from .kitbash import Resources, assemble


def normal_draw(raw):
    body, = parse_ini(raw).blocks
    for draw in body.children:
        if draw.kind.lower() != 'draw':
            continue
        for state in draw.children:
            if state.kind.lower() == 'defaultconditionstate' or (state.kind.lower() == 'conditionstate' and state.value.upper() == 'NONE'):
                if state.find_fields('Model'):
                    return draw,state
    raise ValueError('Stock vehicle requires a normal Draw model')


def compile_cementaur(source, spec, output, files):
    from .project import _rename, _edit, _fields, _scalar, _append, BuildError, _newline
    seed, source_path = source.find_object(spec['source_object'])
    chassis, chassis_path = source.find_object(spec['chassis_object'])
    factory, factory_path = source.find_object(spec['production_object'])
    source.find_object(spec['prerequisite'])
    if spec['id'].lower() in source.object_names:
        raise BuildError('New object already exists: '+spec['id'])
    donor_draw, donor_state = normal_draw(seed)
    chassis_draw, chassis_state = normal_draw(chassis)
    resources = Resources(source)
    model, model_report = assemble(resources, _scalar(chassis_state,'Model'), _scalar(donor_state,'Model'),
                                    _scalar(chassis_state,'Turret'), _scalar(donor_state,'Turret'), spec['model'])
    virtual_model = 'Art\\W3D\\'+spec['model'].lower()+'.w3d'
    if virtual_model.lower() in source.entries or virtual_model in files:
        raise BuildError('Composite model path already exists')
    files[virtual_model] = model
    factory_block, = parse_ini(factory).blocks
    command_set = _scalar(factory_block,'CommandSet')
    try:
        patch = patch_command_set(output['CommandSet'],command_set,spec['button'])
    except IniError as exc:
        if str(exc) != 'No free production slot 1..12; original commands were preserved':
            raise
        patch = patch_command_set(output['CommandSet'],command_set,spec['button'],slots=(15,16))
        # Recreate from the original, never parse our narrowed grid as stock.
        ui='Window\\ControlBar.wnd'
        files[ui]=compact_production_panel(source.read(ui),slots=(15,16))
    output['CommandSet']=patch.data
    clone=_rename(seed,'Object',spec['id'])
    body, = parse_ini(clone).blocks
    # Keep exact weapon sets, armor, Body, AI, locomotors and economy. Remove
    # only the Overlord's separate upgrade attachment containers/commands.
    safe={'STOP','GUARD','ATTACK_MOVE','WAYPOINTS','ATTACK_OBJECT','ATTACK_GROUND'}
    original_set=parse_ini(output['CommandSet']).find_block('CommandSet',_scalar(body,'CommandSet'))
    buttons=parse_ini(output['CommandButton'])
    commands=[f for f in original_set.fields if _scalar(buttons.find_block('CommandButton',f.value),'Command').upper() in safe]
    if not any(_scalar(buttons.find_block('CommandButton',f.value),'Command').upper()=='STOP' for f in commands):
        raise BuildError('Overlord lacks a safe Stop command')
    new_set=(f"CommandSet {spec['command_set']}\n"+''.join(f'  {f.key} = {f.value}\n' for f in commands)+'End\n').encode('ascii')
    output['CommandSet']=_append(output['CommandSet'],[new_set])
    bindings=[]
    for field in donor_state.fields:
        if field.key.lower() in {'turret','turretpitch','weaponfirefxbone','weaponlaunchbone','weaponrecoilbone','weaponmuzzleflash'}:
            bindings.append(f'      {field.key} = {field.value}\n')
    # Preserve the original track settings where supported by the chassis.
    draw_fields=''
    draw_type=chassis_draw.value.split()[0]
    if draw_type.lower() not in {'w3dtankdraw','w3dtruckdraw','w3dmodeldraw'}:
        raise BuildError('Unsupported chassis Draw module: '+draw_type)
    for field in chassis_draw.fields:
        key=field.key.lower()
        if key in {'trackmarks','treadanimationrate','treadpivotspeed','treaddrivespeed',
                   'tirerotationmultiplier','powersliderotationaddition','cabrotationmultiplier',
                   'trailerrotationmultiplier','rotationdamping','dust','dirtspray','powerslidespray'} or key.endswith('tirebone') or key in {'cabbone','trailerbone'}:
            value=field.value
            if key.endswith('bone'):
                mapping={k.lower():v for k,v in model_report['chassis_bones'].items()}
                if value.lower() not in mapping:
                    raise BuildError('Chassis Draw references a missing bone: '+value)
                value=mapping[value.lower()]
            draw_fields += f'    {field.key} = {value}\n'
    draw=(f"  Draw = {draw_type} UWCementaurDraw\n    OkToChangeModelColor = Yes\n{draw_fields}"
          f"    DefaultConditionState\n      Model = {spec['model']}\n"+''.join(bindings)+
          '    End\n    ConditionState = RUBBLE\n      Model = NONE\n    End\n  End\n').encode('ascii').replace(b'\n',_newline(clone))
    edits=[];drawn=False
    for child in body.children:
        if child.kind.lower()=='draw':
            edits.append((child.start,child.end,b'' if drawn else draw));drawn=True
        if child.kind.lower()=='behavior' and child.value.split()[0].lower() in {'overlordcontain','objectcreationupgrade','subobjectsupgrade'}:
            edits.append((child.start,child.end,b''))
    if not drawn:
        raise BuildError('Overlord has no Draw module')
    clone=_edit(clone,edits);body,=parse_ini(clone).blocks
    requirements=[c for c in body.children if c.kind.lower()=='prerequisites']
    if len(requirements)>1:
        raise BuildError('Multiple Overlord prerequisite blocks')
    req=f"  Prerequisites\n    Object = {spec['prerequisite']}\n  End\n".encode('ascii').replace(b'\n',_newline(clone))
    clone=_edit(clone,[(requirements[0].start,requirements[0].end,req)] if requirements else [(body.header_end,body.header_end,req)])
    body,=parse_ini(clone).blocks
    chassis_body,=parse_ini(chassis).blocks
    # Footprint follows the actual Nuclear Cannon hull. Rendering stays at
    # stock scale; weapon, health, resistance, speed, cost and time stay Overlord.
    updates={'DisplayName':spec['display_label'],'CommandSet':spec['command_set'],'BuildVariations':None,
             'Shadow':'SHADOW_DECAL','ShadowTexture':'shadow','ShadowSizeX':'48','ShadowSizeY':'24'}
    for key in ('Geometry','GeometryMajorRadius','GeometryMinorRadius','GeometryHeight','GeometryIsSmall'):
        fields=chassis_body.find_fields(key)
        updates[key]=fields[0].value if fields else None
    for i in range(1,6):
        updates[f'UpgradeCameo{i}']=None
    clone=_fields(clone,body,updates)
    virtual='Data\\INI\\Object\\'+spec['id']+'.ini'
    if virtual.lower() in source.entries:
        raise BuildError('New object path already exists')
    files[virtual]=clone
    source_body,=parse_ini(seed).blocks
    # Reuse the installed Overlord cameo; no stock icon is redistributed.
    image=_scalar(source_body,'ButtonImage')
    button=(f"CommandButton {spec['button']}\n  Command = UNIT_BUILD\n  Object = {spec['id']}\n"
            f"  TextLabel = {spec['button_label']}\n  ButtonImage = {image}\n  ButtonBorderType = BUILD\n"
            f"  DescriptLabel = {spec['tooltip_label']}\nEnd\n").encode('ascii')
    body_modules=[c for c in source_body.children if c.kind.lower()=='body']
    if len(body_modules)!=1:
        raise BuildError('Overlord requires one Body module')
    report={'id':spec['id'],'profile':'stock_kitbash','reference_object':spec['source_object'],
            'factory':spec['production_object'],'command_set':command_set,'production_slot':patch.slot,
            'source_object_file':source_path,'source_chassis_file':chassis_path,'source_factory_file':factory_path,
            'health':float(_scalar(body_modules[0],'MaxHealth')),'cost':float(_scalar(source_body,'BuildCost')),
            'build_seconds':float(_scalar(source_body,'BuildTime')),'model_assembly':model_report,
            'model_sources':resources.records,'upgrades':'separate Overlord attachment upgrades omitted',
            'footprint':'stock Nuclear Cannon; combat/economy/movement copied from Overlord'}
    return report,button
