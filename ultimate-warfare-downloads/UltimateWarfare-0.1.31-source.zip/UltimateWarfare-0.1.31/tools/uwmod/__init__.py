"""Local tooling for original Command & Conquer: Generals Zero Hour mods."""
