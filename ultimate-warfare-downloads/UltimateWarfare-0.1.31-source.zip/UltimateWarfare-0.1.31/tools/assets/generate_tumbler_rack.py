#!/usr/bin/env python3
"""Original four-missile Tumbler rear rack, CC0 geometry; MIT exporter code."""
import json
import math
from pathlib import Path
from generate_longma import Mesh, w3d

OUTPUT=Path(__file__).resolve().parents[2]/'assets/generated'
SCALE=1.25
POSITIONS=[(1.9,-1.55,.65),(1.9,-1.55,1.55),(1.9,1.55,.65),(1.9,1.55,1.55)]
BONES=[('ROOTTRANSFORM',-1,(0.,0.,0.)),('R_TURRET',0,(0.,0.,0.))]+[(f'ROCKET{i+1:02d}',1,p) for i,p in enumerate(POSITIONS)]
BONES=[(n,p,tuple(v*SCALE for v in t)) for n,p,t in BONES]
ORIGINS=[(0.,0.,0.),(0.,0.,0.)]+[b[2] for b in BONES[2:]]


def rack():
    support=Mesh('RACK',1);color=Mesh('HOUSECOLOR',1)
    support.cylinder((-.3,0.,.1),.65,.25,'z',16,7)
    support.box((-.1,0.,.28),(1.5,3.9,.25),0)
    for side in (-1,1):
        support.box((-.2,side*1.55,.9),(.35,.45,1.3),2)
        support.box((.1,side*1.55,.45),(2.8,.7,.18),7)
        support.box((.1,side*1.55,1.35),(2.8,.7,.18),7)
        color.box((-.2,side*1.81,.9),(.35,.06,.5),9)
    meshes=[support,color]
    for i,(x,y,z) in enumerate(POSITIONS):
        missile=Mesh(f'ROCKET{i+1:02d}',i+2)
        # Narrow graphite missiles with a light nose and four small fins.
        missile.cylinder((.15,y,z),.22,2.85,'x',12,5)
        missile.cylinder((-1.3,y,z),.16,.16,'x',12,7)
        base=1.575;tip=1.9
        for j in range(12):
            a=j*math.tau/12;b=(j+1)*math.tau/12
            missile.face([(base,y+.22*math.cos(a),z+.22*math.sin(a)),
                          (base,y+.22*math.cos(b),z+.22*math.sin(b)),(tip,y,z)],tile=10)
        for sign in (-1,1):
            missile.box((-.85,y+sign*.29,z),(.6,.25,.045),2)
            missile.box((-.85,y,z+sign*.29),(.6,.045,.25),2)
        meshes.append(missile)
    for m in meshes:
        m.vertices=[tuple(v*SCALE for v in p) for p in m.vertices]
    return meshes


def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    meshes=rack()
    (OUTPUT/'uwtbrack.w3d').write_bytes(w3d(meshes,model_name='UWTBRACK',texture_name='uwtumbler.tga',bones=BONES,origins=ORIGINS))
    lines=['# Original authored rear missile rack; CC0-1.0','mtllib uwtumbler.mtl'];offset=1
    for m in meshes:
        lines+=['o '+m.name,'usemtl TUMBLER']
        lines+=['v %.6f %.6f %.6f'%p for p in m.vertices]
        lines+=['vt %.6f %.6f'%p for p in m.uvs]
        lines+=['vn %.6f %.6f %.6f'%p for p in m.normals]
        lines+=['f '+' '.join(f'{i+offset}/{i+offset}/{i+offset}' for i in f) for f in m.triangles]
        offset+=len(m.vertices)
    (OUTPUT/'uwtbrack.obj').write_text('\n'.join(lines)+'\n')
    data={'model':'UWTBRACK','asset_license':'CC0-1.0','texture':'uwtumbler.tga',
          'bones':[{'name':n,'parent':p,'translation':t} for n,p,t in BONES],
          'meshes':[{'name':m.name,'bone':m.bone,'origin':ORIGINS[m.bone],'vertices':m.vertices,'normals':m.normals,'uvs':m.uvs,'triangles':m.triangles} for m in meshes]}
    (OUTPUT/'uwtbrack.mesh.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    print('UWTBRACK:',sum(len(m.triangles) for m in meshes),'triangles, four independently hidden missiles')


if __name__=='__main__':main()
