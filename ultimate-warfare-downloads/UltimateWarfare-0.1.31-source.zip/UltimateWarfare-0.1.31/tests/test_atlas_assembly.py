"""Private texture assembly tested with original synthetic gradient artwork."""
import unittest
from pathlib import Path

from tools.uwmod.stock_art import assemble_atlas
from tools.uwmod.texture_io import decode_tga


class AtlasAssemblyTests(unittest.TestCase):
    def test_crop_orientation_and_untouched_player_color_tile(self):
        fallback=(Path(__file__).resolve().parents[1]/'assets/generated/uwlongma.tga').read_bytes()
        gradient=b''.join(bytes((x,y,77)) for y in range(256) for x in range(256))
        recipe={'reference_size':256,'tiles':[{'tile':0,'source':'fixture','rect':[20,30,60,70]}]}
        atlas=assemble_atlas(fallback,recipe,{'fixture':(256,256,gradient)})
        w,h,rgb=decode_tga(atlas)
        self.assertEqual((w,h),(512,512))
        self.assertEqual(rgb[(384*512)*3:(384*512)*3+3],bytes((20,30,77)))
        self.assertEqual(rgb[(511*512+127)*3:(511*512+127)*3+3],bytes((59,69,77)))
        _,_,before=decode_tga(fallback)
        for y in range(128,256):
            a,b=(y*512+256)*3,(y*512+384)*3
            self.assertEqual(rgb[a:b],before[a:b])

    def test_invalid_crop_and_player_color_overwrite_are_rejected(self):
        fallback=(Path(__file__).resolve().parents[1]/'assets/generated/uwlongma.tga').read_bytes()
        image={'fixture':(256,256,bytes((50,60,70))*256*256)}
        for tile,rect in ((10,[0,0,32,32]),(0,[20,20,400,50])):
            with self.subTest(tile=tile),self.assertRaises(ValueError):
                assemble_atlas(fallback,{'reference_size':256,'tiles':[{'tile':tile,'source':'fixture','rect':rect}]},image)
