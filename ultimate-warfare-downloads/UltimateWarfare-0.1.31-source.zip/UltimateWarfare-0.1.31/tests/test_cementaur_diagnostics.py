"""Metadata diagnosis of authored fixtures; no native game art."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import test_project as fixtures
from uwmod.project import compile_project, GameSource
from uwmod.archive import write_big
from tools.inspect_cementaur import diagnose


class CementaurDiagnosticsTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def test_sources_and_assembled_bindings_are_reported_without_geometry_arrays(self):
        files,_=compile_project(GameSource(self.game),self.project)
        archive=self.root/'Authored.big';archive.write_bytes(write_big(files))
        data=diagnose(self.game,archive)
        self.assertEqual([v['object'] for v in data['vehicles']],['ChinaVehicleNukeLauncher','ChinaTankOverlord'])
        original=data['vehicles'][1];actual=data['assembled_model']
        self.assertEqual(original['meshes'][0]['selected_triangles'],0)
        self.assertEqual(original['meshes'][1]['selected_triangles'],12)
        self.assertEqual(original['meshes'][1]['vertices_sha256'],actual['meshes'][1]['vertices_sha256'])
        self.assertEqual(original['meshes'][1]['uv_channels'],actual['meshes'][1]['uv_channels'])
        self.assertEqual(actual['meshes'][1]['binding_name'],'FixtureTurret')
        serialized=json.dumps(data)
        self.assertNotIn(str(self.game),serialized)
        self.assertNotIn('triangles_raw',serialized)
        self.assertNotIn('vertices_raw',serialized)
        self.assert_original_unchanged()

    def test_script_writes_new_report_and_refuses_game_output_and_overwrite(self):
        script=Path(__file__).resolve().parents[1]/'tools/inspect_cementaur.py'
        target=self.root/'Report.json'
        args=[sys.executable,str(script),'--game-dir',str(self.game),'--report',str(target)]
        result=subprocess.run(args,capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        original=target.read_bytes()
        repeat=subprocess.run(args,capture_output=True,text=True)
        self.assertNotEqual(repeat.returncode,0)
        self.assertEqual(target.read_bytes(),original)
        args[-1]=str(self.game/'NoWrite.json')
        result=subprocess.run(args,capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0)
        self.assertFalse((self.game/'NoWrite.json').exists())
        self.assert_original_unchanged()
