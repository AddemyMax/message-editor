"""Private stock assembly against authored geometry; not native game proof."""
import copy
import json
import struct
import unittest
from pathlib import Path
import tempfile

import test_project as fixtures
from kitbash_fixtures import stock_model
from tools.uwmod.kitbash import assemble, unpack, pack, one, name, world_positions, Resources, verify_dependencies
from uwmod.project import GameSource, compile_project, validate_archive
from uwmod.ini import parse_ini
from uwmod.archive import write_big


class MemoryResources:
    def __init__(self):
        self.files={'Art\\W3D\\FixtureNuke.w3d':stock_model('FixtureNuke','NUKETURRET',3),
                    'Art\\W3D\\FixtureOriginal.w3d':stock_model('FixtureOriginal')}
    def read(self,path):
        return self.files[path]


class KitbashTests(unittest.TestCase):
    def assemble(self,resources=None):
        return assemble(resources or MemoryResources(),'FixtureNuke','FixtureOriginal','NUKETURRET','FixtureTurret','UWCEMENTAUR')

    def test_actual_chassis_and_turret_vertices_materials_uvs_are_retained(self):
        resources=MemoryResources();raw,report=self.assemble(resources)
        top=unpack(raw);meshes=[v for cid,v in top if cid==0]
        self.assertEqual([name(one(m,0x1f)[8:24]) for m in meshes],['BODY','TURRET'])
        sources=[unpack(resources.read(p)) for p in resources.files]
        expected=[next(v for cid,v in sources[0] if cid==0),[v for cid,v in sources[1] if cid==0][1]]
        for actual,original in zip(meshes,expected):
            for cid in (2,3,0x20,0x28,0x29,0x2a,0x30,0x38):
                self.assertEqual(one(actual,cid),one(original,cid))
        pivots=list(struct.iter_unpack('<16sI10f',one(one(top,0x100),0x102)))
        turret=next(i for i,p in enumerate(pivots) if name(p[0])=='FixtureTurret')
        self.assertEqual(world_positions(pivots)[turret],(0,0,3))
        self.assertEqual(report['mesh_counts'],[1,1])

    def test_external_hierarchy_and_mesh_files_are_resolved(self):
        resources=MemoryResources()
        path='Art\\W3D\\FixtureOriginal.w3d';top=unpack(resources.files[path])
        tree=one(top,0x100);head=one(tree,0x101)
        tree=[(cid,head[:4]+b'ExternalTree'.ljust(16,b'\0')+head[20:] if cid==0x101 else p) for cid,p in tree]
        resources.files['Art\\W3D\\ExternalTree.w3d']=pack([(0x100,tree)])
        hlod=one(top,0x700);new=[]
        for cid,p in hlod:
            new.append((cid,p[:24]+b'ExternalTree'.ljust(16,b'\0') if cid==0x701 else p))
        resources.files[path]=pack([v for v in top if v[0]==0]+[(0x700,new)])
        raw,_=self.assemble(resources)
        self.assertTrue(raw)

    def test_skin_bone_indices_and_per_face_channels_are_remapped_and_filtered(self):
        resources=MemoryResources();path='Art\\W3D\\FixtureOriginal.w3d'
        top=unpack(resources.files[path]);mesh=next(v for cid,v in top if cid==0)
        nv=struct.unpack_from('<I',one(mesh,0x1f),44)[0]
        # Three cube faces belong to the turret, three to the discarded hull.
        influences=b''.join(struct.pack('<H6x',1 if i<nv//2 else 0) for i in range(nv))
        revised=[]
        for cid,p in mesh:
            if cid==0x38:
                p=[(c,struct.pack('<12I',*range(12)) if c==0x3a else v) for c,v in p]
            revised.append((cid,p))
        revised.append((0xe,influences))
        resources.files[path]=pack([(0x100,one(top,0x100)),(0,revised),(0x700,one(top,0x700))])
        # Retain only the BODY mesh binding; its vertex skin supplies the turret.
        top=unpack(resources.files[path]);hlod=one(top,0x700);lod=one(hlod,0x702)
        lod=[(0x703,struct.pack('<If',1,3.402823466e38)),next(v for v in lod if v[0]==0x704)]
        resources.files[path]=pack([(0x100,one(top,0x100)),(0,revised),(0x700,[(c,lod if c==0x702 else v) for c,v in hlod])])
        raw,_=self.assemble(resources);top=unpack(raw);skin=[v for c,v in top if c==0][-1]
        self.assertEqual(struct.unpack_from('<I',one(skin,0x1f),40)[0],6)
        self.assertEqual(one(one(skin,0x38),0x3a),struct.pack('<6I',*range(6)))
        self.assertEqual(struct.unpack_from('<H',one(skin,0xe))[0],6)

    def test_missing_turret_and_malformed_chunks_fail_before_assembly(self):
        resources=MemoryResources()
        with self.assertRaisesRegex(ValueError,'turret pivot'):
            assemble(resources,'FixtureNuke','FixtureOriginal','Absent','FixtureTurret','UWCEMENTAUR')
        with self.assertRaisesRegex(ValueError,'Truncated'):
            unpack(b'1234')


class CementaurIntegrationTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged
    fill_factory=fixtures.ProjectIntegrationTests.fill_factory

    def test_overlord_combat_economy_ai_and_movement_are_byte_exact(self):
        files,report=compile_project(GameSource(self.game),self.project)
        source=GameSource(self.game);original,_=source.find_object('ChinaTankOverlord')
        new=files['Data\\INI\\Object\\ChinaTankUWCementaur.ini']
        old_doc=parse_ini(original);new_doc=parse_ini(new)
        old,=old_doc.blocks;unit,=new_doc.blocks
        for kind in ('weaponset','armorset','body'):
            self.assertEqual([old_doc.source(c) for c in old.children if c.kind.lower()==kind],
                             [new_doc.source(c) for c in unit.children if c.kind.lower()==kind])
        for kind in ('AIUpdateInterface','PhysicsBehavior'):
            self.assertEqual([old_doc.source(c) for c in old.children if c.value and c.value.split()[0]==kind],
                             [new_doc.source(c) for c in unit.children if c.value and c.value.split()[0]==kind])
        for field in ('BuildCost','BuildTime','Locomotor'):
            self.assertEqual([f.value for f in old.find_fields(field)],[f.value for f in unit.find_fields(field)])
        self.assertEqual(unit.find_fields('GeometryMajorRadius')[0].value,'22')
        self.assertEqual(report['units'][2]['health'],1375)
        self.assertNotIn('Object ChinaTankOverlord',new.decode('ascii'))
        self.assert_original_unchanged()

    def test_full_factory_has_longma15_cementaur16_and_missing16_window_fails(self):
        self.fill_factory();files,report=compile_project(GameSource(self.game),self.project)
        self.assertEqual([report['units'][i]['production_slot'] for i in (0,2)],[15,16])
        from tools.uwmod.interface import windows
        nodes=windows(files['Window\\ControlBar.wnd']);buttons=[n for n in nodes if 'ButtonCommand' in n.name]
        for i,n in enumerate(buttons):
            x,y,r,b,*_=n.rect
            for other in buttons[i+1:]:
                X,Y,R,B,*_=other.rect
                self.assertFalse(x<R and r>X and y<B and b>Y)
        target=self.root/'Cementaur.big';target.write_bytes(write_big(files));validate_archive(target)
        extra=next(n for n in nodes if n.name.endswith('ButtonCommand16'))
        data=files['Window\\ControlBar.wnd'];files['Window\\ControlBar.wnd']=data[:extra.start]+data[extra.end:]
        target.write_bytes(write_big(files))
        with self.assertRaisesRegex(ValueError,'matching command window'):
            validate_archive(target)

    def test_chassis_wheel_bindings_and_overlord_muzzle_bindings_are_connected(self):
        key='Data/INI/Object/FixtureSource.ini'
        self.fixture[key]=self.fixture[key].replace(b'W3DModelDraw FixtureNukeDraw',b'W3DTruckDraw FixtureNukeDraw\n    LeftFrontTireBone = ROOTTRANSFORM\n    TireRotationMultiplier = 0.3')
        self.write_fixture();files,_=compile_project(GameSource(self.game),self.project)
        obj,=parse_ini(files['Data\\INI\\Object\\ChinaTankUWCementaur.ini']).blocks
        draw=next(c for c in obj.children if c.kind.lower()=='draw')
        self.assertTrue(draw.value.startswith('W3DTruckDraw'))
        self.assertEqual(draw.find_fields('LeftFrontTireBone')[0].value,'C000')
        self.assertEqual(draw.children[0].find_fields('WeaponLaunchBone')[0].value,'PRIMARY MUZZLE')
        target=self.root/'WheelBindings.big';target.write_bytes(write_big(files));validate_archive(target)
        self.assert_original_unchanged()

    def test_model_checksums_detect_mutation_in_shared_base_game(self):
        base=self.root/'Command and Conquer Generals';base.mkdir()
        models={k:v for k,v in self.fixture.items() if k.startswith('Art/W3D')}
        for key in models:
            del self.fixture[key]
        self.write_fixture();archive=base/'W3D.big';archive.write_bytes(write_big(models))
        source=GameSource(self.game);_,report=compile_project(source,self.project)
        records=report['model_sources'];self.assertTrue(all(r['root']==str(base) for r in records))
        verify_dependencies(GameSource(self.game),records)
        key=next(iter(models));models[key]=models[key]+b'changed'
        archive.write_bytes(write_big(models))
        with self.assertRaisesRegex(ValueError,'models changed'):
            verify_dependencies(GameSource(self.game),records)
        self.assert_original_unchanged()
