"""Launch preflight on invented data; no actual game process is executed."""
from contextlib import redirect_stderr, redirect_stdout
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from uwmod.archive import write_big
from uwmod.project import main
from test_project import invented_game_files
from test_project import invented_texture


class LaunchIntegrityTests(unittest.TestCase):
    def build_with_shared_art(self):
        base=self.root/'Generals';base.mkdir()
        art={key:self.fixture.pop(key) for key in list(self.fixture) if key.startswith('Art/Textures/')}
        self.original.write_bytes(write_big(self.fixture))
        archive=base/'Textures.big';archive.write_bytes(write_big(art))
        output=self.root/'Build/Shared.big'
        code,_,error=self.run_cli('build','--game-dir',str(self.game),'--output',str(output))
        self.assertEqual(code,0,error)
        code,_,error=self.run_cli('check-launch','--game-dir',str(self.game),'--archive',str(output))
        self.assertEqual(code,0,error)
        return base,archive,art,output

    def test_changed_shared_texture_requires_rebuild(self):
        base,archive,art,output=self.build_with_shared_art()
        art['Art/Textures/NVOvrlrd.tga']=invented_texture(256,21)
        archive.write_bytes(write_big(art))
        code,_,error=self.run_cli('check-launch','--game-dir',str(self.game),'--archive',str(output))
        self.assertEqual(code,1)
        self.assertIn('stock artwork changed',error)

    def test_new_loose_texture_cannot_silently_mask_shared_source(self):
        base,archive,art,output=self.build_with_shared_art()
        loose=self.game/'Art/Textures/NVOvrlrd.tga';loose.parent.mkdir(parents=True)
        loose.write_bytes(invented_texture(256,21))
        code,_,error=self.run_cli('check-launch','--game-dir',str(self.game),'--archive',str(output))
        self.assertEqual(code,1)
        self.assertIn('stock artwork changed',error)

    def test_build_never_writes_into_shared_generals_installation(self):
        base,archive,art,output=self.build_with_shared_art()
        forbidden=base/'PrivateMod.big'
        code,_,error=self.run_cli('build','--game-dir',str(self.game),'--output',str(forbidden))
        self.assertEqual(code,1)
        self.assertIn('Refusing to write',error)
        self.assertFalse(forbidden.exists())
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.game = self.root / "Game"
        self.game.mkdir()
        self.fixture = invented_game_files()
        self.original = self.game / "INIZH.big"
        self.original.write_bytes(write_big(self.fixture))
        (self.game / "generals.exe").write_bytes(b"Authored test marker, never executable or executed")
        self.output = self.root / "Build/Prototype.big"
        code, _, error = self.run_cli("build", "--game-dir", str(self.game), "--output", str(self.output))
        self.assertEqual(code, 0, error)

    def run_cli(self, *arguments):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            code = main(list(arguments))
        return code, stdout.getvalue(), stderr.getvalue()

    def check(self):
        return self.run_cli("check-launch", "--game-dir", str(self.game), "--archive", str(self.output))

    def test_source_change_requires_rebuild_and_does_not_run_game(self):
        self.fixture["Data/INI/Weapon.ini"] += b"; Source changed after build\n"
        changed = write_big(self.fixture)
        self.original.write_bytes(changed)
        code, _, error = self.check()
        self.assertEqual(code, 1)
        self.assertIn("changed since build", error)
        self.assertEqual(self.original.read_bytes(), changed)

    def test_object_source_change_is_also_tracked(self):
        key = "Data/INI/Object/FixtureSource.ini"
        self.fixture[key] += b"; changed object\n"
        self.original.write_bytes(write_big(self.fixture))
        code, _, error = self.check()
        self.assertEqual(code, 1)
        self.assertIn("changed since build", error)

    def test_missing_companion_manifest_is_rejected(self):
        self.output.with_suffix(".manifest.json").unlink()
        code, _, error = self.check()
        self.assertEqual(code, 1)
        self.assertIn("Companion build manifest missing", error)

    def test_archive_hash_mismatch_is_rejected(self):
        manifest_path = self.output.with_suffix(".manifest.json")
        report = json.loads(manifest_path.read_text())
        report["archive_sha256"] = "0" * 64
        manifest_path.write_text(json.dumps(report))
        code, _, error = self.check()
        self.assertEqual(code, 1)
        self.assertIn("checksum no longer matches", error)


if __name__ == "__main__":
    unittest.main()
