import struct
import unittest
import zlib

from tools.uwmod.compression import CompressionError, MAX_DECODED_SIZE, decode_payload


def refpack(size, commands, marker=0x10):
    """Independent byte fixture for the documented EA stream format."""
    width = 4 if marker & 0x80 else 3
    extra = (123).to_bytes(width, "big") if marker & 1 else b""
    return bytes((marker, 0xFB)) + extra + size.to_bytes(width, "big") + commands


def ear(stream, size):
    return b"EAR\0" + struct.pack("<I", size) + stream


def literal_commands(data):
    """Encode only aligned literal runs, without using a compressor."""
    if len(data) % 4:
        raise ValueError("Fixture literal prefix must be a multiple of four")
    result = bytearray()
    for position in range(0, len(data), 112):
        block = data[position:position + 112]
        result.append(0xE0 + len(block) // 4 - 1)
        result.extend(block)
    return bytes(result)


class CompressionTests(unittest.TestCase):
    def test_plain_data_is_unchanged(self):
        for data in (b"", b"Object Example\r\nEnd\r\n", b" FSC", b"EAR", b"ZL0\0test"):
            self.assertIs(decode_payload(data), data)
        with self.assertRaises(TypeError):
            decode_payload("text")

    def test_all_refpack_length_headers_and_outer_ear(self):
        for marker in (0x10, 0x11, 0x90, 0x91):
            stream = refpack(7, b"\xe0abcd\xffxyz", marker)
            self.assertEqual(decode_payload(stream), b"abcdxyz")
            self.assertEqual(decode_payload(ear(stream, 7)), b"abcdxyz")

    def test_terminal_literal_counts_and_empty_stream(self):
        for count in range(4):
            data = b"abc"[:count]
            self.assertEqual(decode_payload(refpack(count, bytes((0xFC + count,)) + data)), data)

    def test_fixture_encoded_by_pinned_original_ea_encoder(self):
        # Generated from synthetic text with actual EA REF_encode, compiled from
        # EAC/refencode.cpp at 0a05454d8574207440a5fb15241b98ad0b435590.
        # Actual EA REF_decode also verified every byte and consumed length.
        original = (b"Object SyntheticFixture\n  Side = China\nEnd\n" * 24
                    + b"A" * 40 + b"1234567abc1234567")
        encoded = bytes.fromhex(
            "10fb000441e94f626a6563742053796e746865746963466978747572650a20205369"
            "6465203d204368696e610a45cf002ad86e640aa3400041e331323334353637616263"
            "313233343536fd37")
        self.assertEqual(decode_payload(encoded), original)
        self.assertEqual(decode_payload(ear(encoded, len(original))), original)

    def test_short_medium_and_long_overlapping_references(self):
        fixtures = [
            (b"\x03\x02abc\xfc", b"abcabc"),
            (b"\x83\xc0\x02abc\xfc", b"abcabcabca"),
            (b"\xc3\x00\x02\x03abc\xfc", b"abcabcabcab"),
            (b"\xe0abcd\x1c\x00\xfc", b"abcd" + b"d" * 10),
        ]
        for commands, expected in fixtures:
            with self.subTest(commands=commands):
                self.assertEqual(decode_payload(refpack(len(expected), commands)), expected)

    def test_reference_distance_bits_and_maximum_long_match(self):
        cases = [
            (bytes(range(256)) * 4, b"\x60\x00", 769, 3),
            (bytes(range(256)) * 64, b"\x80\x3f\xff", 16384, 4),
            (bytes(range(256)) * 512, b"\xdc\xff\xff\xff", 131072, 1028),
        ]
        for prefix, command, distance, count in cases:
            expected = prefix + prefix[len(prefix) - distance:len(prefix) - distance + count]
            commands = literal_commands(prefix) + command + b"\xfc"
            self.assertEqual(decode_payload(refpack(len(expected), commands)), expected)

    def test_all_ea_zlib_signatures(self):
        data = b"Object Original\r\nEnd\r\n" * 100
        for level in range(1, 10):
            signature = f"ZL{level}\0".encode("ascii")
            payload = signature + struct.pack("<I", len(data)) + zlib.compress(data, level)
            self.assertEqual(decode_payload(payload), data)
        self.assertEqual(decode_payload(b"ZL1\0" + struct.pack("<I", 0) + zlib.compress(b"")), b"")

    def test_reject_unsupported_known_codecs(self):
        for marker in (b"EAB\0", b"EAH\0", b"NOX\0"):
            with self.assertRaisesRegex(CompressionError, "Unsupported EA"):
                decode_payload(marker + struct.pack("<I", 12) + b"whatever")

    def test_reject_truncated_wrappers_headers_commands_and_literals(self):
        stream = refpack(7, b"\xe0abcd\xffxyz")
        for count in range(len(stream)):
            if count < 2:
                continue  # Incomplete markers cannot identify a stream.
            with self.subTest(count=count), self.assertRaises(CompressionError):
                decode_payload(stream[:count])
        for marker in (b"EAR\0", b"ZL1\0", b"NOX\0"):
            for count in range(4, 8):
                with self.assertRaisesRegex(CompressionError, "Truncated"):
                    decode_payload((marker + b"\0" * 4)[:count])
        for marker in (0x11, 0x90, 0x91):
            stream = refpack(0, b"\xfc", marker)
            with self.assertRaises(CompressionError):
                decode_payload(stream[:-1])
        for command in (b"\x00", b"\x80\0", b"\xc0\0\0"):
            with self.assertRaisesRegex(CompressionError, "Truncated"):
                decode_payload(refpack(8, command))

    def test_reject_invalid_reference_bounds_and_lengths(self):
        invalid = [
            refpack(3, b"\x00\x00\xfc"),
            refpack(6, b"\x03\x03abc\xfc"),
            refpack(3, b"\xe0abcd\xfc"),
            refpack(6, b"\xe0abcd\x00\x00\xfc"),
            refpack(5, b"\xe0abcd\xfc"),
            refpack(4, b"\xe0abcd\xfc\0"),
            ear(refpack(0, b"\xfc"), 1),
            ear(b"\x20\xfb\0\0\0\xfc", 0),
        ]
        for payload in invalid:
            with self.subTest(payload=payload), self.assertRaises(CompressionError):
                decode_payload(payload)

    def test_reject_oversized_declared_lengths_without_allocating(self):
        size = MAX_DECODED_SIZE + 1
        for payload in (refpack(size, b"\xfc", 0x90),
                        b"EAR\0" + struct.pack("<I", size),
                        b"ZL1\0" + struct.pack("<I", size)):
            with self.assertRaisesRegex(CompressionError, "64 MiB"):
                decode_payload(payload)

    def test_reject_bad_zlib_size_checksum_truncation_and_trailing_data(self):
        data = b"alpha" * 100
        valid = b"ZL9\0" + struct.pack("<I", len(data)) + zlib.compress(data)
        invalid = [valid[:-1], valid + b"tail", valid[:8] + b"not zlib",
                   valid[:4] + struct.pack("<I", len(data) - 1) + valid[8:],
                   valid[:4] + struct.pack("<I", len(data) + 1) + valid[8:]]
        corrupt = bytearray(valid)
        corrupt[-1] ^= 1
        invalid.append(bytes(corrupt))
        for payload in invalid:
            with self.subTest(payload=payload[:12]), self.assertRaises(CompressionError):
                decode_payload(payload)


if __name__ == "__main__":
    unittest.main()
