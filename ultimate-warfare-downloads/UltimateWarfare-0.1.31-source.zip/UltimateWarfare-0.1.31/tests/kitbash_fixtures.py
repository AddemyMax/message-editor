"""Small authored stock-shaped models. No commercial game artwork."""
from tools.assets.generate_longma import Mesh, w3d


def stock_model(model, turret='FixtureTurret', mount=5):
    bones=[('ROOTTRANSFORM',-1,(0.,0.,0.)),(turret,0,(0.,0.,float(mount))),
           ('BARREL',1,(1.,0.,0.)),('MUZZLE01',2,(4.,0.,0.))]
    origins=[(0.,0.,0.),(0.,0.,float(mount))]
    body=Mesh('BODY',0);body.box((0,0,1),(12,6,2),tile=1)
    gun=Mesh('TURRET',1);gun.box((0,0,mount+1),(4,3,2),tile=2)
    return w3d([body,gun],model_name=model,texture_name='authored-fixture.tga',bones=bones,origins=origins)
