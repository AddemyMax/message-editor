"""Opt-in line diagnostics on invented data; no game files are distributed."""
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
from explain_ini import explain, _production_layout, _control_bar_layout, _window_structure
from uwmod.project import PROJECT
from test_project import invented_game_files
from uwmod.archive import write_big
from uwmod.ini import parse_ini


class ExplainIniTests(unittest.TestCase):
    def test_window_structure_detects_nonbare_markers_without_comment_values(self):
        data = b'''WINDOW // PrivateComment
WINDOWTYPE = USER;
NAME = "ControlBar.wnd:Fixture";
CHILD;
ENDALLCHILDREN
END
TEXT = "PrivateText";
'''
        records = _window_structure(data)
        self.assertEqual([item["keyword"] for item in records], ["WINDOW", "WINDOWTYPE", "NAME", "CHILD", "ENDALLCHILDREN", "END"])
        self.assertTrue(records[0]["slash_comment"])
        self.assertTrue(records[3]["semicolon"])
        self.assertFalse(records[0]["bare_line"])
        self.assertNotIn("PrivateComment", json.dumps(records))
        self.assertNotIn("PrivateText", json.dumps(records))

    def test_explicit_wnd_diagnosis_is_available_despite_other_failure(self):
        self.fixture["Window/ControlBar.wnd"] = b'WINDOW\nWINDOWTYPE = USER;\nNAME = "ControlBar.wnd:Fixture";\nCHILD\nEND\nEND\n'
        self.fixture["Data/INI/Weapon.ini"] += b"#unsupported\n"
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        report = explain(self.game, window_structure=True)
        self.assertEqual(report["detail_kind"], "wnd_lexical_structure")
        file, = report["control_bar_layout"]["files"]
        self.assertEqual(file["structural_record_count"], 6)
        self.assertFalse(file["structural_records_truncated"])

    def test_control_bar_inspects_geometry_without_copying_art_or_callbacks(self):
        self.fixture["Data/Window/ControlBar.wnd"] = b'''WINDOW
 WINDOWTYPE = USER;
 SCREENRECT = UPPERLEFT: 0 400, BOTTOMRIGHT: 800 600, CREATIONRESOLUTION: 800 600;
 NAME = "ControlBar.wnd:CommandWindow";
 CHILD
 WINDOWTYPE = PUSHBUTTON;
 SCREENRECT = UPPERLEFT: 10 20, BOTTOMRIGHT: 40 50, CREATIONRESOLUTION: 800 600;
 NAME = "ControlBar.wnd:ButtonCommand15";
 INPUTCALLBACK = "PrivateCallback";
 ENABLEDDRAWDATA = IMAGE: PrivateArt;
 END
 ENDALLCHILDREN
END
'''
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        layout = _control_bar_layout(self.game)
        window_file, = layout["files"]
        self.assertEqual(window_file["command_window_names"], ["ControlBar.wnd:ButtonCommand15"])
        self.assertEqual(len(window_file["window_metadata"]), 2)
        self.assertIn("10 20", window_file["window_metadata"][1]["screen_rect"])
        self.assertNotIn("PrivateCallback", json.dumps(layout))
        self.assertNotIn("PrivateArt", json.dumps(layout))

    def test_missing_control_bar_is_reported_without_guessing_extra_buttons(self):
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        self.assertEqual(_control_bar_layout(self.game)["files"], [])

    def test_full_factory_reports_all_slots_without_changing_commands(self):
        raw = self.fixture["Data/INI/CommandSet.ini"]
        block = parse_ini(raw).find_block('CommandSet','FixtureFactoryCommands')
        full = (b"CommandSet FixtureFactoryCommands\n" +
            b"".join(f"  {slot} = Command_Fixture{slot}\n".encode("ascii") for slot in range(1, 15)) + b"End\n")
        self.fixture["Data/INI/CommandSet.ini"] = raw[:block.start] + full + raw[block.end:]
        report = self.run_fixture()
        self.assertEqual(report["detail_kind"], "factory_command_identifiers")
        menu = report["production_layout"][0]
        self.assertEqual(menu["factory_object"], "ChinaWarFactory")
        self.assertEqual(menu["command_set"], "FixtureFactoryCommands")
        self.assertEqual(menu["command_set_archive"], "INIZH.big")
        self.assertEqual(menu["free_production_slots"], [])
        self.assertEqual(menu["slots"][-1], {"slot": 14, "command_button": "Command_Fixture14"})
        self.assertNotIn("error_line_candidates", report)

    def test_layout_identifies_free_slots_and_keeps_service_slots(self):
        (self.game / "INIZH.big").write_bytes(write_big(self.fixture))
        menu = _production_layout(self.game, PROJECT)[0]
        self.assertEqual(menu["free_production_slots"], [2, 4, 5, 6, 7, 8, 9, 10, 11, 12])
        self.assertIn({"slot": 13, "command_button": "Command_Rally"}, menu["slots"])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.game = Path(self.temp.name) / "Game"
        self.game.mkdir()
        self.fixture = invented_game_files()
        (self.game / "generals.exe").write_bytes(b"Invented presence marker, never executed")
        (self.game / "game.dat").write_bytes(b"Invented presence marker, never executed")

    def run_fixture(self):
        archive = self.game / "INIZH.big"
        original = write_big(self.fixture)
        archive.write_bytes(original)
        report = explain(self.game)
        self.assertEqual(archive.read_bytes(), original)
        self.assertFalse(report["in_game_tested"])
        return report

    def test_object_error_exposes_only_one_escaped_source_line(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = (
            b"Object FixtureBroken\n  BuildCost = 900\n#unsupported_fixture\nEnd\n")
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["source_virtual_path"], "Data\\INI\\Object\\FixtureBroken.ini")
        self.assertEqual(line["line"], 3)
        self.assertEqual(line["ascii_escaped"], "#unsupported_fixture\n")
        self.assertEqual(bytes.fromhex(line["hex"]), b"#unsupported_fixture\n")
        self.assertNotIn("BuildCost = 900", json.dumps(report))
        self.assertEqual(report["line_detail_status"], "Exact source provenance")

    def test_legacy_control_marker_is_visible_and_line_is_clipped(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = (
            b"Object FixtureBroken\nEnd\n" + b"\x1a" + b"x" * 600 + b"\n")
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertTrue(line["ascii_escaped"].startswith("\x1a"))
        self.assertTrue(line["hex"].startswith("1a"))
        self.assertEqual(len(bytes.fromhex(line["hex"])), 512)
        self.assertTrue(line["truncated"])

    def test_monolithic_error_without_provenance_returns_candidate_source(self):
        self.fixture["Data/INI/Weapon.ini"] += b"#unsupported_fixture\n"
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["source_virtual_path"], "Data\\INI\\Weapon.ini")
        self.assertEqual(line["ascii_escaped"], "#unsupported_fixture\n")
        self.assertIn("Candidate", report["line_detail_status"])

    def test_unmatched_end_trace_shows_headers_and_keys_without_scalar_values(self):
        self.fixture["Data/INI/Object/FixtureBroken.ini"] = b"""Object FixtureBroken
  Behavior = FixtureUpdate FixtureTag
    ScalarText = PrivateFieldValue
    FixtureGroup = PrivateGroupArgument
      Delay = 100
    End
  End
End
"""
        report = self.run_fixture()
        line, = report["error_line_candidates"]
        self.assertEqual(line["line"], 8)
        self.assertEqual(line["ascii_escaped"], "End\n")
        context = line["structure_before_error"]
        self.assertEqual(context["scope_header"]["identifier"], "FixtureBroken")
        self.assertEqual(context["module_headers"][0]["module_type"], "FixtureUpdate")
        self.assertIn("FixtureGroup", [item["keyword"] for item in context["previous_keywords"]])
        self.assertNotIn("PrivateFieldValue", json.dumps(report))
        self.assertNotIn("PrivateGroupArgument", json.dumps(report))
        self.assertEqual(report["detail_tool_version"], "1.4")
