"""Check native armor identifiers and explicit survivability overrides."""
import json
import unittest

import test_project as fixtures
from uwmod.project import GameSource,compile_project,validate_archive,BuildError
from uwmod.ini import parse_ini
from uwmod.archive import write_big
from uwmod.tumbler_rockets import DAMAGE_TYPES,SPECIAL_DAMAGE


class TumblerSurvivabilityTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def test_native_pilot_identifier_and_every_generated_armor_type_are_valid(self):
        self.assertIn('KILL_PILOT',SPECIAL_DAMAGE)
        self.assertNotIn('KILLPILOT',DAMAGE_TYPES)
        files,_=compile_project(GameSource(self.game),self.project)
        doc=parse_ini(files['Data\\INI\\Armor.ini'])
        for armor in (b for b in doc.blocks if b.name.startswith('UWTumblerArmor')):
            kinds={f.value.split()[0] for f in armor.find_fields('Armor')}
            self.assertTrue(kinds<=DAMAGE_TYPES|{'DEFAULT'})
            self.assertIn('KILL_PILOT',kinds)
            self.assertNotIn('KILLPILOT',kinds)

    def test_unknown_native_damage_type_is_rejected_at_build_and_preflight(self):
        files,_=compile_project(GameSource(self.game),self.project)
        key='Data\\INI\\Armor.ini';files[key]=files[key].replace(b'Armor = KILL_PILOT',b'Armor = KILLPILOT')
        target=self.root/'InvalidArmor.big';target.write_bytes(write_big(files))
        with self.assertRaisesRegex(BuildError,'Unknown native damage type'):
            validate_archive(target)
        self.fixture['Data/INI/Armor.ini']+=b'Armor InvalidReferenceArmor\n  Armor = KILLPILOT 100%\nEnd\n'
        key='Data/INI/Object/FixtureSource.ini'
        # Only the Overlord donor gets the intentionally malformed table.
        raw=self.fixture[key];doc=parse_ini(raw);block=doc.find_block('Object','ChinaTankOverlord')
        changed=doc.source(block).replace(b'Armor = FixtureArmor',b'Armor = InvalidReferenceArmor')
        self.fixture[key]=raw[:block.start]+changed+raw[block.end:];self.write_fixture()
        with self.assertRaisesRegex(BuildError,'Unknown native damage type'):
            compile_project(GameSource(self.game),self.project)
        self.assert_original_unchanged()

    def test_5000_health_initial_health_manifest_and_subdual_ratios_agree(self):
        key='Data/INI/Object/FixtureSource.ini';raw=self.fixture[key]
        doc=parse_ini(raw);block=doc.find_block('Object','ChinaTankOverlord')
        altered=doc.source(block).replace(b'MaxHealth = 1375',b'MaxHealth = 1100').replace(b'InitialHealth = 1375',b'InitialHealth = 1100\n    SubdualDamageCap = 2200\n    SubdualDamageHealAmount = 50\n    SubdualDamageHealRate = 500')
        self.fixture[key]=raw[:block.start]+altered+raw[block.end:];self.write_fixture()
        files,report=compile_project(GameSource(self.game),self.project)
        obj,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        body=next(c for c in obj.children if c.kind.lower()=='body')
        values={f.key:f.value for f in body.fields}
        self.assertEqual(values['MaxHealth'],'5000');self.assertEqual(values['InitialHealth'],'5000')
        self.assertEqual(float(values['SubdualDamageCap']),10000)
        self.assertAlmostEqual(float(values['SubdualDamageHealAmount']),50*5000/1100,places=6)
        self.assertEqual(values['SubdualDamageHealRate'],'500')
        self.assertEqual(report['units'][1]['health'],5000)
        self.assertEqual(report['units'][1]['rockets']['health'],5000)
        # Source donor and separate rocket rack retain their own health.
        rack,=parse_ini(files['Data\\INI\\Object\\UWTumblerRocketRack.ini']).blocks
        rack_body=next(c for c in rack.children if c.kind.lower()=='body')
        self.assertEqual(rack_body.find_fields('MaxHealth')[0].value,'1000')
        self.assert_original_unchanged()

    def test_invalid_health_overrides_are_rejected(self):
        manifest=self.project/'content/units/tumbler.json';spec=json.loads(manifest.read_text())
        for value in (0,-1,True,'5000',1000001):
            spec['max_health']=value;manifest.write_text(json.dumps(spec))
            with self.assertRaisesRegex(BuildError,'maximum health'):
                compile_project(GameSource(self.game),self.project)
