"""Authored travel/deployed weapon branches reproduce the reported selection bug.

Only public bone identifiers are used; geometry and pivot coordinates are
invented here. No commercial model or uploaded report is included.
"""
import struct
import unittest

from tools.assets.generate_longma import Mesh, w3d
from tools.uwmod.kitbash import assemble, chassis_selection, unpack, one, name
from kitbash_fixtures import stock_model


class VariantResources:
    def __init__(self):
        self.bones=[('ROOTTRANSFORM',-1,(0,0,0)),('CHASSIS',0,(0,0,0)),
                    ('TURRET01',1,(0,0,4)),('BARREL01',2,(2,0,0)),
                    ('TURRETBACK',1,(-3,0,4)),('ELEVATIONBARREL',4,(0,0,1)),
                    ('LIFTERS',5,(0,0,0)),('GUNBARREL',5,(2,0,0)),
                    ('TURRETFRONT',1,(3,0,4)),('TREADSL01',1,(0,3,0)),
                    ('ARM01',1,(0,-3,0)),('HOUSECOLOR01',10,(0,0,1))]
        meshes=[]
        for index,(bone,_,_) in enumerate(self.bones[1:],1):
            m=Mesh(bone,index);m.box((0,0,0),(1,1,1),tile=index%8);meshes.append(m)
        self.files={'NVNUKECN':w3d(meshes,model_name='NVNUKECN',texture_name='authored.tga',bones=self.bones,origins=[(0,0,0)]*len(self.bones)),
                    'FIXTUREORIGINAL':stock_model('FixtureOriginal')}
    def read(self,path):
        return self.files[path.split('\\')[-1][:-4].upper()]


class CementaurWeaponVariantTests(unittest.TestCase):
    def test_transport_barrel_and_both_turrets_are_removed_but_chassis_is_exact(self):
        resources=VariantResources()
        result,report=assemble(resources,'NVNukeCn','FixtureOriginal','TURRET01','FixtureTurret','UWCEMENTAUR')
        top=unpack(result);meshes=[m for cid,m in top if cid==0]
        names=[name(one(m,0x1f)[8:24]) for m in meshes]
        self.assertEqual(names,['CHASSIS','TREADSL01','ARM01','HOUSECOLOR01','TURRET'])
        self.assertEqual(report['mesh_counts'],[4,1])
        self.assertEqual(report['removed_chassis_weapon_roots'],['TURRET01','TURRETFRONT','TURRETBACK'])
        original=[m for cid,m in unpack(resources.files['NVNUKECN']) if cid==0]
        for m in meshes[:4]:
            source=next(s for s in original if one(s,0x1f)[8:24]==one(m,0x1f)[8:24])
            self.assertEqual([v for v in m if v[0]!=0x1f],[v for v in source if v[0]!=0x1f])

    def test_split_weapon_branches_are_not_removed_from_other_models(self):
        resources=VariantResources()
        raw=resources.files['NVNUKECN'];top=unpack(raw)
        pivots=list(struct.iter_unpack('<16sI10f',one(one(top,0x100),0x102)))
        _,removed,extra=chassis_selection(pivots,'TURRET01','OtherCarrier')
        self.assertEqual(removed,{2,3});self.assertEqual(extra,[])

    def test_nuke_model_without_travel_variants_remains_supported(self):
        top=unpack(stock_model('NVNukeCn','TURRET01'))
        pivots=list(struct.iter_unpack('<16sI10f',one(one(top,0x100),0x102)))
        _,removed,extra=chassis_selection(pivots,'TURRET01','NVNukeCn')
        self.assertEqual(removed,{1,2,3});self.assertEqual(extra,[])
