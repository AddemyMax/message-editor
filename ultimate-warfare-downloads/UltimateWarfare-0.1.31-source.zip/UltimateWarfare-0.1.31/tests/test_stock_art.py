"""Decode authored tiny art fixtures; installed commercial assets are read-only."""
import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import zlib

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from inspect_stock_art import decode_dds, decode_tga, texture_names, png, inspect
from tools.uwmod.texture_io import decode_dds as decode_private_dds
from uwmod.archive import write_big
from test_project import invented_game_files


def tga():
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,2,1,24,32)+bytes([0,0,255,0,255,0])


class StockArtTests(unittest.TestCase):
    def test_shared_generals_texture_and_loose_override_are_private_and_read_only(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);game=root/'ZeroHour';game.mkdir();base=root/'Generals';base.mkdir()
            objects=b'''Object ChinaTankBattleMaster
Draw = W3DModelDraw FixtureTag
DefaultConditionState
Model = Fixture
End
End
End
Object ChinaTankOverlord
End
'''
            name=b'FixturePaint.tga\x00'
            current=write_big({'Data/INI/Object/Reference.ini':objects,
                               'Art/W3D/Fixture.w3d':struct.pack('<II',0x32,len(name))+name})
            original=write_big({'Art/Textures/FixturePaint.tga':tga()})
            (game/'Fixture.big').write_bytes(current);(base/'Textures.big').write_bytes(original)
            report=inspect(game,root/'Private')
            self.assertEqual(report['textures'][0]['source_kind'],'archive')
            self.assertEqual(report['textures'][0]['archive_name'],'Textures.big')
            self.assertEqual(report['shared_sources'][0]['folder_name'],'Generals')
            loose=game/'Art/Textures/FixturePaint.tga';loose.parent.mkdir(parents=True)
            loose.write_bytes(tga()[:-6]+bytes([255,0,0])*2)
            report=inspect(game,root/'PrivateLoose')
            self.assertEqual(report['textures'][0]['source_kind'],'loose_file')
            self.assertEqual((root/'PrivateLoose/reference-1.png').read_bytes(),png(*decode_tga(loose.read_bytes())))
            self.assertEqual((base/'Textures.big').read_bytes(),original)
            self.assertEqual((game/'Fixture.big').read_bytes(),current)
            with self.assertRaisesRegex(ValueError,'outside'):
                inspect(game,base/'Private')

    def test_compound_model_filename_and_texture_only_candidates_are_labeled(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);game=root/'Game';game.mkdir()
            objects=b'''Object ChinaTankBattleMaster
Draw = W3DModelDraw FixtureTag
DefaultConditionState
Model = Fixture
End
End
End
Object ChinaTankOverlord
Draw = W3DModelDraw FixtureTag
DefaultConditionState
Model = Other
End
End
End
'''
            name=b'FixturePaint.tga\x00'
            files={'Data/INI/Object/Fixture.ini':objects,
                   'Art/W3D/Fixture_SKN.w3d':struct.pack('<II',0x32,len(name))+name,
                   'Art/Textures/FixturePaint.tga':tga(),
                   'Art/Textures/OtherPaint.tga':tga()}
            archive=game/'Fixture.big';original=write_big(files);archive.write_bytes(original)
            report=inspect(game,root/'Private')
            self.assertEqual(len(report['textures']),2)
            self.assertEqual(report['objects'][0]['model_discovery'],'filename_family_candidates')
            self.assertEqual(report['objects'][0]['model_source_paths'],['Art\\W3D\\Fixture_SKN.w3d'])
            self.assertEqual(report['objects'][0]['texture_discovery'],'w3d_texture_chunks')
            self.assertEqual(report['textures'][1]['discovery'],'filename_family_candidates')
            self.assertEqual(report['asset_counts'],{'w3d':1,'tga':2,'dds':0})
            self.assertEqual(archive.read_bytes(),original)

    def test_tga_raw_and_rle_preserve_color_and_orientation(self):
        self.assertEqual(decode_tga(tga()),(2,1,bytes([255,0,0,0,255,0])))
        data=bytearray(tga()[:18]);data[2]=10
        self.assertEqual(decode_tga(bytes(data)+b'\x81\x00\x00\xff'),(2,1,b'\xff\x00\x00'*2))
        with self.assertRaisesRegex(ValueError,'Truncated'):
            decode_tga(tga()[:-1])

    def test_dxt1_dxt3_dxt5_decode_top_mip_without_external_dependencies(self):
        for code in (b'DXT1',b'DXT3',b'DXT5'):
            header=bytearray(128);header[:4]=b'DDS '
            struct.pack_into('<I',header,4,124);struct.pack_into('<II',header,12,4,4)
            struct.pack_into('<I',header,80,4);header[84:88]=code
            block=(b'\xff'*8 if code!=b'DXT1' else b'')+struct.pack('<HHI',0xf800,0x07e0,0)
            self.assertEqual(decode_dds(bytes(header)+block),(4,4,b'\xff\x00\x00'*16))
            self.assertEqual(decode_private_dds(bytes(header)+block),(4,4,b'\xff\x00\x00'*16))
            with self.assertRaisesRegex(ValueError,'Truncated'):
                decode_dds(bytes(header)+block[:-1])

    def test_w3d_texture_names_and_png_roundtrip_payload(self):
        raw=b'fixture.tga\x00'
        child=struct.pack('<II',0x32,len(raw))+raw
        source=struct.pack('<II',0x30,0x80000000|len(child))+child
        self.assertEqual(texture_names(source),['fixture.tga'])
        image=png(2,1,b'\xff\x00\x00\x00\xff\x00')
        self.assertTrue(image.startswith(b'\x89PNG\r\n\x1a\n'))
        cursor=8
        while cursor<len(image):
            size=struct.unpack_from('>I',image,cursor)[0];kind=image[cursor+4:cursor+8]
            data=image[cursor+8:cursor+8+size]
            if kind==b'IDAT':
                self.assertEqual(zlib.decompress(data),b'\x00\xff\x00\x00\x00\xff\x00')
            cursor+=size+12

    def test_private_extraction_keeps_archive_unchanged_and_refuses_game_outputs(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);game=root/'Game';game.mkdir()
            fixture=invented_game_files()
            # A tiny independent reference object and texture index; no game art.
            for key in list(fixture):
                if key.lower().startswith('data/ini/object/'):
                    del fixture[key]
            fixture['Data/INI/Object/References.ini']=b'''Object ChinaTankBattleMaster
Draw = W3DModelDraw FixtureTag
DefaultConditionState
Model = Fixture
End
End
End
Object ChinaTankOverlord
End
'''
            name=b'fixture.tga\x00'
            fixture['Art/W3D/Fixture.w3d']=struct.pack('<II',0x32,len(name))+name
            fixture['Art/Textures/fixture.tga']=tga()
            original=write_big(fixture);archive=game/'Fixture.big';archive.write_bytes(original)
            output=root/'Private'
            report=inspect(game,output)
            self.assertEqual(len(report['textures']),1)
            self.assertTrue((output/'reference-1.png').exists())
            self.assertEqual(archive.read_bytes(),original)
            with self.assertRaisesRegex(ValueError,'exists'):
                inspect(game,output)
            with self.assertRaisesRegex(ValueError,'outside'):
                inspect(game,game/'Private')
            self.assertEqual(json.loads((output/'stock-visual-details.json').read_text())['textures'][0]['width'],2)
