"""Read compiled armor rather than trusting manifest/config promises."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import unittest

import test_project as fixtures
from uwmod.project import GameSource,compile_project
from uwmod.archive import write_big
from tools.inspect_tumbler_armor import diagnose


class TumblerArmorDiagnosticTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def test_reports_actual_armor_health_and_machinegun_damage_estimate(self):
        self.fixture['Data/INI/Weapon.ini']=self.fixture['Data/INI/Weapon.ini'].replace(b'Weapon FixtureHumveeGun\n',b'Weapon FixtureHumveeGun\n  DamageType = SMALL_ARMS\n')
        self.write_fixture();files,manifest=compile_project(GameSource(self.game),self.project)
        path=self.root/'ArmorCheck.big';path.write_bytes(write_big(files))
        manifest['archive_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        path.with_suffix('.manifest.json').write_text(json.dumps(manifest))
        data=diagnose(self.game,path)
        self.assertTrue(data['matches_build_checksum'])
        self.assertEqual(data['vehicle']['body']['MaxHealth'],['5000'])
        self.assertEqual(data['vehicle']['armor_sets'][0]['effective_percent']['SMALL_ARMS'],5)
        humvee=next(a for a in data['test_attackers'] if a['object']=='AmericaVehicleHumvee')
        shot=humvee['weapons'][0]['damage_estimates'][0]
        self.assertAlmostEqual(shot['estimated_primary_hp_damage'],.35)
        self.assertEqual(shot['estimated_hits_to_deplete_health'],14286)
        self.assertNotIn(str(self.game),json.dumps(data))
        self.assertFalse(data['native_loaded_archive_verified'])
        self.assert_original_unchanged()

    def test_actual_archive_overrides_manifest_claims_and_mutation_is_detected(self):
        files,manifest=compile_project(GameSource(self.game),self.project)
        target=self.root/'Mutated.big';target.write_bytes(write_big(files))
        manifest['archive_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
        target.with_suffix('.manifest.json').write_text(json.dumps(manifest))
        key='Data\\INI\\Armor.ini'
        files[key]=files[key].replace(b'Armor UWTumblerArmor0\n  Armor = DEFAULT 5%',b'Armor UWTumblerArmor0\n  Armor = DEFAULT 100%')
        target.write_bytes(write_big(files));data=diagnose(self.game,target)
        self.assertFalse(data['matches_build_checksum'])
        self.assertEqual(data['vehicle']['build_armor_policy'],'uniform')
        self.assertEqual(data['vehicle']['armor_sets'][0]['effective_percent']['GATTLING'],100)
        self.assertEqual(data['vehicle']['armor_sets'][0]['effective_percent']['SMALL_ARMS'],5)
        self.assert_original_unchanged()

    def test_cli_refuses_overwrite_and_game_report_paths(self):
        files,_=compile_project(GameSource(self.game),self.project)
        archive=self.root/'Authored.big';archive.write_bytes(write_big(files))
        script=Path(__file__).resolve().parents[1]/'tools/inspect_tumbler_armor.py'
        report=self.root/'ArmorReport.json'
        args=[sys.executable,str(script),'--game-dir',str(self.game),'--archive',str(archive),'--report',str(report)]
        result=subprocess.run(args,capture_output=True,text=True);self.assertEqual(result.returncode,0,result.stderr)
        original=report.read_bytes();repeat=subprocess.run(args,capture_output=True,text=True)
        self.assertNotEqual(repeat.returncode,0);self.assertEqual(original,report.read_bytes())
        args[-1]=str(self.game/'NoWrite.json');result=subprocess.run(args,capture_output=True,text=True)
        self.assertNotEqual(result.returncode,0);self.assertFalse((self.game/'NoWrite.json').exists())
        self.assert_original_unchanged()
