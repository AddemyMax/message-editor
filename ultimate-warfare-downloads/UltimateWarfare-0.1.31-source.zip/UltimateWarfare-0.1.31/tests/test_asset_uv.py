"""UV continuity checks for the authored exporter, not native rendering tests."""
import unittest

from tools.assets.generate_longma import Mesh


class SurfaceUvTests(unittest.TestCase):
    def test_prism_roof_samples_one_panel_across_all_fan_triangles(self):
        mesh = Mesh('Fixture', 0)
        ring = [(-2,-1),(2,-1),(2,1),(-2,1)]
        mesh.prism(ring, ring, 0, 2)
        by_position = {}
        for position, normal, uv in zip(mesh.vertices, mesh.normals, mesh.uvs):
            if normal[2] > .99:
                by_position.setdefault(position, set()).add(uv)
        # Shared roof vertices need the same UV in adjoining triangles; each
        # corner must occupy a different part of the panel instead of tiling
        # the entire texture over every triangle.
        self.assertEqual(len(by_position), 5)
        self.assertTrue(all(len(uvs)==1 for uvs in by_position.values()))
        self.assertEqual(len({next(iter(uvs)) for uvs in by_position.values()}), 5)

    def test_cylinder_wraps_once_instead_of_repeating_texture_per_facet(self):
        mesh = Mesh('Fixture', 0)
        mesh.cylinder((0,0,0), 1, 3, 'x', 8, 5)
        surface = [(p,uv) for p,n,uv in zip(mesh.vertices,mesh.normals,mesh.uvs) if abs(n[0])<.9]
        self.assertEqual(len(surface), 32)
        distinct_u = {round(uv[0],6) for _,uv in surface}
        self.assertEqual(len(distinct_u), 9)
