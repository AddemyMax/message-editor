"""Run with Blender --background --python tools/assets/render_longma.py.

SPDX-License-Identifier: MIT
Reconstructs the exact procedural mesh and UVs, saves editable .blend, renders
an honest asset preview (Blender lighting is not a preview of SAGE lighting).
"""
import json
import math
from pathlib import Path
import bpy
from mathutils import Vector


OUTPUT = Path(__file__).resolve().parents[2] / "assets/generated"
data = json.loads((OUTPUT / "uwlongma.mesh.json").read_text())
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
scene = bpy.context.scene
bpy.context.preferences.filepaths.save_version = 0
scene.render.engine = "CYCLES"
scene.cycles.samples = 48
# The cloud Blender build does not provide OpenImageDenoise. Native Cycles
# sampling is sufficient for this model; do not request unavailable denoising.
scene.cycles.use_denoising = False
scene.render.resolution_x = 1200
scene.render.resolution_y = 900
scene.render.resolution_percentage = 100
scene.world.color = (.045, .055, .068)
scene.view_settings.view_transform = "AgX"

material = bpy.data.materials.new("Longma original paint atlas")
material.use_nodes = True
principled = material.node_tree.nodes.get("Principled BSDF")
principled.inputs["Metallic"].default_value = .35
principled.inputs["Roughness"].default_value = .63
texture = material.node_tree.nodes.new("ShaderNodeTexImage")
texture.image = bpy.data.images.load(str(OUTPUT / "uwlongma.tga"))
material.node_tree.links.new(texture.outputs["Color"], principled.inputs["Base Color"])

bones = []
for bone in data["bones"]:
    obj = bpy.data.objects.new(bone["name"], None)
    scene.collection.objects.link(obj)
    if bone["parent"] >= 0:
        obj.parent = bones[bone["parent"]]
    obj.location = bone["translation"]
    obj.empty_display_type = "ARROWS"
    obj.empty_display_size = .7
    bones.append(obj)

for mesh in data["meshes"]:
    origin = mesh["origin"]
    verts = [[v[i] - origin[i] for i in range(3)] for v in mesh["vertices"]]
    geometry = bpy.data.meshes.new(mesh["name"])
    geometry.from_pydata(verts, [], mesh["triangles"])
    geometry.update()
    obj = bpy.data.objects.new(mesh["name"], geometry)
    scene.collection.objects.link(obj)
    obj.parent = bones[mesh["bone"]]
    obj.data.materials.append(material)
    uv_layer = geometry.uv_layers.new(name="Longma atlas")
    for loop in geometry.loops:
        uv_layer.data[loop.index].uv = mesh["uvs"][loop.vertex_index]
    obj["W3D_Model"] = data["model"]
    obj["Asset_License"] = "CC0-1.0"

# A preview stage is explicitly separate from exported gameplay geometry.
bpy.ops.mesh.primitive_plane_add(size=200, location=(0, 0, -.08))
floor = bpy.context.object
floor.name = "PREVIEW_ONLY_floor"
mat = bpy.data.materials.new("Preview ground")
mat.diffuse_color = (.035, .043, .052, 1.)
floor.data.materials.append(mat)


def point_at(obj, target):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def area(name, location, power, color, size):
    bpy.ops.object.light_add(type="AREA", location=location)
    light = bpy.context.object
    light.name = "PREVIEW_ONLY_" + name
    light.data.energy = power
    light.data.color = color
    light.data.shape = "DISK"
    light.data.size = size
    point_at(light, (0, 0, 3))


area("key", (18, -22, 35), 45000, (1., .9, .77), 18)
area("rim", (-15, 15, 22), 34000, (.61, .75, 1.), 15)
area("fill", (10, 22, 13), 20000, (.84, .93, 1.), 20)
bpy.ops.object.camera_add(location=(32, -38, 27))
camera = bpy.context.object
camera.name = "PREVIEW_ONLY_camera"
point_at(camera, (1., 0., 4.1))
camera.data.type = "ORTHO"
camera.data.ortho_scale = 34
scene.camera = camera
scene.render.image_settings.file_format = "PNG"
scene.render.filepath = str(OUTPUT / "uwlongma-preview.png")
# Packing guarantees the .blend has the authored atlas without external paths.
texture.image.pack()
bpy.ops.wm.save_as_mainfile(filepath=str(OUTPUT / "uwlongma.blend"))
bpy.ops.render.render(write_still=True)
