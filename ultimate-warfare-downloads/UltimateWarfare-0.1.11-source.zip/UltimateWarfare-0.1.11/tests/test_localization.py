"""All fixtures are authored here; no original game localization is included."""

import struct
import unittest

from tools.uwmod.localization import LocalizationError, append_labels, append_str_labels


def make_csf(records, *, version=3, reserved=0x01234567, language=4):
    """Independently construct documented CSF chunks and optional speech data."""
    payload = bytearray()
    pairs = 0
    for label, values in records:
        encoded_label = label if isinstance(label, bytes) else label.encode("ascii")
        payload.extend(b" LBL" + struct.pack("<II", len(values), len(encoded_label)) + encoded_label)
        for text, speech in values:
            units = text.encode("utf-16-le")
            payload.extend((b" RTS" if speech is None else b"WRTS") + struct.pack("<I", len(units) // 2))
            payload.extend(bytes(255 - value for value in units))
            if speech is not None:
                payload.extend(struct.pack("<I", len(speech)) + speech)
            pairs += 1
    return struct.pack("<4s5I", b" FSC", version, len(records), pairs, reserved, language) + bytes(payload)


def read_appended_record(blob, offset):
    """Decode one resulting record using the published reader's byte layout."""
    if blob[offset:offset + 4] != b" LBL":
        raise AssertionError("Label tag missing")
    pairs, label_size = struct.unpack_from("<II", blob, offset + 4)
    cursor = offset + 12
    label = blob[cursor:cursor + label_size].decode("ascii")
    cursor += label_size
    if blob[cursor:cursor + 4] != b" RTS":
        raise AssertionError("String tag missing")
    text_units = struct.unpack_from("<I", blob, cursor + 4)[0]
    cursor += 8
    encoded = blob[cursor:cursor + text_units * 2]
    text = bytes(255 - value for value in encoded).decode("utf-16-le")
    return label, pairs, text_units, text, cursor + text_units * 2


class CsfLocalizationTests(unittest.TestCase):
    def test_legacy_label_bytes_and_speech_are_preserved_without_decoding(self):
        source = make_csf([(b"TEST:\xc0\xe0\xff", [("Авторский текст", b"FixtureSpeech")])])
        output = append_labels(source, {"TEST:New": "new"})
        self.assertEqual(output[24:len(source)], source[24:])
        self.assertIs(append_labels(source, {}), source)
        self.assertEqual(struct.unpack_from("<II", output, 8), (2, 2))

    def test_high_label_bytes_do_not_use_unicode_case_folding(self):
        source = make_csf([(b"TEST:\xc0", [("Upper byte", None)]), (b"TEST:\xe0", [("Lower byte", None)])])
        self.assertIs(append_labels(source, {}), source)
        self.assertEqual(append_labels(source, {"TEST:New": "new"})[24:len(source)], source[24:])

    def test_native_label_bytes_do_not_relax_authored_label_or_nul_checks(self):
        source = make_csf([(b"TEST:\xc0", [("Fixture", None)])])
        with self.assertRaisesRegex(LocalizationError, "ASCII"):
            append_labels(source, {"TEST:Ж": "new"})
        invalid = make_csf([(b"TEST:A\x00Hidden", [("Fixture", None)])])
        with self.assertRaisesRegex(LocalizationError, "terminator"):
            append_labels(invalid, {})

    def setUp(self):
        self.source = make_csf([
            ("TEST:Existing", [("Synthetic original", b"OwnSpeech_01"), ("Other pair", None)]),
            ("TEST:Other", [("Second label", None)]),
        ])

    def test_preserves_all_source_records_and_header_metadata(self):
        output = append_labels(self.source, {"TEST:Added": "Authored new text"})
        self.assertEqual(output[:8], self.source[:8])
        self.assertEqual(output[16:24], self.source[16:24])
        self.assertEqual(output[24:len(self.source)], self.source[24:])
        self.assertEqual(struct.unpack_from("<II", output, 8), (3, 4))
        label, pairs, units, text, end = read_appended_record(output, len(self.source))
        self.assertEqual((label, pairs, units, text), ("TEST:Added", 1, 17, "Authored new text"))
        self.assertEqual(end, len(output))

    def test_v2_and_v3_keep_version_language_and_reserved_field(self):
        for version in (2, 3):
            source = make_csf([], version=version, language=8, reserved=1234)
            output = append_labels(source, {"TEST:New": "x"})
            self.assertEqual(struct.unpack_from("<5I", output, 4), (version, 1, 1, 1234, 8))

    def test_full_unicode_uses_utf16_units_not_python_character_count(self):
        output = append_labels(self.source, {"TEST:Added": "Ж😀"})
        label, pairs, units, text, end = read_appended_record(output, len(self.source))
        self.assertEqual((pairs, units, text, end), (1, 3, "Ж😀", len(output)))
        self.assertEqual(output[-6:], b"\xe9\xfb\xc2\x27\xff\x21")

    def test_empty_append_validates_and_preserves_exact_source(self):
        self.assertIs(append_labels(self.source, {}), self.source)

    def test_append_order_is_deterministic(self):
        first = append_labels(self.source, {"TEST:Z": "z", "TEST:A": "a"})
        second = append_labels(self.source, {"TEST:A": "a", "TEST:Z": "z"})
        self.assertEqual(first, second)

    def test_rejects_duplicate_existing_and_new_labels_case_insensitively(self):
        inputs = [
            (self.source, {"test:existing": "new"}),
            (self.source, {"TEST:A": "one", "test:a": "two"}),
            (make_csf([("TEST:A", [("one", None)]), ("test:a", [("two", None)])]), {}),
        ]
        for source, additions in inputs:
            with self.subTest(additions=additions), self.assertRaises(LocalizationError):
                append_labels(source, additions)

    def test_rejects_bad_counts_tags_version_and_trailing_bytes(self):
        bad_sources = [
            self.source[:23],
            b"CSF " + self.source[4:],
            make_csf([], version=1),
            self.source + b"trailing",
            self.source[:8] + struct.pack("<I", 1) + self.source[12:],
            self.source[:12] + struct.pack("<I", 2) + self.source[16:],
            self.source[:12] + struct.pack("<I", 4) + self.source[16:],
            self.source[:24] + b"BAD!" + self.source[28:],
            self.source.replace(b"WRTS", b"BAD!", 1),
        ]
        for source in bad_sources:
            with self.subTest(source=source[:24]), self.assertRaises(LocalizationError):
                append_labels(source, {})

    def test_rejects_every_truncated_nonempty_record(self):
        for size in range(24, len(self.source)):
            with self.subTest(size=size), self.assertRaises(LocalizationError):
                append_labels(self.source[:size], {})

    def test_rejects_invalid_unicode_and_original_reader_terminators(self):
        for text in ("a\x00b", "a\uffffb", "\ud800"):
            with self.subTest(text=repr(text)), self.assertRaises(LocalizationError):
                append_labels(self.source, {"TEST:New": text})
        source = make_csf([("TEST:Bad", [("\uffff", None)])])
        with self.assertRaises(LocalizationError):
            append_labels(source, {})

    def test_rejects_oversized_lengths_before_reading_or_allocating(self):
        label_length_offset = 32
        source = bytearray(self.source)
        struct.pack_into("<I", source, label_length_offset, 0xFFFFFFFF)
        with self.assertRaises(LocalizationError):
            append_labels(bytes(source), {})
        with self.assertRaises(LocalizationError):
            append_labels(self.source, {"TEST:New": "x" * 20480})


class StrLocalizationTests(unittest.TestCase):
    def setUp(self):
        self.source = b'// Authored fixture\r\nTEST:Existing\r\n"Own text \\"quoted\\"" = OwnSpeech\r\nEND\r\n'

    def test_append_keeps_complete_source_exactly_and_escapes_text(self):
        output = append_str_labels(self.source, {"TEST:Added": 'Build &Tank\nA "quote"\tC:\\path'})
        self.assertTrue(output.startswith(self.source))
        self.assertEqual(output[len(self.source):], b'\r\nTEST:Added\r\n"Build &Tank\\nA \\"quote\\"\\tC:\\\\path"\r\nEND\r\n')
        self.assertIs(append_str_labels(output, {}), output)

    def test_source_without_final_newline_is_separated(self):
        source = b'TEST:Existing\n"Owned fixture"\nEND'
        output = append_str_labels(source, {"TEST:Added": "new"})
        self.assertTrue(output.startswith(source + b"\n\nTEST:Added\n"))

    def test_multiline_original_quote_and_speech_tail_are_preserved(self):
        source = b'TEST:Existing\n"Own multiline\nEND is text\nmore \\"quoted\\"" = Sound_1\nEND\n'
        output = append_str_labels(source, {"TEST:Added": "new"})
        self.assertTrue(output.startswith(source))
        self.assertIs(append_str_labels(output, {}), output)

    def test_duplicates_and_incomplete_original_blocks_are_rejected(self):
        inputs = [
            (self.source, {"test:existing": "new"}),
            (self.source, {"TEST:A": "one", "test:a": "two"}),
            (b'TEST:A\n"one"\nEND\ntest:a\n"two"\nEND\n', {}),
            (b'TEST:A\n"value"\n', {}),
            (b'TEST:A\nEND\n', {}),
            (b'TEST:A\n"unterminated\nEND\n', {}),
            (b'TEST:A\n"one"\n"two"\nEND\n', {}),
        ]
        for source, additions in inputs:
            with self.subTest(source=source), self.assertRaises(LocalizationError):
                append_str_labels(source, additions)

    def test_str_rejects_utf8_unicode_escapes_are_not_an_encoding_workaround(self):
        for text in ("Танк", "😀", "\xff", "\r", "\x00"):
            with self.subTest(text=repr(text)), self.assertRaises(LocalizationError):
                append_str_labels(self.source, {"TEST:New": text})
        output = append_str_labels(self.source, {"TEST:New": "Caf\xe9"})
        self.assertIn(b'"Caf\xe9"', output)

    def test_rejects_bom_nul_bad_labels_and_excessive_lines(self):
        for source in (b"\xef\xbb\xbf" + self.source, b"\xff\xfe" + self.source, self.source + b"\x00", b"a" * 10240):
            with self.subTest(source=source[:5]), self.assertRaises(LocalizationError):
                append_str_labels(source, {})
        for label in ("", "END", "TEST:with space", "ТЕСТ:New", "//comment"):
            with self.subTest(label=label), self.assertRaises(LocalizationError):
                append_str_labels(self.source, {label: "new"})


if __name__ == "__main__":
    unittest.main()
