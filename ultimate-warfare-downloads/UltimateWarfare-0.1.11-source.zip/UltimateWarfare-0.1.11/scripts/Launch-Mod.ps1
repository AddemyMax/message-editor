[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$GameDir,

    [string]$Archive
)

$ErrorActionPreference = 'Stop'

function Find-Python {
    foreach ($candidate in @('py', 'python', 'python3')) {
        $commands = @(Get-Command $candidate -CommandType Application -All -ErrorAction SilentlyContinue)
        foreach ($command in $commands) {
            # Windows App Execution Aliases may open the Store instead of Python.
            if ($command.Source -match '[\\/]Microsoft[\\/]WindowsApps[\\/]python(?:3(?:\.\d+)?)?\.exe$') {
                continue
            }
            $prefix = @()
            if ($candidate -eq 'py') { $prefix = @('-3') }
            try {
                $version = & $command.Source @prefix -c 'import sys; print(str(sys.version_info.major) + chr(46) + str(sys.version_info.minor)); sys.exit(0 if sys.version_info >= (3, 10) else 1)'
                $versionExitCode = $LASTEXITCODE
                if ($versionExitCode -eq 0) {
                    return [pscustomobject]@{ Path = $command.Source; Prefix = $prefix }
                }
            } catch {
                # Continue if a launcher has no interpreter or an executable fails.
            }
        }
    }
    throw 'Python 3.10 or newer is required for the pre-launch archive and collision check.'
}

try {
    if (-not (Test-Path -LiteralPath $GameDir -PathType Container)) {
        throw "Game directory does not exist: $GameDir"
    }
    $resolvedGameDir = (Resolve-Path -LiteralPath $GameDir).ProviderPath
    $gameExe = Join-Path $resolvedGameDir 'generals.exe'
    if (-not (Test-Path -LiteralPath $gameExe -PathType Leaf)) {
        throw "Zero Hour generals.exe was not found: $gameExe"
    }
    $projectDir = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
    if ([string]::IsNullOrWhiteSpace($Archive)) {
        $Archive = Join-Path $projectDir 'dist\UltimateWarfare.big'
    }
    if (-not (Test-Path -LiteralPath $Archive -PathType Leaf)) {
        throw "Mod archive does not exist: $Archive. Run Build-Mod.ps1 first."
    }
    $resolvedArchive = (Resolve-Path -LiteralPath $Archive).ProviderPath
    if ([System.IO.Path]::GetExtension($resolvedArchive) -ine '.big') {
        throw 'The mod archive must have the .big extension.'
    }

    $python = Find-Python
    $pythonPath = $python.Path
    $prefix = @($python.Prefix)
    $builder = Join-Path $projectDir 'tools\build_mod.py'
    & $pythonPath @prefix $builder check-launch --game-dir $resolvedGameDir --archive $resolvedArchive
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    # Zero Hour resolves relative -mod paths under its user-data directory.
    # Use a quoted absolute archive path and the installation as working directory.
    $arguments = '-mod "{0}"' -f $resolvedArchive
    $process = Start-Process -FilePath $gameExe -WorkingDirectory $resolvedGameDir -ArgumentList $arguments -PassThru
    Write-Host "Zero Hour started with $resolvedArchive (process $($process.Id))."
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
