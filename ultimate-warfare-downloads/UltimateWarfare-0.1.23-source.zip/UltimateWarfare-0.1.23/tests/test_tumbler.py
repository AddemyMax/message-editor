"""Second-unit integration and binary checks against authored fixtures only."""
import json
from pathlib import Path
import struct
import sys
import unittest

import test_project as fixtures
PROJECT = fixtures.PROJECT
from uwmod.project import GameSource, compile_project, validate_archive, BuildError
from uwmod.ini import parse_ini
from uwmod.archive import write_big
from assets.validate_w3d import validate


class TumblerTests(unittest.TestCase):
    setUp = fixtures.ProjectIntegrationTests.setUp
    write_fixture = fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged = fixtures.ProjectIntegrationTests.assert_original_unchanged

    def compile(self):
        return compile_project(GameSource(self.game), self.project)

    def test_exact_stock_stats_and_usa_factory_without_chinese_attachments(self):
        source = GameSource(self.game)
        stock_raw, path = source.find_object('ChinaTankOverlord')
        stock, = parse_ini(stock_raw).blocks
        files, report = self.compile()
        raw = files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']
        obj, = parse_ini(raw).blocks
        for kind in ('body', 'armorset'):
            self.assertEqual([parse_ini(stock_raw).source(c) for c in stock.children if c.kind.lower()==kind],
                             [parse_ini(raw).source(c) for c in obj.children if c.kind.lower()==kind])
        for key in ('BuildCost', 'BuildTime'):
            self.assertEqual([f.value for f in obj.find_fields(key)], [f.value for f in stock.find_fields(key)])
        self.assertEqual(obj.find_fields('Side')[0].value, 'America')
        self.assertEqual(obj.find_fields('Shadow')[0].value, 'SHADOW_DECAL')
        prereq=next(c for c in obj.children if c.kind.lower()=='prerequisites')
        self.assertEqual(prereq.find_fields('Object')[0].value,'AmericaStrategyCenter')
        self.assertNotIn(b'OverlordContain',raw)
        ai=next(c for c in obj.children if c.kind.lower()=='behavior' and 'AIUpdate' in c.value)
        turret=next(c for c in ai.children if c.kind.lower()=='turret')
        self.assertEqual(turret.find_fields('ControlledWeaponSlots')[0].value,'SECONDARY')
        commands=parse_ini(files['Data\\INI\\CommandSet.ini']).find_block('CommandSet','UWTumblerCommandSet')
        self.assertEqual([f.value for f in commands.fields],['Command_FixtureStop','Command_FixtureGuard','Command_UWTumblerSmoke'])
        self.assertEqual(report['units'][1]['health'],1375)
        self.assertEqual(report['units'][1]['cost'],2137)
        self.assertNotIn(path.replace('/','\\'),files)
        self.assert_original_unchanged()

    def test_humvee_speeds_are_private_and_other_locomotor_fields_unchanged(self):
        files, report = self.compile()
        doc = parse_ini(files['Data\\INI\\Locomotor.ini'])
        mapping = report['units'][1]['locomotors']
        self.assertEqual(report['units'][1]['speed_reference']['object'], 'AmericaVehicleHumvee')
        original = parse_ini(self.fixture['Data/INI/Locomotor.ini'])
        for old, new in mapping.items():
            self.assertNotEqual(old, new)
            clone = doc.find_block('Locomotor', new)
            self.assertEqual(clone.find_fields('Speed')[0].value, '63')
            self.assertEqual(clone.find_fields('SpeedDamaged')[0].value, '41')
            before = original.find_block('Locomotor', old)
            self.assertEqual(original.source(before), doc.source(doc.find_block('Locomotor', old)))
            self.assertEqual([(f.key, f.value) for f in before.fields if f.key not in ('Speed','SpeedDamaged')],
                             [(f.key, f.value) for f in clone.fields if f.key not in ('Speed','SpeedDamaged')])
        self.assert_original_unchanged()

    def test_paladin_size_scales_model_collision_and_decal_together(self):
        files, report = self.compile()
        obj, = parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        unit = report['units'][1]
        self.assertGreater(unit['model_scale'], 1)
        self.assertAlmostEqual(unit['geometry']['minor_radius'], 11)
        self.assertGreaterEqual(unit['geometry']['major_radius'], 15.4)
        self.assertAlmostEqual(float(obj.find_fields('Scale')[0].value), unit['model_scale'], places=5)
        self.assertAlmostEqual(float(obj.find_fields('ShadowSizeX')[0].value), 32*unit['model_scale'], places=4)
        # A different installed Paladin is measured, not guessed from fixed numbers.
        path='Data/INI/Object/FixtureSource.ini'
        self.fixture[path]=self.fixture[path].replace(b'GeometryMajorRadius = 14',b'GeometryMajorRadius = 20')
        self.write_fixture()
        _, larger = self.compile()
        self.assertAlmostEqual(larger['units'][1]['geometry']['major_radius'],22)
        self.assertGreater(larger['units'][1]['model_scale'],unit['model_scale'])
        self.assert_original_unchanged()

    def test_full_usa_factory_uses_visible_slot15_and_preserves_every_original_slot(self):
        from test_interface import authored_panel
        key='Data/INI/CommandSet.ini'; original=self.fixture[key]
        block=parse_ini(original).find_block('CommandSet','FixtureUSAFactory')
        replacement=b'CommandSet FixtureUSAFactory\n'+b''.join(f'  {i} = Command_USAKeep{i}\n'.encode() for i in range(1,15))+b'End\n'
        self.fixture[key]=original[:block.start]+replacement+original[block.end:]
        self.fixture['Window/ControlBar.wnd']=authored_panel(); self.write_fixture()
        files, report=self.compile()
        self.assertEqual(report['units'][1]['production_slot'],15)
        block=parse_ini(files['Data\\INI\\CommandSet.ini']).find_block('CommandSet','FixtureUSAFactory')
        self.assertEqual({f.key:f.value for f in block.fields if f.key!='15'},
                         {str(i):f'Command_USAKeep{i}' for i in range(1,15)})
        big=self.root/'Tumbler.big'; big.write_bytes(write_big(files))
        self.assertEqual(validate_archive(big)['models'],['UWLONGMA','UWSMKGREN','UWTUMBLER'])
        del files['Window\\ControlBar.wnd']; big.write_bytes(write_big(files))
        with self.assertRaisesRegex(BuildError,'lacks its control bar'): validate_archive(big)
        self.assert_original_unchanged()

    def test_tumbler_catalog_can_build_without_longma(self):
        path=self.project/'content/catalog.json'; value=json.loads(path.read_text())
        value['units']=['units/tumbler.json']; path.write_text(json.dumps(value))
        files, report=self.compile()
        self.assertEqual(len(report['units']),1)
        self.assertFalse(any('uwlongma' in k.lower() for k in files))
        big=self.root/'OnlyTumbler.big'; big.write_bytes(write_big(files))
        self.assertEqual(set(validate_archive(big)['objects']),{'AmericaVehicleUWTumbler','UWTumblerSmokeGrenade','UWTumblerSmokeCloud'})

    def test_missing_tire_binding_fails_validation(self):
        files,_=self.compile();key='Data\\INI\\Object\\AmericaVehicleUWTumbler.ini'
        files[key]=files[key].replace(b'WHEEL_FL',b'NONEXISTENT')
        big=self.root/'MissingBone.big';big.write_bytes(write_big(files))
        with self.assertRaisesRegex(BuildError,'missing tire bone'):validate_archive(big)

    def test_exported_wheels_bind_to_correct_pivots_and_muzzles_have_distinct_positions(self):
        result=validate(PROJECT/'assets/generated/uwtumbler.w3d')
        self.assertEqual(len(result['meshes']),11)
        self.assertEqual(len(result['bones']),13)
        self.assertEqual(result['bones'][7:9],['MUZZLE01','MUZZLE02'])
        self.assertNotEqual(result['bone_world_positions'][7],result['bone_world_positions'][8])
        from assets.validate_w3d import chunks,one,name
        top=chunks((PROJECT/'assets/generated/uwtumbler.w3d').read_bytes())
        lod=one(one(top,0x700),0x702)
        bindings={name(raw_name):bone for cid,p in lod if cid==0x704 for bone,raw_name in [struct.unpack('<I32s',p)]}
        for i in range(6):self.assertEqual(bindings['UWTUMBLER.TIRE'+str(i)],i+1)

if __name__=='__main__':unittest.main()
