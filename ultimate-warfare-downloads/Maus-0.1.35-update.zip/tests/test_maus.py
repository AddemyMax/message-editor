"""Maus uses an original mesh and otherwise exact local Crusader statistics."""
import json
from pathlib import Path
import unittest

import test_project as fixtures
from uwmod.project import GameSource,compile_project,validate_archive,BuildError
from uwmod.ini import parse_ini,IniError
from uwmod.archive import write_big
from assets.validate_w3d import validate


class MausTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def test_every_nonvisual_field_and_module_matches_local_crusader(self):
        source=GameSource(self.game);raw,path=source.find_object('AmericaTankCrusader')
        original,=parse_ini(raw).blocks
        files,report=compile_project(source,self.project)
        current_raw=files['Data\\INI\\Object\\AmericaTankUWMaus.ini'];current,=parse_ini(current_raw).blocks
        visual={'displayname','selectportrait','buttonimage','shadow','shadowsizex','shadowsizey','shadowtexture','scale','geometry','geometrymajorradius','geometryminorradius','geometryheight','geometryissmall'}
        fields=lambda obj:[(f.key,f.value) for f in obj.fields if f.key.lower() not in visual]
        self.assertEqual(fields(original),fields(current))
        self.assertEqual([raw[c.start:c.end] for c in original.children if c.kind.lower()!='draw'],
                         [current_raw[c.start:c.end] for c in current.children if c.kind.lower()!='draw'])
        item=report['units'][3];self.assertEqual(item['reference_object'],'AmericaTankCrusader')
        self.assertEqual(item['health'],1375);self.assertEqual(item['cost'],2137)
        self.assertNotIn(path.replace('/','\\'),files)
        self.assertEqual(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini'].count(b'MaxHealth = 4000'),1)
        self.assert_original_unchanged()

    def test_different_source_health_cost_weapons_armor_and_upgrades_are_retained(self):
        key='Data/INI/Object/FixtureSource.ini';raw=self.fixture[key]
        doc=parse_ini(raw);donor=doc.find_block('Object','AmericaTankCrusader')
        changed=doc.source(donor).replace(b'1375',b'825').replace(b'2137',b'999')
        changed=changed.replace(b'  Side = America',b'  Behavior = MaxHealthUpgrade FixtureUpgrade\n    TriggeredBy = FixtureCrusaderUpgrade\n    AddMaxHealth = 125\n  End\n  Prerequisites\n    Object = AmericaWarFactory\n  End\n  Side = America')
        self.fixture[key]=raw[:donor.start]+changed+raw[donor.end:];self.write_fixture()
        files,report=compile_project(GameSource(self.game),self.project)
        new=files['Data\\INI\\Object\\AmericaTankUWMaus.ini']
        self.assertIn(b'TriggeredBy = FixtureCrusaderUpgrade',new);self.assertIn(b'Object = AmericaWarFactory',new)
        self.assertIn(b'Armor = FixtureArmor',new);self.assertIn(b'Weapon = PRIMARY FixtureGun',new)
        self.assertEqual(report['units'][3]['health'],825);self.assertEqual(report['units'][3]['cost'],999)
        self.assert_original_unchanged()

    def test_full_usa_factory_keeps_fourteen_original_slots_and_uses_visible_sixteen(self):
        from test_interface import authored_panel
        key='Data/INI/CommandSet.ini';raw=self.fixture[key];block=parse_ini(raw).find_block('CommandSet','FixtureUSAFactory')
        full=b'CommandSet FixtureUSAFactory\n'+b''.join(f'  {i} = Command_USAKeep{i}\n'.encode() for i in range(1,15))+b'End\n'
        self.fixture[key]=raw[:block.start]+full+raw[block.end:]
        self.fixture['Window/ControlBar.wnd']=authored_panel();self.write_fixture()
        files,report=compile_project(GameSource(self.game),self.project)
        commands=parse_ini(files['Data\\INI\\CommandSet.ini']).find_block('CommandSet','FixtureUSAFactory')
        values={f.key:f.value for f in commands.fields}
        for i in range(1,15):self.assertEqual(values[str(i)],f'Command_USAKeep{i}')
        self.assertEqual(values['15'],'Command_ConstructUWTumbler');self.assertEqual(values['16'],'Command_ConstructUWMaus')
        self.assertEqual(report['units'][3]['production_slot'],16)
        big=self.root/'Maus.big';big.write_bytes(write_big(files));validate_archive(big)
        self.assert_original_unchanged()

    def test_no_slot_is_freed_by_replacing_an_original_command(self):
        from test_interface import authored_panel
        key='Data/INI/CommandSet.ini';raw=self.fixture[key];block=parse_ini(raw).find_block('CommandSet','FixtureUSAFactory')
        full=b'CommandSet FixtureUSAFactory\n'+b''.join(f'  {i} = Command_USAKeep{i}\n'.encode() for i in range(1,17))+b'End\n'
        self.fixture[key]=raw[:block.start]+full+raw[block.end:]
        self.fixture['Window/ControlBar.wnd']=authored_panel();self.write_fixture()
        with self.assertRaises(IniError):compile_project(GameSource(self.game),self.project)
        self.assert_original_unchanged()

    def test_model_pitch_recoil_muzzle_and_scrolling_treads_have_native_contracts(self):
        result=validate(fixtures.PROJECT/'assets/generated/uwmaus.w3d')
        self.assertEqual(result['bones'],['ROOTTRANSFORM','TURRET','GUN_PITCH','GUN_RECOIL','MUZZLE01'])
        muzzle=result['bone_world_positions'][-1]
        self.assertAlmostEqual(muzzle[0],12.805,places=4);self.assertAlmostEqual(muzzle[2],5.6,places=4)
        self.assertIn('UWMAUS.TREADSL',result['meshes']);self.assertIn('UWMAUS.TREADSR',result['meshes'])
        files,_=compile_project(GameSource(self.game),self.project)
        for absent in ('Art\\Textures\\uwmatread.tga','Art\\W3D\\uwmaus.w3d'):
            changed=dict(files);del changed[absent];big=self.root/'MissingMausAsset.big';big.write_bytes(write_big(changed))
            with self.assertRaises(BuildError):validate_archive(big)

    def test_scale_tracks_actual_overlord_model_and_reference_scale(self):
        from uwmod.kitbash import verify_dependencies
        files,report=compile_project(GameSource(self.game),self.project)
        size=report['units'][3]['visual_size']
        self.assertTrue(all(r>=1.9-1e-8 for r in size['actual_horizontal_ratios']))
        # Even though Cementaur and Maus read the same donor model, launch
        # dependency records must be de-duplicated and verifiable.
        verify_dependencies(GameSource(self.game),report['model_sources'])
        raw=self.fixture['Data/INI/Object/FixtureSource.ini'];doc=parse_ini(raw)
        donor=doc.find_block('Object','ChinaTankOverlord')
        changed=doc.source(donor).replace(b'Object ChinaTankOverlord\n',b'Object ChinaTankOverlord\n  Scale = 2\n')
        self.fixture['Data/INI/Object/FixtureSource.ini']=raw[:donor.start]+changed+raw[donor.end:]
        self.write_fixture();larger,updated=compile_project(GameSource(self.game),self.project)
        newsize=updated['units'][3]['visual_size']
        self.assertAlmostEqual(newsize['model_scale'],size['model_scale']*2)
        self.assertAlmostEqual(newsize['geometry']['minor_radius'],size['geometry']['minor_radius']*2)
        self.assertEqual(updated['units'][3]['health'],report['units'][3]['health'])
        self.assert_original_unchanged()

    def test_existing_unit_definitions_are_unchanged_when_maus_is_added(self):
        files,_=compile_project(GameSource(self.game),self.project)
        catalog=self.project/'content/catalog.json';value=json.loads(catalog.read_text());value['units'].remove('units/maus.json');catalog.write_text(json.dumps(value))
        before,_=compile_project(GameSource(self.game),self.project)
        for key,data in before.items():
            if key.startswith('Data\\INI\\Object\\'):
                self.assertEqual(files[key],data,key)
        self.assert_original_unchanged()
