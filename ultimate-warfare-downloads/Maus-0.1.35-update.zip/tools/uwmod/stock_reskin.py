"""Authored tank visuals on an otherwise unchanged local stock Object."""
from .ini import parse_ini, patch_command_set, IniError
from .interface import compact_production_panel


def compile_reskin(source, spec, output, files, project):
    from .project import _rename, _edit, _fields, _scalar, _newline, BuildError
    seed, source_path = source.find_object(spec['source_object'])
    factory, factory_path = source.find_object(spec['production_object'])
    if spec['id'].lower() in source.object_names:
        raise BuildError('New object already exists in installed game: '+spec['id'])
    factory_block, = parse_ini(factory).blocks
    commands = _scalar(factory_block, 'CommandSet')
    try:
        patch = patch_command_set(output['CommandSet'], commands, spec['button'])
    except IniError as exc:
        if str(exc) != 'No free production slot 1..12; original commands were preserved':
            raise
        patch = patch_command_set(output['CommandSet'], commands, spec['button'], slots=(15,16))
        # Rebuild from the original layout, also retaining any earlier slot15.
        files['Window\\ControlBar.wnd'] = compact_production_panel(source.read('Window\\ControlBar.wnd'), slots=(15,16))
    output['CommandSet'] = patch.data
    clone = _rename(seed, 'Object', spec['id'])
    body, = parse_ini(clone).blocks
    draws = [c for c in body.children if c.kind.lower() == 'draw']
    if not draws:
        raise BuildError('Reference tank requires a Draw module')
    # Preserve the complete original CommandSet, prerequisites, AI/turret,
    # upgrades, weapons, armor, Body, locomotors and economy. Geometry is
    # preserved by default; explicit visual sizing below also adjusts collision.
    source_commands = _scalar(body, 'CommandSet')
    parse_ini(output['CommandSet']).find_block('CommandSet', source_commands)
    draw = f'''  Draw = W3DTankDraw UWMausDraw
    OkToChangeModelColor = Yes
    DefaultConditionState
      Model = {spec['model']}
      Turret = TURRET
      TurretPitch = GUN_PITCH
      WeaponRecoilBone = PRIMARY GUN_RECOIL
      WeaponFireFXBone = PRIMARY MUZZLE
      WeaponLaunchBone = PRIMARY MUZZLE
    End
    ConditionState = RUBBLE
      Model = NONE
    End
'''
    # Retain local Crusader dust/track tuning, without model-specific bones.
    safe = {'trackmarks','treadanimationrate','treadpivotspeedfraction',
            'treaddrivespeedfraction','treaddebrisleft','treaddebrisright',
            'dust','dirtspray','powerslidespray'}
    for field in draws[0].fields:
        if field.key.lower() in safe:
            draw += f'    {field.key} = {field.value}\n'
    draw += '  End\n'
    clone = _edit(clone, [(d.start,d.end,draw.encode('ascii').replace(b'\n',_newline(clone)) if i==0 else b'')
                          for i,d in enumerate(draws)])
    body, = parse_ini(clone).blocks
    # Decal shadows avoid the known classic W3D volumetric-shadow buffer limit.
    clone = _fields(clone,body,{'DisplayName':spec['display_label'],
        'SelectPortrait':spec['image'],'ButtonImage':spec['image'],
        'Shadow':'SHADOW_DECAL','ShadowSizeX':'30','ShadowSizeY':'18','ShadowTexture':'shadow'})
    size_report=None;model_sources=[]
    if spec.get('visual_reference_object'):
        from .vehicle_size import size_like_reference
        fields,size_report,model_sources=size_like_reference(source,spec,project)
        body,=parse_ini(clone).blocks
        clone=_fields(clone,body,fields)
    path = f"Data\\INI\\Object\\{spec['id']}.ini"
    if path.lower() in source.entries or path in files:
        raise BuildError('New object path already exists: '+path)
    files[path] = clone
    bodies = [c for c in body.children if c.kind.lower()=='body']
    if len(bodies)!=1:
        raise BuildError('Reference tank requires one Body')
    return {'id':spec['id'],'profile':'stock_reskin','reference_object':spec['source_object'],
        'factory':spec['production_object'],'command_set':commands,'unit_command_set':source_commands,
        'production_slot':patch.slot,'source_object_file':source_path,'source_factory_file':factory_path,
        'health':float(_scalar(bodies[0],'MaxHealth')),'cost':float(_scalar(body,'BuildCost')),
        'build_seconds':float(_scalar(body,'BuildTime')),
        'visual_size':size_report,'model_sources':model_sources,
        'statistics_policy':'original stock combat/economy/AI/upgrade values; authored visuals and optional size/collision'}
