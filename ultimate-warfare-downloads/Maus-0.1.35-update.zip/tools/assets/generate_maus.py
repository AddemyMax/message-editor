#!/usr/bin/env python3
"""Authored Panzer VIII Maus interpretation; no third-party mesh or texture.

Code MIT; generated artwork CC0-1.0. +X forward, +Z up.
"""
import json
import math
from pathlib import Path
import struct
from generate_longma import Mesh,w3d,cameo_tga,chunk,container

OUTPUT=Path(__file__).resolve().parents[2]/'assets/generated'
BONES=[('ROOTTRANSFORM',-1,(0.,0.,0.)),('TURRET',0,(-1.4,0.,4.17)),
       ('GUN_PITCH',1,(4.75,0.,1.43)),('GUN_RECOIL',2,(0.,0.,0.)),
       ('MUZZLE01',3,(9.455,-.55,0.))]
ORIGINS=[]
for _,parent,pos in BONES:
    ORIGINS.append(tuple(v+(ORIGINS[parent][i] if parent>=0 else 0) for i,v in enumerate(pos)))


def vehicle():
    hull=Mesh('HULL',0);turret=Mesh('TURRET_BODY',1);gun=Mesh('GUNS',3)
    color=Mesh('HOUSECOLOR',0)
    # Reference silhouette: broad uninterrupted hull sides, sloping glacis,
    # low rear-set turret and many small road wheels below deep armor skirts.
    hull.prism([(-8.3,-4.35),(8.55,-4.35),(8.55,4.35),(-8.3,4.35)],
               [(-7.65,-4.35),(6.25,-4.35),(6.25,4.35),(-7.65,4.35)],1.25,3.85,0)
    hull.box((-.2,0,3.92),(12.7,8.5,.16),1)
    hull.cylinder((-1.4,0,4.12),3.32,.18,'z',32,5)
    for side in (-1,1):
        # One heavy skirt per side, rather than a row of small modern panels.
        ring=[(-8.05,side*4.20),(7.05,side*4.20),(8.0,side*5.10),(-8.1,side*5.10)]
        top=[(-7.65,side*4.20),(6.7,side*4.20),(7.35,side*5.02),(-7.7,side*5.02)]
        if side<0:ring.reverse();top.reverse()
        hull.prism(ring,top,1.43,3.83,0)
        hull.box((-.25,side*5.15,3.82),(14.4,.08,.10),5)
        hull.box((-.1,side*5.15,1.56),(14.8,.08,.08),5)
        for x in (-7.5,6.9):
            hull.cylinder((x,side*5.17,3.45),.13,.06,'y',8,5)
        # Engine deck, removable covers and dark ventilation grilles.
        for y in (1.1,2.8):
            hull.box((-6.35,side*y,4.08),(2.5,1.35,.14),8)
            for x in (-7.3,-6.9,-6.5,-6.1,-5.7,-5.3):
                hull.box((x,side*y,4.18),(.12,1.15,.09),5)
        hull.box((4.85,side*1.05,3.99),(1.20,1.15,.12),1)
        hull.box((4.85,side*1.05,4.10),(.55,.07,.08),5)
        for x in (-7.95,7.90):
            hull.cylinder((x,side*3.3,1.62),.23,.30,'y',10,5)
        hull.box((6.7,side*3.75,3.42),(.28,.40,.45),5,roll=.35)
        hull.cylinder((6.93,side*3.75,3.48),.13,.07,'x',10,11)
        # Small color tabs retain ownership readability without blue side bars.
        color.box((-6.9,side*4.86,3.91),(.85,.22,.05),10)
        hull.box((-8.30,side*3.1,3.15),(.12,.38,.16),15)
    # A single continuous upper glacis and lower front plate, with tow eyes.
    hull.box((8.57,0,1.35),(.12,6.85,.36),2)
    for y in (-2.8,2.8):hull.box((8.62,y,1.6),(.25,.35,.65),5)
    # Sloping turret rear and lower roof, followed by a genuinely rounded front
    # armor plate. It is not the old high box with a full cylinder pasted on.
    turret.prism([(-5.8,-3.55),(3.35,-3.10),(3.35,3.10),(-5.8,3.55)],
                 [(-4.55,-3.08),(3.35,-3.10),(3.35,3.10),(-4.55,3.08)],4.22,6.98,0)
    arc=[]
    for i in range(17):
        angle=-math.pi/2+i*math.pi/16
        arc.append((3.35+.78*math.cos(angle),5.60+1.38*math.sin(angle)))
    for i in range(len(arc)-1):
        x,z=arc[i];xx,zz=arc[i+1]
        turret.face([(x,-3.11,z),(x,3.11,z),(xx,3.11,zz),(xx,-3.11,zz)],1,
                    uv=[(i/16,0),(i/16,1),((i+1)/16,1),((i+1)/16,0)])
    for side in (-1,1):
        points=[(x,side*3.11,z) for x,z in arc]
        if side>0:points.reverse()
        turret.face(points,0,uv=[((x-3.35)/.78,(z-4.22)/2.76) for x,_,z in points])
        # Thin weld beads at the curved plate seam and recessed pistol ports.
        turret.box((2.98,side*3.13,5.62),(.07,.07,2.25),5,roll=.02)
        turret.cylinder((-1.85,side*3.35,5.52),.17,.08,'y',12,5)
        turret.cylinder((-1.85,side*3.41,5.52),.09,.04,'y',10,7)
        for x in (-3.8,.6):
            turret.box((x,side*3.25,6.68),(.55,.10,.07),5)
        turret.box((-1.0,side*3.34,4.45),(6.4,.06,.06),5)
    # Low roof hatches and periscopes match the reference instead of tall cups.
    for x,y,r in ((-2.9,-.7,.78),(-.35,.95,.66)):
        turret.cylinder((x,y,7.01),r,.09,'z',24,1)
        turret.box((x,y,7.08),(.60,.07,.05),5)
    for x,y in ((-3.55,-.7),(-2.25,-.7),(-2.9,-1.32),(-2.9,-.08)):
        turret.box((x,y,7.10),(.20,.15,.12),5)
    turret.box((1.1,-1.4,7.05),(.45,.70,.12),2)
    turret.box((1.1,-1.4,7.14),(.30,.45,.10),3)
    # The long main barrel has a plain, open muzzle. Smaller coaxial tube is
    # decorative only; no extra weapon is installed in the object definition.
    gun.cylinder((4.6,-.55,5.60),.43,1.15,'x',24,1)
    gun.cylinder((8.45,-.55,5.60),.25,8.45,'x',20,2)
    gun.cylinder((12.68,-.55,5.60),.27,.15,'x',20,5)
    gun.cylinder((12.78,-.55,5.60),.20,.05,'x',20,7)
    gun.cylinder((5.55,1.,5.60),.13,3.9,'x',16,2)
    gun.cylinder((7.54,1.,5.60),.15,.09,'x',16,7)
    # Circular bolts around both gun mounts are part of the recoiling assembly.
    for y,r in ((-.55,.68),(1.,.36)):
        for i in range(8):
            a=i*math.tau/8
            gun.cylinder((4.13,y+r*math.cos(a),5.60+r*math.sin(a)),.055,.08,'x',6,5)
    tracks=[]
    for side in (-1,1):
        tread=Mesh('TREADSL' if side<0 else 'TREADSR',0)
        profile=[(-8.2,1.15),(-7.2,.18),(6.9,.18),(8.35,1.32),(8.35,2.6),(7.25,3.12),(-7.25,3.12),(-8.2,2.55)]
        for i,(x,z) in enumerate(profile):
            xx,zz=profile[(i+1)%len(profile)];u0=i/len(profile);u1=(i+1)/len(profile)
            points=[(x,side*3.75,z),(xx,side*3.75,zz),(xx,side*5.15,zz),(x,side*5.15,z)]
            uv=[(u0,0),(u1,0),(u1,1),(u0,1)]
            if side>0:points.reverse();uv=[(1-u,v) for u,v in reversed(uv)]
            tread.face(points,uv=uv)
        # Sixteen small exposed road wheels, plus two end wheels per side.
        for j in range(16):
            x=-6.85+j*.91
            hull.cylinder((x,side*4.56,.91),.65,1.02,'y',16,4)
            hull.cylinder((x,side*5.09,.91),.45,.06,'y',12,2)
            hull.cylinder((x,side*5.14,.91),.14,.07,'y',10,5)
        for x in (-7.37,7.35):
            hull.cylinder((x,side*4.52,1.48),.89,1.10,'y',20,4)
            hull.cylinder((x,side*5.1,1.48),.62,.08,'y',16,2)
            hull.cylinder((x,side*5.16,1.48),.23,.08,'y',12,5)
        tracks.append(tread)
    return [hull,turret,gun,*tracks,color]


def texture(tread=False):
    colors=[(77,80,80),(96,99,99),(62,66,66),(23,31,34),
            (30,32,32),(48,51,52),(106,109,106),(9,12,13),
            (39,44,44),(86,89,90),(170,175,171),(190,193,185),
            (83,87,87),(76,79,80),(103,104,100),(105,28,25)]
    pixels=bytearray()
    for y in range(512):
        for x in range(512):
            tile=(y//128)*4+x//128;u=x%128;v=y%128
            shade=((x*31+y*79)%13-6)*.5
            if tread:
                seam=x%32
                val=37+(13 if 5<seam<24 else -15)+(8 if y%64<6 else 0)
                rgb=(val,val+2,val)
            else:
                edge=min(u,v,127-u,127-v)
                if tile in (0,1,2,9,12,13,14):
                    shade+=(-30 if edge<7 else 19 if edge<10 else 0)+(v-64)*.20
                    # Baked weld lines, screw heads and chipped paint remain
                    # readable under SAGE's simple diffuse lighting.
                    if v in (18,19):shade-=20
                    if v==20:shade+=12
                    if (u<20 or u>107) and (v<20 or v>107):
                        dx=min(abs(u-15),abs(u-112));dy=min(abs(v-15),abs(v-112))
                        if dx*dx+dy*dy<12:shade+=30
                    if v<34 and (u*7+v*13)%31<9:shade-=12
                    if (u*19+v*7)%1459<4:shade+=20
                if tile==8:shade+=-23 if v%16<10 else 9
                rgb=tuple(max(0,min(255,int(c+shade))) for c in colors[tile])
            pixels.extend(reversed(rgb))
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,512,512,24,0)+pixels


def main():
    from uwmod.kitbash import unpack,pack
    OUTPUT.mkdir(parents=True,exist_ok=True);meshes=vehicle();tex=texture()
    raw=w3d(meshes,model_name='UWMAUS',texture_name='uwmaus.tga',bones=BONES,origins=ORIGINS)
    data=unpack(raw)
    # Native W3DTankDraw discovers TREADSL/R and requires a linear-offset mapper.
    for cid,payload in data:
        if cid!=0:continue
        header=next(p for i,p in payload if i==0x1f)
        if not header[8:24].split(b'\0')[0].startswith(b'TREADS'):continue
        materials=next(p for i,p in payload if i==0x2a)
        mat=next(p for i,p in materials if i==0x2b)
        for j,(i,p) in enumerate(mat):
            if i==0x2d:mat[j]=(i,struct.pack('<I',0x40000)+p[4:])
        mat.append((0x2e,b'UPerSec=0\nVPerSec=0\0'))
        textures=next(p for i,p in payload if i==0x30)
        texture_block=next(p for i,p in textures if i==0x31)
        for j,(i,p) in enumerate(texture_block):
            if i==0x32:texture_block[j]=(i,b'uwmatread.tga\0')
    (OUTPUT/'uwmaus.w3d').write_bytes(pack(data))
    (OUTPUT/'uwmaus.tga').write_bytes(tex);(OUTPUT/'uwmatread.tga').write_bytes(texture(True))
    (OUTPUT/'uwmacameo.tga').write_bytes(cameo_tga(meshes,tex))
    verts=[v for m in meshes for v in m.vertices]
    report={'model':'UWMAUS','texture':'uwmaus.tga','asset_license':'CC0-1.0','front':'+X','up':'+Z',
        'triangles':sum(len(m.triangles) for m in meshes),'vertices':len(verts),'rigid_meshes':len(meshes),
        'bounds':{'min':[min(v[i] for v in verts) for i in range(3)],'max':[max(v[i] for v in verts) for i in range(3)]},
        'bones':[{'name':n,'parent':p,'translation':t} for n,p,t in BONES],
        'meshes':[{'name':m.name,'bone':m.bone,'origin':ORIGINS[m.bone],'vertices':m.vertices,'normals':m.normals,
            'uvs':m.uvs,'triangles':m.triangles,'texture':'uwmatread.tga' if m.name.startswith('TREADS') else 'uwmaus.tga'} for m in meshes]}
    (OUTPUT/'uwmaus.mesh.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
    lines=['# Authored Maus interpretation; CC0-1.0','mtllib uwmaus.mtl'];offset=1
    for m in meshes:
        lines+=['o '+m.name,'usemtl TREADS' if m.name.startswith('TREADS') else 'usemtl MAUS']
        lines+=['v %.6f %.6f %.6f'%p for p in m.vertices]
        lines+=['vt %.6f %.6f'%p for p in m.uvs]
        lines+=['vn %.6f %.6f %.6f'%p for p in m.normals]
        lines+=['f '+' '.join(f'{i+offset}/{i+offset}/{i+offset}' for i in f) for f in m.triangles];offset+=len(m.vertices)
    (OUTPUT/'uwmaus.obj').write_text('\n'.join(lines)+'\n')
    (OUTPUT/'uwmaus.mtl').write_text('newmtl MAUS\nKd 1 1 1\nmap_Kd uwmaus.tga\nnewmtl TREADS\nKd 1 1 1\nmap_Kd uwmatread.tga\n')
    print(json.dumps({k:report[k] for k in ('model','triangles','vertices','bounds')}))

if __name__=='__main__':
    import sys
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    main()
