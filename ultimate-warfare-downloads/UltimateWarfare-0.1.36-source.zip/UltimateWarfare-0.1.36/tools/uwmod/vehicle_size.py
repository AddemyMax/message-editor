"""Measure private local stock geometry; only dimensions/hashes enter reports."""
import math
import struct
from .ini import parse_ini
from .kitbash import Resources,load_model,one


def model_bounds(resources,model,mesh_names=None):
    pivots,bindings=load_model(resources,model)
    def transform(point,bone):
        while bone != 0xffffffff:
            p=pivots[bone];x,y,z,w=p[8:12]
            if abs(x*x+y*y+z*z+w*w-1)>.01:
                raise ValueError('Reference model has a non-normalized rotation')
            vx,vy,vz=point
            tx,ty,tz=2*(y*vz-z*vy),2*(z*vx-x*vz),2*(x*vy-y*vx)
            point=(vx+w*tx+y*tz-z*ty+p[2],vy+w*ty+z*tx-x*tz+p[3],vz+w*tz+x*ty-y*tx+p[4])
            bone=p[1]
        return point
    points=[]
    for bone,mesh in bindings:
        if mesh_names is not None and one(mesh,0x1f)[8:24].split(b'\0')[0].decode('ascii') not in mesh_names:
            continue
        vertices=list(struct.iter_unpack('<3f',one(mesh,2)))
        skins=[p for cid,p in mesh if cid==0xe]
        if skins:
            raw,=skins
            if len(raw)!=len(vertices)*8:raise ValueError('Unsupported reference skin data')
            indices=[struct.unpack_from('<H',raw,i*8)[0] for i in range(len(vertices))]
        else:indices=[bone]*len(vertices)
        # Ignore unused vertices left by export-time mesh filtering.
        indices_used={i for tri in struct.iter_unpack('<4I4f',one(mesh,0x20)) for i in tri[:3]}
        for i in sorted(indices_used):
            if i>=len(vertices) or indices[i]>=len(pivots):raise ValueError('Reference vertex/bone out of range')
            points.append(transform(vertices[i],indices[i]))
    if not points or not all(math.isfinite(v) for p in points for v in p):
        raise ValueError('Reference model has invalid bounds')
    return {'min':[min(p[i] for p in points) for i in range(3)],
            'max':[max(p[i] for p in points) for i in range(3)]}


def fixed_size(spec,project):
    from .project import BuildError
    scale=spec['visual_scale']
    if type(scale) not in (int,float) or not math.isfinite(scale) or not .01<scale<=3:
        raise BuildError('Fixed visual scale must be greater than0.01 and at most3')
    class AuthoredResources:
        def read(self,virtual):
            expected='Art\\W3D\\'+spec['model']+'.w3d'
            if virtual.lower()!=expected.lower():raise BuildError('Unexpected authored sizing dependency')
            return (project/'assets/generated'/f"{spec['model'].lower()}.w3d").read_bytes()
    own=model_bounds(AuthoredResources(),spec['model'])
    chassis=model_bounds(AuthoredResources(),spec['model'],{'HULL','TREADSL','TREADSR'})
    major=max(abs(chassis['min'][0]),abs(chassis['max'][0]))*scale
    minor=max(abs(chassis['min'][1]),abs(chassis['max'][1]))*scale
    height=(own['max'][2]-own['min'][2])*scale
    geometry={'major_radius':major,'minor_radius':minor,'height':height}
    return {'Scale':f'{scale:g}','Geometry':'BOX','GeometryMajorRadius':f'{major:.10g}',
        'GeometryMinorRadius':f'{minor:.10g}','GeometryHeight':f'{height:.10g}',
        'GeometryIsSmall':'No','ShadowSizeX':f'{major*2.2:.10g}','ShadowSizeY':f'{minor*2.2:.10g}'}, {
        'method':'fixed authored model scale; independent of stock Overlord bounds',
        'model_scale':scale,'geometry':geometry},[]


def size_like_reference(source,spec,project):
    from .project import _scalar,BuildError
    if 'visual_scale' in spec:return fixed_size(spec,project)
    raw,path=source.find_object(spec['visual_reference_object'])
    ref,=parse_ini(raw).blocks
    state=next((state for draw in ref.children if draw.kind.lower()=='draw'
        for state in draw.children if state.kind.lower()=='defaultconditionstate' or
        (state.kind.lower()=='conditionstate' and state.value.upper()=='NONE')),None)
    if state is None:raise BuildError('Reference vehicle lacks a normal Draw state')
    model=_scalar(state,'Model');resources=Resources(source)
    bounds=model_bounds(resources,model)
    source_scale=float(_scalar(ref,'Scale')) if ref.find_fields('Scale') else 1.
    ratio=spec['visual_reference_ratio']
    if not math.isfinite(source_scale) or source_scale<=0:raise BuildError('Invalid reference vehicle Scale')
    class AuthoredResources:
        def read(self,virtual):
            expected='Art\\W3D\\'+spec['model']+'.w3d'
            if virtual.lower()!=expected.lower():
                raise BuildError('Authored sizing model unexpectedly depends on another W3D')
            return (project/'assets/generated'/f"{spec['model'].lower()}.w3d").read_bytes()
    authored=model_bounds(AuthoredResources(),spec['model'])
    chassis=model_bounds(AuthoredResources(),spec['model'],{'HULL','TREADSL','TREADSR'})
    dimensions=[(b-a)*source_scale for a,b in zip(bounds['min'],bounds['max'])]
    own=[b-a for a,b in zip(authored['min'],authored['max'])]
    if any(v<=0 or not math.isfinite(v) for v in dimensions+own):raise BuildError('Invalid sizing bounds')
    scale=max(ratio*dimensions[i]/own[i] for i in (0,1))
    if not .01<scale<100:raise BuildError('Reference-based scale outside supported range')
    # Collision covers the enlarged chassis, while the barrel may overhang.
    major=max(abs(chassis['min'][0]),abs(chassis['max'][0]))*scale
    minor=max(abs(chassis['min'][1]),abs(chassis['max'][1]))*scale
    height=own[2]*scale
    return {'Scale':f'{scale:.10g}','Geometry':'BOX','GeometryMajorRadius':f'{major:.10g}',
            'GeometryMinorRadius':f'{minor:.10g}','GeometryHeight':f'{height:.10g}',
            'GeometryIsSmall':'No','ShadowSizeX':f'{major*2.2:.10g}','ShadowSizeY':f'{minor*2.2:.10g}'}, {
            'reference_object':spec['visual_reference_object'],'reference_file':path,'reference_model':model,
            'reference_scale':source_scale,'reference_bounds':bounds,'target_ratio':ratio,
            'method':'uniform scale ensuring at least target ratio in both visible horizontal extents',
            'model_scale':scale,'actual_horizontal_ratios':[own[i]*scale/dimensions[i] for i in (0,1)],
            'geometry':{'major_radius':major,'minor_radius':minor,'height':height}},resources.records
