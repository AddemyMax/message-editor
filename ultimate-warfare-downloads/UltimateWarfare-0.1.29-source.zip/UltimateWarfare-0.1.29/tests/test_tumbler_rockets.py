"""Armor and independent payload contracts on authored fixtures, not native AI proof."""
import json
from pathlib import Path
import struct
import unittest

import test_project as fixtures
from uwmod.project import GameSource,compile_project,validate_archive,BuildError
from uwmod.ini import parse_ini
from uwmod.archive import write_big
from assets.validate_w3d import chunks,one,validate


class TumblerRocketTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def compile(self):
        return compile_project(GameSource(self.game),self.project)

    def validate_files(self,files):
        target=self.root/'RocketTests.big';target.write_bytes(write_big(files));return validate_archive(target)

    def test_armor_reduces_combat_damage_to_one_third_without_changing_health_or_status(self):
        raw=self.fixture['Data/INI/Armor.ini']
        block=parse_ini(raw).find_block('Armor','FixtureArmor')
        raw=raw[:block.end_start]+b'  Armor = STATUS 65%\n  Armor = HEALING 150%\n  Armor = SUBDUAL_VEHICLE 30%\n'+raw[block.end_start:]
        self.fixture['Data/INI/Armor.ini']=raw;self.write_fixture()
        files,report=self.compile();armor=parse_ini(files['Data\\INI\\Armor.ini'])
        mapping=report['units'][1]['armor'];self.assertEqual(mapping,{'FixtureArmor':'UWTumblerArmor0'})
        stock=armor.find_block('Armor','FixtureArmor');new=armor.find_block('Armor',mapping['FixtureArmor'])
        coefficients=lambda block:{f.value.split()[0]:float(f.value.split()[1][:-1]) for f in block.find_fields('Armor')}
        old=coefficients(stock);updated=coefficients(new)
        for key,value in old.items():
            expected=value if key in ('STATUS','HEALING') else value/3
            self.assertAlmostEqual(updated[key],expected,places=7)
        self.assertEqual(updated['UNRESISTABLE'],old['DEFAULT'])
        obj,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        body=next(c for c in obj.children if c.kind.lower()=='body')
        self.assertEqual(body.find_fields('MaxHealth')[0].value,'1375')
        self.assertTrue(files['Data\\INI\\Armor.ini'].startswith(raw))
        self.assert_original_unchanged()

    def test_full_parent_weapon_slots_keep_all_guns_and_payload_has_four_rockets(self):
        key='Data/INI/Object/FixtureSource.ini';source=self.fixture[key]
        doc=parse_ini(source);stock=doc.find_block('Object','ChinaTankOverlord')
        raw=doc.source(stock).replace(b'Weapon = PRIMARY FixtureGun\n',b'Weapon = PRIMARY FixtureGun\n    Weapon = SECONDARY FixtureEliteGun\n')
        self.fixture[key]=source[:stock.start]+raw+source[stock.end:];self.write_fixture()
        files,report=self.compile();vehicle,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        normal=next(c for c in vehicle.children if c.kind.lower()=='weaponset')
        self.assertEqual({f.value for f in normal.find_fields('Weapon')},
                         {'PRIMARY FixtureGun','SECONDARY FixtureEliteGun','TERTIARY UWTumblerMinigun'})
        weapon=parse_ini(files['Data\\INI\\Weapon.ini']).find_block('Weapon','UWTumblerRearRocket')
        values={f.key:f.value for f in weapon.fields}
        self.assertEqual({k:values[k] for k in ('PrimaryDamage','AttackRange','ClipSize','ClipReloadTime','DelayBetweenShots','ShotsPerBarrel','ProjectileObject')},
                         {'PrimaryDamage':'89','AttackRange':'360','ClipSize':'4','ClipReloadTime':'12000','DelayBetweenShots':'250','ShotsPerBarrel':'1','ProjectileObject':'FixtureScorpionMissile'})
        self.assertEqual(report['units'][1]['rockets']['source_weapon'],'FixtureScorpionRocket')
        rack,=parse_ini(files['Data\\INI\\Object\\UWTumblerRocketRack.ini']).blocks
        self.assertNotIn('SELECTABLE',rack.find_fields('KindOf')[0].value.split())
        self.assertNotIn('SCORE',rack.find_fields('KindOf')[0].value.split())
        self.assertIn('PORTABLE_STRUCTURE',rack.find_fields('KindOf')[0].value.split())
        self.assertEqual(self.validate_files(files)['status'],'structurally_valid')
        self.assert_original_unchanged()

    def test_logical_firepoint_and_visual_anchor_match_and_reveal_on_rocket_attack(self):
        files,_=self.compile();parent,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        child,=parse_ini(files['Data\\INI\\Object\\UWTumblerRocketRack.ini']).blocks
        draw=next(c for c in child.children if c.kind.lower()=='draw')
        self.assertEqual(draw.find_fields('AttachToBoneInContainer')[0].value,'FIREPOINT01')
        self.assertEqual(draw.find_fields('ProjectileBoneFeedbackEnabledSlots')[0].value,'PRIMARY')
        model=chunks(files['Art\\W3D\\uwtumbler.w3d']);pivots=one(one(model,0x100),0x102)
        anchor=next(p for p in struct.iter_unpack('<16sI10f',pivots) if p[0].split(b'\0')[0]==b'FIREPOINT01')
        self.assertLess(anchor[2],0);self.assertGreater(anchor[4],7)
        stealth=next(c for c in parent.children if c.value.startswith('StealthUpdate '))
        self.assertIn('RIDERS_ATTACKING',stealth.find_fields('StealthForbiddenConditions')[0].value.split())
        payload=next(c for c in parent.children if c.value.startswith('OverlordContain '))
        self.assertEqual(payload.find_fields('PayloadTemplateName')[0].value,'UWTumblerRocketRack')
        self.assertEqual(payload.find_fields('DamagePercentToUnits')[0].value,'0%')

    def test_numbered_missiles_have_distinct_launch_points_and_feedback_meshes(self):
        data=validate(fixtures.PROJECT/'assets/generated/uwtbrack.w3d')
        self.assertEqual(data['bones'],['ROOTTRANSFORM','R_TURRET','ROCKET01','ROCKET02','ROCKET03','ROCKET04'])
        self.assertEqual(len({tuple(v) for v in data['bone_world_positions'][2:]}),4)
        self.assertEqual(data['triangles'],796)
        top=chunks((fixtures.PROJECT/'assets/generated/uwtbrack.w3d').read_bytes())
        headers=[one(m,0x1f) for cid,m in top if cid==0]
        mesh_names={h[8:24].split(b'\0')[0].decode() for h in headers}
        self.assertTrue({'ROCKET01','ROCKET02','ROCKET03','ROCKET04'}<=mesh_names)

    def test_missing_payload_feedback_and_attachment_are_rejected(self):
        files,_=self.compile();target='Data\\INI\\Object\\UWTumblerRocketRack.ini'
        cases=[]
        missing=dict(files);del missing[target];cases.append(missing)
        for old,new in ((b'AttachToBoneInContainer = FIREPOINT01',b'AttachToBoneInContainer = WRONG'),
                        (b'ProjectileBoneFeedbackEnabledSlots = PRIMARY',b'ProjectileBoneFeedbackEnabledSlots = SECONDARY')):
            altered=dict(files);altered[target]=altered[target].replace(old,new);cases.append(altered)
        missing=dict(files);del missing['Art\\W3D\\uwtbrack.w3d'];cases.append(missing)
        for case in cases:
            with self.assertRaises(BuildError):self.validate_files(case)

    def test_base_scorpion_weapon_is_chosen_over_salvage_upgraded_variant(self):
        key='Data/INI/Object/FixtureSource.ini'
        self.fixture[key]=self.fixture[key].replace(b'Object GLATankScorpion\n',b'Object GLATankScorpion\n  WeaponSet\n    Conditions = PLAYER_UPGRADE CRATEUPGRADE_ONE\n    Weapon = SECONDARY FixtureSalvageRocket\n  End\n')
        self.fixture['Data/INI/Weapon.ini']+=b'Weapon FixtureSalvageRocket\n  PrimaryDamage = 400\n  ProjectileObject = FixtureScorpionMissile\nEnd\n'
        self.write_fixture();files,_=self.compile()
        weapon=parse_ini(files['Data\\INI\\Weapon.ini']).find_block('Weapon','UWTumblerRearRocket')
        self.assertEqual(weapon.find_fields('PrimaryDamage')[0].value,'89')
        self.assert_original_unchanged()

    def armor_case(self,definition,expected):
        raw=self.fixture['Data/INI/Armor.ini'];block=parse_ini(raw).find_block('Armor','FixtureArmor')
        self.fixture['Data/INI/Armor.ini']=raw[:block.start]+definition+raw[block.end:]
        self.write_fixture();files,_=self.compile()
        armor=parse_ini(files['Data\\INI\\Armor.ini']).find_block('Armor','UWTumblerArmor0')
        fields=[f.value.split() for f in armor.find_fields('Armor')]
        self.assertEqual(fields[0][0],'DEFAULT')
        values={kind:float(value[:-1]) for kind,value in fields}
        for kind,value in expected.items():self.assertAlmostEqual(values[kind],value,places=7)
        self.validate_files(files)
        self.assertTrue(files['Data\\INI\\Armor.ini'].startswith(self.fixture['Data/INI/Armor.ini']))
        self.assert_original_unchanged()

    def test_omitted_default_uses_native_100_percent_before_tripling_armor(self):
        self.armor_case(b'Armor FixtureArmor\n  Armor = ARMOR_PIERCING 60%\n  Armor = FLAME 0%\nEnd\n',
                        {'DEFAULT':100/3,'ARMOR_PIERCING':20,'FLAME':0,'STATUS':100,'HEALING':100})

    def test_empty_armor_uses_native_default_for_unlisted_damage_types(self):
        self.armor_case(b'Armor FixtureArmor\nEnd\n',{'DEFAULT':100/3,'STATUS':100,'HEALING':100})

    def test_default_resets_earlier_overrides_and_later_duplicates_win(self):
        self.armor_case(b'Armor FixtureArmor\n  Armor = STATUS 20%\n  Armor = SMALL_ARMS 15%\n  Armor = DEFAULT 75%\n  Armor = ARMOR_PIERCING 30%\n  Armor = ARMOR_PIERCING 60%\n  Armor = HEALING 140%\nEnd\n',
                        {'DEFAULT':25,'STATUS':75,'HEALING':140,'ARMOR_PIERCING':20})
