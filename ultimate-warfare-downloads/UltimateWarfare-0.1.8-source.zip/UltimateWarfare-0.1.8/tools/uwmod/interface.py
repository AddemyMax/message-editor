"""Conservative private WND overlay for the stock 800x600 command grid.

This is a targeted, lossless window reader, not a general WND interpreter.
Unknown layouts fail closed. No installed file is written.
"""
from dataclasses import dataclass
import re

from .ini import IniError


@dataclass
class Window:
    start: int
    end: int
    parent: object
    header_end: int
    name: str = ""
    kind: str = ""
    rect: tuple = ()
    rect_span: tuple = ()
    child_group_open: bool = False


def windows(data: bytes) -> list[Window]:
    tokens = list(re.finditer(rb"(?m)^[ \t]*(WINDOW|CHILD|ENDALLCHILDREN|END)[ \t]*\r?$", data))
    stack = []
    result = []
    for index, token in enumerate(tokens):
        kind = token[1]
        if kind == b"WINDOW":
            header_end = tokens[index + 1].start() if index + 1 < len(tokens) else len(data)
            node = Window(token.start(), 0, stack[-1] if stack else None, header_end)
            header = data[token.end():header_end]
            names = list(re.finditer(rb'\bNAME\s*=\s*"([^"\r\n]*)"\s*;', header))
            kinds = list(re.finditer(rb"\bWINDOWTYPE\s*=\s*([A-Za-z0-9_]+)\s*;", header))
            rects = list(re.finditer(rb"\bSCREENRECT\s*=\s*UPPERLEFT:\s*(-?\d+)\s+(-?\d+)\s*,\s*BOTTOMRIGHT:\s*(-?\d+)\s+(-?\d+)\s*,\s*CREATIONRESOLUTION:\s*(\d+)\s+(\d+)\s*;", header))
            if len(names) > 1 or len(rects) != 1 or len(kinds) != 1:
                raise IniError("Unsupported WND window header; compact production panel not applied")
            node.name = names[0][1].decode("ascii") if names else ""
            node.kind = kinds[0][1].decode("ascii")
            node.rect = tuple(int(value) for value in rects[0].groups())
            node.rect_span = (token.end() + rects[0].start(), token.end() + rects[0].end())
            stack.append(node)
            result.append(node)
        elif kind == b"END":
            if stack:
                if stack[-1].child_group_open:
                    raise IniError("Unclosed WND child group; compact production panel not applied")
                stack.pop().end = token.end() + (1 if data[token.end():token.end()+1] == b"\n" else 0)
        elif not stack:
            raise IniError("Unexpected WND child group; compact production panel not applied")
        elif kind == b"CHILD":
            if stack[-1].child_group_open:
                raise IniError("Repeated WND child group is unsupported")
            stack[-1].child_group_open = True
        elif kind == b"ENDALLCHILDREN":
            if not stack[-1].child_group_open:
                raise IniError("Unmatched WND child group end")
            stack[-1].child_group_open = False
    if stack or any(not window.end for window in result):
        raise IniError("Unclosed WND window; compact production panel not applied")
    return result


def compact_production_panel(data: bytes) -> bytes:
    parsed = windows(data)
    lookup = {}
    for node in parsed:
        if not (node.name == "ControlBar.wnd:CommandWindow" or re.fullmatch(r"ControlBar\.wnd:ButtonCommand\d{2}", node.name)):
            continue
        if node.name in lookup:
            raise IniError("Duplicate WND name; compact production panel not applied")
        lookup[node.name] = node
    prefix = "ControlBar.wnd:"
    parent = lookup.get(prefix + "CommandWindow")
    if parent is None or parent.kind != "USER" or parent.rect != (189, 492, 606, 592, 800, 600):
        raise IniError("Unsupported command panel geometry; compact production panel not applied")
    if any(prefix + f"ButtonCommand{slot:02d}" in lookup for slot in range(15, 19)):
        raise IniError("Additional command window already exists; compact production panel not applied")
    buttons = []
    for slot in range(1, 15):
        node = lookup.get(prefix + f"ButtonCommand{slot:02d}")
        col, row = divmod(slot - 1, 2)
        x, y = 223 + col * 55, 494 + row * 51
        if node is None or node.kind != "PUSHBUTTON" or node.parent is not parent or node.rect != (x, y, x + 50, y + 44, 800, 600):
            raise IniError("Unsupported stock command button layout; compact production panel not applied")
        if any(child.parent is node for child in parsed):
            raise IniError("Nested command button window is unsupported")
        buttons.append(node)
    if {node.name for node in parsed if node.parent is parent} != {node.name for node in buttons}:
        raise IniError("Unexpected command panel children; compact production panel not applied")
    # Seven production columns fit before the untouched rally/sell column.
    # Existing production buttons narrow from 50 to 42 design pixels.
    def rect(x, y):
        return f"SCREENRECT = UPPERLEFT: {x} {y}, BOTTOMRIGHT: {x+42} {y+44}, CREATIONRESOLUTION: 800 600;".encode("ascii")
    template = buttons[0]
    clone = data[template.start:template.end]
    a, b = template.rect_span
    clone = clone[:a-template.start] + rect(505, 494) + clone[b-template.start:]
    old = (prefix + "ButtonCommand01").encode("ascii")
    new = (prefix + "ButtonCommand15").encode("ascii")
    if clone.count(old) != 1:
        raise IniError("Ambiguous command button template references")
    clone = clone.replace(old, new)
    newline = b"\r\n" if b"\r\n" in data else b"\n"
    edits = [(template.start, template.start, clone + newline)]
    for index, node in enumerate(buttons[:12]):
        col, row = divmod(index, 2)
        edits.append((*node.rect_span, rect(223 + col * 47, 494 + row * 51)))
    patched = data
    for start, end, replacement in sorted(edits, reverse=True):
        patched = patched[:start] + replacement + patched[end:]
    verified = windows(patched)
    extra, = [node for node in verified if node.name == prefix + "ButtonCommand15"]
    if extra.rect != (505, 494, 547, 538, 800, 600):
        raise IniError("New command window validation failed")
    return patched
