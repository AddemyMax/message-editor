"""Authored WND fixtures: structural tests, not native rendering proof."""
import unittest

from tools.uwmod.interface import compact_production_panel, windows
from tools.uwmod.ini import IniError


def authored_panel():
    def header(name, rect, kind="USER"):
        x, y, right, bottom = rect
        return (f'WINDOW\n WINDOWTYPE = {kind};\n'
                f' SCREENRECT = UPPERLEFT: {x} {y}, BOTTOMRIGHT: {right} {bottom}, CREATIONRESOLUTION: 800 600;\n'
                f' NAME = "ControlBar.wnd:{name}";\n').encode("ascii")
    data = header("CommandWindow", (189, 492, 606, 592)) + b"CHILD\n"
    for slot in reversed(range(1, 15)):
        col, row = divmod(slot - 1, 2)
        x, y = 223 + col * 55, 494 + row * 51
        data += header(f"ButtonCommand{slot:02d}", (x, y, x+50, y+44), "PUSHBUTTON")
        data += b' INPUTCALLBACK = "FixtureCommandCallback";\n DATA = IMAGE: FixtureArt;\nEND\n'
    return data + b"ENDALLCHILDREN\nEND\n"


class InterfaceTests(unittest.TestCase):
    def test_extra_button_is_sibling_preserves_callbacks_and_service_buttons(self):
        data = authored_panel().replace(b"\n", b"\r\n")
        patched = compact_production_panel(data)
        before = {n.name: n for n in windows(data)}
        after = {n.name: n for n in windows(patched)}
        self.assertEqual(len(after), len(before) + 1)
        extra = after["ControlBar.wnd:ButtonCommand15"]
        self.assertIs(extra.parent, after["ControlBar.wnd:CommandWindow"])
        self.assertEqual(extra.rect, (505, 494, 547, 538, 800, 600))
        self.assertIn(b'INPUTCALLBACK = "FixtureCommandCallback";', patched[extra.start:extra.end])
        for slot in (13, 14):
            name = f"ControlBar.wnd:ButtonCommand{slot:02d}"
            old, new = before[name], after[name]
            self.assertEqual(data[old.start:old.end], patched[new.start:new.end])
        # Removing the insertion and reverting only the 12 rectangle fields
        # recovers every original byte (including CRLF and art/callback data).
        edits = [(extra.start, extra.end + 2, b"")]
        for slot in range(1, 13):
            name = f"ControlBar.wnd:ButtonCommand{slot:02d}"
            old, new = before[name], after[name]
            edits.append((*new.rect_span, data[slice(*old.rect_span)]))
        recovered = patched
        for a, b, replacement in sorted(edits, reverse=True):
            recovered = recovered[:a] + replacement + recovered[b:]
        self.assertEqual(recovered, data)

    def test_compact_buttons_do_not_overlap_and_stay_inside_parent(self):
        parsed = windows(compact_production_panel(authored_panel()))
        buttons = [node for node in parsed if "ButtonCommand" in node.name]
        for i, node in enumerate(buttons):
            x, y, r, b, _, _ = node.rect
            self.assertTrue(189 <= x < r <= 606 and 492 <= y < b <= 592)
            for other in buttons[i+1:]:
                ox, oy, right, bottom, _, _ = other.rect
                self.assertFalse(x < right and r > ox and y < bottom and b > oy)

    def test_unknown_layout_existing_extra_and_nested_buttons_fail_closed(self):
        data = authored_panel()
        cases = [data.replace(b"UPPERLEFT: 223 494", b"UPPERLEFT: 224 494"),
                 data.replace(b"ButtonCommand01", b"ButtonCommand15"),
                 data.replace(b"ENDALLCHILDREN", b""),
                 data.replace(b"CommandWindow", b"UnknownWindow")]
        # Missing ENDALLCHILDREN must be rejected by structural parsing too.
        for candidate in cases:
            with self.subTest(candidate=candidate[:80]), self.assertRaises(IniError):
                compact_production_panel(candidate)

    def test_duplicate_anonymous_windows_outside_command_panel_are_retained(self):
        anonymous = b'WINDOW\nWINDOWTYPE = USER;\nSCREENRECT = UPPERLEFT: 0 0, BOTTOMRIGHT: 1 1, CREATIONRESOLUTION: 800 600;\nNAME = "ControlBar.wnd:";\nEND\n'
        patched = compact_production_panel(anonymous * 2 + authored_panel())
        self.assertTrue(patched.startswith(anonymous * 2))
