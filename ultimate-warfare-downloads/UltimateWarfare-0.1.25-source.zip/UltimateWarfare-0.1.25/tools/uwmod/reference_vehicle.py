"""Add an authored wheeled vehicle with an installed stock tank's statistics."""
import math

from .ini import parse_ini, patch_command_set, IniError
from .interface import compact_production_panel


def compile_reference(source, spec, output, files, project):
    from .project import _rename, _edit, _fields, _scalar, _newline, _append, BuildError
    seed, object_path = source.find_object(spec['source_object'])
    factory, factory_path = source.find_object(spec['production_object'])
    source.find_object(spec['prerequisite'])
    if spec['id'].lower() in source.object_names:
        raise BuildError('New object already exists in installed game: '+spec['id'])
    factory_block, = parse_ini(factory).blocks
    factory_commands = _scalar(factory_block,'CommandSet')
    try:
        patch=patch_command_set(output['CommandSet'],factory_commands,spec['button'])
    except IniError as exc:
        if str(exc)!='No free production slot 1..12; original commands were preserved': raise
        patch=patch_command_set(output['CommandSet'],factory_commands,spec['button'],slots=(15,))
        ui='Window\\ControlBar.wnd'
        if ui not in files: files[ui]=compact_production_panel(source.read(ui))
    output['CommandSet']=patch.data
    clone=_rename(seed,'Object',spec['id'])
    body,=parse_ini(clone).blocks
    bodies=[c for c in body.children if c.kind.lower()=='body']
    physics=[c for c in body.children if c.kind.lower()=='behavior' and c.value.split()[0].lower()=='physicsbehavior']
    ai=[c for c in body.children if c.kind.lower()=='behavior' and 'aiupdate' in c.value.split()[0].lower()]
    if len(bodies)!=1 or len(physics)!=1 or len(ai)!=1:
        raise BuildError('Reference tank must have exactly one Body, PhysicsBehavior and AIUpdate')
    health=_scalar(bodies[0],'MaxHealth'); cost=_scalar(body,'BuildCost'); time=_scalar(body,'BuildTime')
    if not body.find_fields('Locomotor') or any(f.start<ai[0].end for f in body.find_fields('Locomotor')):
        raise BuildError('Reference locomotor must follow AIUpdate')
    weapon_sets=[c for c in body.children if c.kind.lower()=='weaponset']
    armor_sets=[c for c in body.children if c.kind.lower()=='armorset']
    if not weapon_sets or not armor_sets: raise BuildError('Reference tank requires weapon and armor sets')
    # Preserve exact stock combat references and their definitions, including
    # veteran weapon sets. Attachments cannot fit this new, turretless model.
    old_set=_scalar(body,'CommandSet')
    command_doc=parse_ini(output['CommandSet'])
    button_doc=parse_ini(output['CommandButton'])
    stock_commands=command_doc.find_block('CommandSet',old_set)
    safe={'STOP','GUARD','ATTACK_MOVE','WAYPOINTS','ATTACK_OBJECT','ATTACK_GROUND'}
    commands=[]
    for field in stock_commands.fields:
        button=button_doc.find_block('CommandButton',field.value)
        if _scalar(button,'Command').upper() in safe:
            commands.append((field.key,field.value))
    if not any(_scalar(button_doc.find_block('CommandButton',v),'Command').upper()=='STOP' for _,v in commands):
        raise BuildError('Reference command set lacks a safe Stop command')
    new_commands=f"CommandSet {spec['command_set']}\n"+''.join(f'  {k} = {v}\n' for k,v in commands)+'End\n'
    output['CommandSet']=_append(output['CommandSet'],[new_commands.encode('ascii')])
    draw=f"""  Draw = W3DTruckDraw UWTumblerDraw
    OkToChangeModelColor = Yes
    DefaultConditionState
      Model = {spec['model']}
      WeaponFireFXBone = PRIMARY MUZZLE
      WeaponLaunchBone = PRIMARY MUZZLE
      Turret = MG_TURRET
      TurretPitch = MG_PITCH
      WeaponFireFXBone = SECONDARY MG_MUZZLE
      WeaponLaunchBone = SECONDARY MG_MUZZLE
      WeaponFireFXBone = TERTIARY SMOKEMZ
      WeaponLaunchBone = TERTIARY SMOKEMZ
    End
    ConditionState = RUBBLE
      Model = NONE
    End
    LeftFrontTireBone = WHEEL_FL
    RightFrontTireBone = WHEEL_FR
    LeftRearTireBone = WHEEL_RL
    RightRearTireBone = WHEEL_RR
    MidLeftRearTireBone = WHEEL_ML
    MidRightRearTireBone = WHEEL_MR
    TireRotationMultiplier = 0.2
  End
""".encode('ascii').replace(b'\n',_newline(clone))
    draws=[c for c in body.children if c.kind.lower()=='draw']
    if not draws: raise BuildError('Reference tank has no Draw module')
    edits=[(c.start,c.end,draw if i==0 else b'') for i,c in enumerate(draws)]
    removed=[]
    for c in body.children:
        if c.kind.lower()=='behavior' and c.value.split()[0].lower() in {
            'overlordcontain','objectcreationupgrade','subobjectsupgrade','weaponsetupgrade'}:
            edits.append((c.start,c.end,b''));removed.append(c.value.split()[0])
    for c in ai[0].children:
        if c.kind.lower() in ('turret','altturret'): edits.append((c.start,c.end,b''))
    for f in ai[0].fields:
        if f.key.lower()=='turretslinked': edits.append((f.start,f.end,b''))
    prereqs=[c for c in body.children if c.kind.lower()=='prerequisites']
    if len(prereqs)>1: raise BuildError('Multiple reference prerequisite blocks')
    requirement=f"  Prerequisites\n    Object = {spec['prerequisite']}\n  End\n".encode('ascii').replace(b'\n',_newline(clone))
    if prereqs: edits.append((prereqs[0].start,prereqs[0].end,requirement))
    else: edits.append((body.header_end,body.header_end,requirement))
    clone=_edit(clone,edits);body,=parse_ini(clone).blocks
    size_factor = 1.0
    size_reference = None
    if spec.get('size_reference_object'):
        reference, reference_path = source.find_object(spec['size_reference_object'])
        reference_body, = parse_ini(reference).blocks
        dimensions = {'major_radius': 'GeometryMajorRadius', 'minor_radius': 'GeometryMinorRadius'}
        reference_dimensions = {key: float(_scalar(reference_body, field)) for key, field in dimensions.items()}
        if any(not math.isfinite(x) or x <= 0 for x in reference_dimensions.values()):
            raise BuildError('Invalid reference vehicle dimensions')
        size_factor = max(spec['size_reference_ratio'] * value / spec['geometry'][key]
                          for key, value in reference_dimensions.items())
        size_reference = {'object': spec['size_reference_object'], 'source_file': reference_path,
                          'dimensions': reference_dimensions, 'minimum_footprint_ratio': spec['size_reference_ratio']}
    geometry = {key: value * size_factor for key, value in spec['geometry'].items()}
    speed_reference = None
    locomotor_map = {}
    if spec.get('speed_reference_object'):
        reference, reference_path = source.find_object(spec['speed_reference_object'])
        reference_body, = parse_ini(reference).blocks
        normal = [f for f in reference_body.find_fields('Locomotor') if f.value.split()[0].upper() == 'SET_NORMAL']
        if len(normal) != 1:
            raise BuildError('Speed reference requires one SET_NORMAL locomotor')
        locomotors = parse_ini(output['Locomotor'])
        donor = locomotors.find_block('Locomotor', normal[0].value.split()[-1])
        speeds = {'Speed': _scalar(donor, 'Speed')}
        damaged = donor.find_fields('SpeedDamaged')
        speeds['SpeedDamaged'] = damaged[0].value if damaged else speeds['Speed']
        if any(not math.isfinite(float(x)) or float(x) <= 0 for x in speeds.values()):
            raise BuildError('Invalid speed reference values')
        speed_reference = {'object': spec['speed_reference_object'], 'source_file': reference_path, **speeds}
        replacements = []
        for field in body.find_fields('Locomotor'):
            condition, old = field.value.split()
            if old not in locomotor_map:
                new = f"{spec['id']}_L{len(locomotor_map)}"
                raw = _rename(locomotors.extract_block('Locomotor', old), 'Locomotor', new)
                block, = parse_ini(raw).blocks
                raw = _fields(raw, block, speeds)
                output['Locomotor'] = _append(output['Locomotor'], [raw])
                locomotor_map[old] = new
            replacements.append((field.start, field.end,
                                 f'  Locomotor = {condition} {locomotor_map[old]}\n'.encode('ascii').replace(b'\n', _newline(clone))))
        clone = _edit(clone, replacements)
        body, = parse_ini(clone).blocks
    clone=_fields(clone,body,{'Side':'America','DisplayName':spec['display_label'],
        'SelectPortrait':spec['image'],'ButtonImage':spec['image'],'CommandSet':spec['command_set'],
        'BuildVariations':None,'Scale':f'{size_factor:g}','Geometry':'BOX',
        'GeometryMajorRadius':f"{geometry['major_radius']:g}",
        'GeometryMinorRadius':f"{geometry['minor_radius']:g}",'GeometryHeight':f"{geometry['height']:g}",
        'GeometryIsSmall':'No','Shadow':'SHADOW_DECAL','ShadowSizeX':f'{32 * size_factor:g}','ShadowSizeY':f'{20 * size_factor:g}','ShadowTexture':'shadow',
        # Stock Overlord voice/sound/death references remain local game assets.
        'UpgradeCameo1':None,'UpgradeCameo2':None,'UpgradeCameo3':None,'UpgradeCameo4':None,'UpgradeCameo5':None})
    virtual=f"Data\\INI\\Object\\{spec['id']}.ini"
    if virtual.lower() in source.entries: raise BuildError('New object path already exists: '+virtual)
    systems_report = None
    if spec.get('tumbler_systems'):
        from .tumbler_systems import install
        clone, systems_report = install(source, spec, project, clone, output, files)
    files[virtual]=clone
    summary={'id':spec['id'],'factory':spec['production_object'],'command_set':factory_commands,
             'systems':systems_report,'profile':'stock_reference','reference_object':spec['source_object'],
             'production_slot':patch.slot,'source_object_file':object_path,'source_factory_file':factory_path,
             'health':float(health),'cost':float(cost),'build_seconds':float(time),
             'removed_attachment_modules':removed,'model_scale':size_factor,'geometry':geometry,
             'size_reference':size_reference,'speed_reference':speed_reference,
             'weapons':{f.value.split()[-1]:f.value.split()[-1] for c in weapon_sets for f in c.find_fields('Weapon') if f.value.split()[-1].upper()!='NONE'},
             'armor':{f.value:f.value for c in armor_sets for f in c.find_fields('Armor')},
             'locomotors':locomotor_map or {f.value.split()[-1]:f.value.split()[-1] for f in body.find_fields('Locomotor')}}
    return summary
