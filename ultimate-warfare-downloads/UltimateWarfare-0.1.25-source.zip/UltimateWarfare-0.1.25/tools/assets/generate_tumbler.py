#!/usr/bin/env python3
"""Original procedural fan interpretation of the Batman Begins Tumbler.

No film mesh, third-party model or commercial texture is imported.
SPDX-License-Identifier: MIT (code); authored mesh/atlas CC0-1.0.
"""
import json
import math
from pathlib import Path
import struct
from generate_longma import Mesh, w3d, cameo_tga

OUTPUT = Path(__file__).resolve().parents[2] / 'assets/generated'
NAME, TEXTURE, SCALE = 'UWTUMBLER', 'uwtumbler.tga', 1.25
CENTERS = [(7.1,-4.1,2.35),(7.1,4.1,2.35),(-6.1,-5.05,3.05),(-6.1,5.05,3.05),(-6.1,-3.35,3.05),(-6.1,3.35,3.05)]
BONES = [('ROOTTRANSFORM',-1,(0,0,0))] + [(n,0,c) for n,c in zip(('WHEEL_FL','WHEEL_FR','WHEEL_RL','WHEEL_RR','WHEEL_ML','WHEEL_MR'),CENTERS)] + [('MUZZLE01',0,(7.15,-1.1,3.75)),('MUZZLE02',0,(7.15,1.1,3.75))]
BONES += [('MG_TURRET',0,(-2.,0.,6.4)),('MG_PITCH',9,(0.,0.,.45)),('MG_MUZZLE',10,(3.55,0.,0.)),('SMOKEMZ',0,(1.95,2.7,5.3))]
BONES = [(n,p,tuple(x*SCALE for x in c)) for n,p,c in BONES]
ORIGINS = []
for _, parent, pos in BONES:
    ORIGINS.append(tuple(v+(ORIGINS[parent][i] if parent>=0 else 0) for i,v in enumerate(pos)))


def vehicle():
    hull, detail, color = Mesh('BODY',0), Mesh('HARDWARE',0), Mesh('HOUSECOLOR',0)
    hull.prism([(-8.7,-3.4),(3.9,-3.3),(6.0,-1.7),(6.0,1.7),(3.9,3.3),(-8.7,3.4)],
               [(-8.0,-3.7),(2.6,-3.5),(4.7,-1.9),(4.7,1.9),(2.6,3.5),(-8.0,3.7)],2.0,4.55,0)
    hull.prism([(-6.7,-2.8),(3.8,-2.8),(4.6,-1.8),(4.6,1.8),(3.8,2.8),(-6.7,2.8)],
               [(-5.7,-2.2),(-1.0,-2.3),(.5,-1.7),(.5,1.7),(-1.,2.3),(-5.7,2.2)],4.5,7.0,1)
    # Split sloping windshield, center spine and separate side windows.
    for s in (-1,1):
        pts=[(4.38,s*.18,4.71),(4.10,s*1.65,4.89),(.68,s*1.6,6.97),(.68,s*.18,6.97)]
        if s<0: pts.reverse()
        hull.face(pts,3)
        pts=[(-4.8,s*2.80,5.12),(2.75,s*2.90,4.75),(-1.3,s*2.49,6.74),(-4.8,s*2.47,6.82)]
        if s>0: pts.reverse()
        hull.face(pts,3)
        # Layered angular side armor, wedge front fenders, a narrow open center nose.
        hull.prism([(-7.7,s*3.3),(-1.0,s*3.2),(2.5,s*4.5),(-5.8,s*4.55)],
                   [(-7.2,s*3.15),(-1.4,s*3.3),(1.5,s*3.85),(-5.5,s*4.15)],2.6,5.1,2) if s>0 else hull.prism(
                   [(-5.8,s*4.55),(2.5,s*4.5),(-1.,s*3.2),(-7.7,s*3.3)],
                   [(-5.5,s*4.15),(1.5,s*3.85),(-1.4,s*3.3),(-7.2,s*3.15)],2.6,5.1,2)
        f=[(3.0,s*3.0),(9.0,s*3.0),(9.4,s*5.7),(2.4,s*5.3)]
        t=[(3.3,s*3.0),(8.5,s*3.1),(7.3,s*5.35),(2.7,s*4.6)]
        if s<0: f.reverse();t.reverse()
        hull.prism(f,t,2.5,3.65,1)
        for x in (4.9,6.0):
            detail.box((x,s*2.7,2.6),(.26,3.8,.24),5,yaw=s*.28)
        detail.box((4.4,s*2.9,3.2),(.35,2.4,.35),6,yaw=s*.48)
        detail.box((5.6,s*1.1,3.75),(2.7,.72,.72),2)
        detail.cylinder((7.07,s*1.1,3.75),.24,.18,'x',12,5)
        detail.cylinder((7.18,s*1.1,3.75),.16,.06,'x',12,7)
        # Visible diagonal armor ribs and recessed door panels.
        hull.box((-1.6,s*3.53,4.7),(4.4,.18,.24),2,roll=-.32)
        hull.box((-4.8,s*3.73,4.1),(2.8,.18,.22),1,roll=.45)
        detail.box((-3.7,s*3.91,3.5),(2.2,.08,.9),4)
        for vent in range(4):
            detail.box((-4.45+vent*.47,s*3.97,3.5),(.17,.09,.7),5)
        for x in (-6.,-3.2,.2):
            detail.cylinder((x,s*3.65,4.9),.075,.12,'y',6,5)
        # Separate rear aero flaps, supported above the armor.
        for x in (-7.0,-4.6):
            detail.box((x,s*3.5,6.35),(.22,.22,1.7),6,roll=.2)
        for x in (-7.3,-4.7):
            hull.box((x,s*3.8,7.15),(1.85,2.8,.16),2,roll=-.16)
        for x in (-6.0,-4.5,-3.0):
            detail.box((x,s*3.8,4.6),(.65,.12,.12),5)
        color.box((-.15,s*3.96,4.85),(2.4,.08,.35),10)
        # Visible white headlights placed at the front outer fenders.
        detail.box((8.48,s*3.4,3.48),(.12,.42,.18),11)
    # Armor is layered in large readable planes, as on stock USA vehicles.
    # Keep the wheel pivots and compact turretless Tumbler silhouette intact.
    for side in (-1, 1):
        ring=[(-5.5,side*3.75),(-1.6,side*3.55),(2.7,side*4.15),(-2.6,side*4.65)]
        upper=[(-5.2,side*3.6),(-1.7,side*3.4),(2.1,side*3.9),(-2.7,side*4.3)]
        if side<0: ring.reverse();upper.reverse()
        hull.prism(ring,upper,4.25,5.0,1)
        # Separate applique plates, bottom sill and armored front cheek.
        for x in (-4.8,-2.9,-1.0):
            hull.box((x,side*4.05,3.1),(1.65,.32,1.15),2,roll=.12)
            detail.box((x,side*4.24,3.7),(.85,.12,.13),5)
        hull.box((-2.7,side*4.1,2.55),(6.4,.38,.38),6)
        hull.box((3.0,side*3.07,4.48),(2.6,.48,.42),1,roll=-.38)
        # Open suspension arms, gold dampers and linkage ends.
        for x in (5.1,6.2):
            detail.box((x,side*3.2,2.2),(.30,3.1,.25),5,yaw=side*.36)
            detail.cylinder((x,side*4.35,2.2),.23,.40,'y',10,7)
        detail.box((4.95,side*3.35,3.25),(.3,2.7,.30),6,roll=.32,yaw=side*.25)
        # Two-piece front fender armor and readable light clusters.
        hull.box((6.25,side*4.25,3.8),(2.8,1.9,.20),1,roll=.13)
        hull.box((8.4,side*4.0,2.7),(.28,2.35,.78),2,roll=-.2)
        for y in (3.2,3.65):
            detail.box((8.64,side*y,3.22),(.10,.29,.25),7)
            detail.box((8.71,side*y,3.23),(.05,.19,.15),11)
        # Service hatches, hinges, handles and a small USA star decal.
        hull.box((-3.35,side*3.88,4.05),(2.2,.14,1.16),9)
        for x in (-4.05,-2.65):
            detail.box((x,side*4.00,4.57),(.28,.13,.16),5)
        detail.box((-3.35,side*4.01,4.23),(.65,.12,.11),6)
        hull.box((-3.05,side*4.68,4.2),(1.75,.20,1.30),2)
        color.box((-3.05,side*4.83,3.72),(1.45,.08,.15),10)
        y=side*4.80
        decal=[(-3.8,y,3.83),(-2.3,y,3.83),(-2.3,y,4.73),(-3.8,y,4.73)]
        if side>0: decal.reverse()
        hull.face(decal,13)
        # Rear brake lamps, towing loops and exhaust-side armor.
        detail.box((-8.8,side*2.8,4.3),(.20,.62,.28),15)
        detail.cylinder((-8.9,side*2.6,2.6),.21,.55,'y',10,6)
        hull.box((-7.4,side*2.55,4.9),(2.7,.8,.38),8)
        color.box((-5.2,side*2.31,6.8),(1.7,.10,.22),10)
        for x in (-5.1,-2.4,.3):
            for z in (3.1,4.8):
                detail.cylinder((x,side*4.3,z),.11,.10,'y',6,5)
    # Armored roof hatch, inset vents, strip highlights and panel seams.
    hull.box((-3.65,0,7.14),(2.9,2.8,.22),9)
    color.box((-1.8,0,7.13),(.85,2.9,.08),10)
    detail.box((-3.65,0,7.30),(1.5,.12,.12),5)
    for x in (-4.65,-2.65):
        for y in (-.95,.95): detail.cylinder((x,y,7.31),.1,.10,'z',8,5)
    for side in (-1,1):
        hull.box((-6.0,side*1.15,6.64),(1.55,1.4,.22),8)
        for j in range(5):
            detail.box((-6.55+j*.25,side*1.15,6.79),(.10,1.12,.12),7)
        # Reinforced windshield ribs bordering, rather than covering, glass.
        hull.box((2.5,side*1.87,5.78),(4.3,.14,.16),2,roll=.50)
    hull.box((2.50,0,5.79),(4.4,.15,.14),1,roll=.50)
    # Front skid and small hazard stripes; rear antenna is a visible silhouette detail.
    hull.box((5.8,0,2.58),(2.7,3.1,.26),2,roll=-.1)
    hull.box((6.7,0,2.73),(.4,2.0,.08),14)
    detail.cylinder((-5.7,1.75,7.14),.20,.28,'z',10,5)
    detail.cylinder((-5.7,1.75,8.15),.055,1.9,'z',8,7)
    # Central rear jet, ring and dark recessed aperture, radiator louvers.
    detail.cylinder((-8.8,0,3.7),1.45,1.8,'x',20,2)
    detail.cylinder((-9.73,0,3.7),1.18,.10,'x',20,6)
    detail.cylinder((-9.8,0,3.7),.92,.12,'x',20,7)
    for x in (-7.6,-7.0,-6.4,-5.8):
        detail.box((x,0,7.12),(.24,3.5,.16),4)
    meshes=[hull,detail,color]
    for i,(x,y,z) in enumerate(CENTERS):
        tire=Mesh('TIRE'+str(i),i+1)
        radius=2.35 if i<2 else 3.05
        width=2.15 if i<2 else 1.58
        tire.cylinder((x,y,z),radius,width,'y',24,4)
        tire.cylinder((x,y,z),radius*.58,width+.07,'y',16,2)
        tire.cylinder((x,y,z),radius*.36,width+.12,'y',12,7)
        # Front road tires have finer grooves; rear tires have broad lugs.
        steps=28 if i<2 else 20
        for k in range(steps):
            a=k*math.tau/steps
            for offset in (-width*.255,width*.255):
                tire.box((x+radius*math.sin(a),y+offset,z+radius*math.cos(a)),
                         (.17 if i<2 else .40,width*.47,.07 if i<2 else .16),4,roll=-a)
        for side in (-1,1):
            for k in range(5):
                a=k*math.tau/5
                tire.box((x+.62*math.sin(a),y+side*(width/2+.09),z+.62*math.cos(a)),
                         (.18,.1,1.0),6,roll=-a)
        for k in range(6):
            a=k*math.tau/6
            tire.cylinder((x+.72*math.cos(a),y+(-1 if y<0 else 1)*(width/2+.10),z+.72*math.sin(a)),.10,.08,'y',6,6)
        meshes.append(tire)
    # Lower the old tall cabin while retaining all wheel centers and footprint.
    # Armor shells and roof gun below are authored in their final coordinates.
    for mesh in meshes:
        if mesh.bone == 0:
            mesh.vertices=[(x,y,4.5+(z-4.5)*.60 if z>4.5 else z) for x,y,z in mesh.vertices]
            # The nonuniform roof remap requires new flat polygon normals.
            from generate_longma import normal
            for tri in mesh.triangles:
                n=normal(*(mesh.vertices[i] for i in tri))
                for i in tri: mesh.normals[i]=n
    armor=Mesh('WHEEL_ARMOR',0)
    for side in (-1,1):
        # Rear shoulder plates bridge BOTH rear tires, with slanted outer skirts.
        bottom=[(-9.0,side*2.7),(-3.2,side*2.8),(-2.7,side*5.95),(-8.7,side*5.95)]
        top=[(-8.35,side*2.5),(-3.65,side*2.7),(-3.7,side*5.2),(-8.25,side*5.4)]
        if side<0:bottom.reverse();top.reverse()
        armor.prism(bottom,top,4.4,6.35,0)
        # Three layered slabs replace the exposed upper tire silhouette.
        for x in (-7.8,-6.0,-4.2):
            armor.box((x,side*5.53,5.45),(1.65,.30,1.20),2,roll=.24)
        # Broad wedge nose/fender shields, close to the film's angular wheel armor.
        bottom=[(2.9,side*3.0),(9.35,side*3.2),(9.4,side*5.65),(3.0,side*5.55)]
        top=[(3.2,side*2.7),(7.5,side*3.0),(8.0,side*5.25),(3.3,side*5.0)]
        if side<0:bottom.reverse();top.reverse()
        armor.prism(bottom,top,3.5,5.15,0)
        blade=[(3.0,side*5.62,2.7),(9.35,side*5.72,1.8),(8.0,side*5.38,4.7),(3.4,side*5.08,5.12)]
        if side>0:blade.reverse()
        armor.face(blade,2)
        # Diagonal cheek armor frames the much narrower black canopy.
        armor.box((1.5,side*2.50,5.0),(3.2,.35,.4),1,roll=.27)
        armor.box((-4.,side*2.43,5.75),(2.8,.25,.25),2)
        for x in (-7.2,-5.2):
            armor.box((x,side*3.7,6.50),(1.7,2.3,.16),0,roll=-.18)
        for x in (4.0,5.5,7.0):
            armor.box((x,side*4.2,5.23),(.12,1.8,.08),2)
    armor.box((1.0,2.7,5.1),(1.6,.92,.45),0)
    for y in (2.42,2.7,2.98):
        armor.cylinder((1.2,y,5.3),.16,1.4,'x',12,5)
        armor.cylinder((1.92,y,5.3),.12,.04,'x',12,7)
    # Compact remotely aimed six-barrel minigun, not a second tank turret.
    gun=Mesh('MINIGUN',10)
    gun.cylinder((-2.,0.,6.15),.7,.36,'z',16,7)
    gun.box((-2.2,0.,6.85),(1.65,1.12,.85),0)
    gun.box((-2.6,-.85,6.77),(1.1,.55,.85),2)
    for i in range(6):
        angle=i*math.tau/6
        gun.cylinder((-.15,.28*math.cos(angle),6.85+.28*math.sin(angle)),.105,2.85,'x',10,5)
    for x in (-1.15,.65,1.23):gun.cylinder((x,0.,6.85),.46,.19,'x',16,7)
    gun.cylinder((1.51,0.,6.85),.39,.10,'x',16,5)
    for i in range(6):
        angle=i*math.tau/6
        gun.cylinder((1.57,.28*math.cos(angle),6.85+.28*math.sin(angle)),.08,.03,'x',8,7)
    meshes += [armor,gun]
    for m in meshes:
        m.vertices=[tuple(v*SCALE for v in p) for p in m.vertices]
    return meshes


def texture():
    """Hand-authored diffuse panels with baked seams, edge wear and US markings.

    Contrast and broad painted detail deliberately survive the SAGE RTS camera.
    No stock/third-party textures are sampled.
    """
    colors=[(27,30,32),(44,47,48),(34,38,40),(10,22,29),
            (25,27,29),(88,94,94),(117,112,89),(12,17,21),
            (38,42,43),(40,45,46),(190,193,178),(225,228,208),
            (35,40,42),(31,35,37),(175,157,77),(134,27,22)]
    star=[(64+43*math.sin(i*math.pi/5),64+43*math.cos(i*math.pi/5))
          if i%2==0 else (64+18*math.sin(i*math.pi/5),64+18*math.cos(i*math.pi/5))
          for i in range(10)]
    def inside(x,y):
        result=False
        for i,(ax,ay) in enumerate(star):
            bx,by=star[(i+1)%10]
            if (ay>y)!=(by>y) and x<(bx-ax)*(y-ay)/(by-ay)+ax: result=not result
        return result
    pixels=bytearray()
    for y in range(512):
        for x in range(512):
            tile=(y//128)*4+x//128; u,v=x%128,y%128
            grain=((x*73+y*151)%17-8)*.48
            shade=grain
            if tile in (0,1,2,8,9,12):
                edge=min(u,v,127-u,127-v)
                shade += -22 if edge<5 else 20 if edge<8 else 0
                # Baked ambient shading, crisp panel join, screws and scuffs.
                shade += (v-64)*.10
                if u in (63,64): shade-=18
                if u in (65,66): shade+=13
                if (u<16 or u>111) and (v<16 or v>111):
                    dx=min(abs(u-12),abs(u-115));dy=min(abs(v-12),abs(v-115))
                    if dx*dx+dy*dy<11: shade+=37
                if (u*11+v*31)%1301<3: shade+=22
            if tile==3:
                shade += 18*(u+v)/254
                if 135<u+v<143: shade+=25
            if tile==4:
                shade-=9 if u%21<4 else 0
            if tile==8 and 18<u<110 and 18<v<110:
                shade += -42 if v%13<8 else 18
            if tile==9 and 23<u<105 and 26<v<102:
                shade-=10
                if min(u-23,105-u,v-26,102-v)<3: shade-=21
            rgb=[max(0,min(255,int(c+shade))) for c in colors[tile]]
            if tile==13:
                if inside(u,v): rgb=[198,204,186]
                if 12<u<116 and 13<v<18: rgb=[137,148,137]
                if 84<u<111 and 21<v<26: rgb=[174,181,163]
            if tile==14 and (u+v)//18%2: rgb=[28,32,32]
            if tile==15:
                rgb=[max(0,min(255,c+(18 if v%15<3 else 0))) for c in rgb]
            pixels.extend(reversed(rgb))
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,512,512,24,0)+pixels


def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    meshes=vehicle(); tex=texture()
    (OUTPUT/TEXTURE).write_bytes(tex)
    (OUTPUT/'uwtumbler.w3d').write_bytes(w3d(meshes,model_name=NAME,texture_name=TEXTURE,bones=BONES,origins=ORIGINS))
    (OUTPUT/'uwtbcameo.tga').write_bytes(cameo_tga(meshes,tex))
    grenade=Mesh('GRENADE',0)
    grenade.cylinder((0,0,.5),.32,1.,'z',12,2)
    grenade.cylinder((0,0,1.05),.25,.14,'z',12,5)
    grenade.box((.18,0,1.13),(.45,.12,.14),6)
    grenade.box((0,0,.5),(.03,.03,.03),2)
    (OUTPUT/'uwsmkgren.w3d').write_bytes(w3d([grenade],model_name='UWSMKGREN',texture_name=TEXTURE,bones=[('ROOTTRANSFORM',-1,(0.,0.,0.))],origins=[(0.,0.,0.)]))
    pixels=bytearray()
    for y in range(64):
        for x in range(64):
            r=math.hypot((x-31.5)/32,(y-31.5)/32)
            alpha=max(0.,1-r)**1.6
            pixels.extend((160,156,150,round(alpha*235)))
    (OUTPUT/'uwsmoke.tga').write_bytes(struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,64,64,32,8)+pixels)
    icon=bytearray()
    for y in range(128):
        for x in range(128):
            cloud=any((x-cx)**2+(y-cy)**2<r*r for cx,cy,r in [(40,73,22),(65,87,26),(88,69,24),(65,52,20)])
            rgb=(178,185,181) if cloud else (28,35,40)
            if 52<x<78 and 21<y<39:rgb=(120,135,111)
            icon.extend(reversed(rgb))
    (OUTPUT/'uwsmkbtn.tga').write_bytes(struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,128,128,24,0)+icon)

    lines=['# Original authored fan model; CC0-1.0','mtllib uwtumbler.mtl'];offset=1
    for m in meshes:
        lines+=['o '+m.name,'usemtl TUMBLER']
        lines+=['v %.6f %.6f %.6f'%p for p in m.vertices]
        lines+=['vt %.6f %.6f'%p for p in m.uvs]
        lines+=['vn %.6f %.6f %.6f'%p for p in m.normals]
        lines+=['f '+' '.join(f'{i+offset}/{i+offset}/{i+offset}' for i in f) for f in m.triangles]
        offset+=len(m.vertices)
    (OUTPUT/'uwtumbler.obj').write_text('\n'.join(lines)+'\n')
    (OUTPUT/'uwtumbler.mtl').write_text('newmtl TUMBLER\nKd 1 1 1\nmap_Kd uwtumbler.tga\n')
    verts=[v for m in meshes for v in m.vertices]
    data={'model':NAME,'asset_license':'CC0-1.0','front':'+X','up':'+Z','texture':TEXTURE,
          'triangles':sum(len(m.triangles) for m in meshes),'vertices':len(verts),'rigid_meshes':len(meshes),
          'bounds':{'min':[min(v[i] for v in verts) for i in range(3)],'max':[max(v[i] for v in verts) for i in range(3)]},
          'bones':[{'name':n,'parent':p,'translation':t} for n,p,t in BONES],
          'meshes':[{'name':m.name,'bone':m.bone,'origin':ORIGINS[m.bone],'vertices':m.vertices,'normals':m.normals,'uvs':m.uvs,'triangles':m.triangles,'vertex_count':len(m.vertices),'triangle_count':len(m.triangles)} for m in meshes]}
    (OUTPUT/'uwtumbler.mesh.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(json.dumps({k:data[k] for k in ('model','triangles','vertices','bounds')}))

if __name__=='__main__': main()
