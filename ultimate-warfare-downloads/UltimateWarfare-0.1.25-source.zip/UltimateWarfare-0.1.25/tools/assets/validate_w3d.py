#!/usr/bin/env python3
"""Read and validate the exported classic W3D artifact independently of generation.

SPDX-License-Identifier: MIT
This validates file structure and geometry, not engine/runtime compatibility.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
import struct


CONTAINERS = {0, 0x100, 0x700, 0x702, 0x2A, 0x2B, 0x30, 0x31, 0x38, 0x48}


def require(test, message):
    if not test:
        raise ValueError(message)


def name(raw):
    require(b"\0" in raw, "W3D name must be null-terminated")
    return raw.split(b"\0", 1)[0].decode("ascii")


def chunks(data):
    position = 0
    result = []
    while position < len(data):
        require(position + 8 <= len(data), "Truncated chunk header")
        cid, length = struct.unpack_from("<II", data, position)
        size = length & 0x7FFFFFFF
        end = position + 8 + size
        require(end <= len(data), f"Chunk 0x{cid:x} exceeds parent/file length")
        require(bool(length & 0x80000000) == (cid in CONTAINERS),
                f"Invalid subchunk flag on 0x{cid:x}")
        payload = data[position + 8:end]
        result.append((cid, chunks(payload) if cid in CONTAINERS else payload))
        position = end
    require(position == len(data), "Unconsumed chunk data")
    return result


def one(children, cid):
    entries = [payload for chunk_id, payload in children if chunk_id == cid]
    require(len(entries) == 1, f"Expected exactly one chunk 0x{cid:x}")
    return entries[0]


def vecs(data, width=3):
    require(len(data) % (width * 4) == 0, "Vector payload byte count")
    result = list(struct.iter_unpack("<" + "f" * width, data))
    require(all(math.isfinite(x) for v in result for x in v), "Non-finite vector")
    return result


def close(a, b, tolerance=1e-4):
    return abs(a - b) <= tolerance


def validate(path):
    tumbler = path.stem.lower() == 'uwtumbler'
    grenade = path.stem.lower() == 'uwsmkgren'
    expected_bones = (["ROOTTRANSFORM", "WHEEL_FL", "WHEEL_FR", "WHEEL_RL", "WHEEL_RR", "WHEEL_ML", "WHEEL_MR", "MUZZLE01", "MUZZLE02", "MG_TURRET", "MG_PITCH", "MG_MUZZLE", "SMOKEMZ"] if tumbler else ["ROOTTRANSFORM", "TURRET", "BARREL", "MUZZLE01", "MUZZLE02", "MUZZLE03"])
    if grenade: expected_bones = ['ROOTTRANSFORM']
    expected_texture = 'uwtumbler.tga' if tumbler or grenade else 'uwlongma.tga'
    mesh_count = 11 if tumbler else 1 if grenade else 5
    top = chunks(path.read_bytes())
    require([cid for cid, _ in top] == [0x100] + [0] * mesh_count + [0x700],
            "Expected hierarchy, rigid meshes, HLOD in asset-loading order")
    hierarchy = one(top, 0x100)
    hheader = one(hierarchy, 0x101)
    require(len(hheader) == 36, "W3dHierarchyStruct size")
    hversion, hname, pivot_count, *_ = struct.unpack("<I16sI3f", hheader)
    require(hversion == 0x40001, "Hierarchy4.1 expected")
    hname = name(hname)
    pivots_raw = one(hierarchy, 0x102)
    require(len(pivots_raw) == 60 * pivot_count, "W3dPivotStruct count/size")
    pivots, pivot_world = [], []
    for i, values in enumerate(struct.iter_unpack("<16sI10f", pivots_raw)):
        pname, parent, *rest = values
        require(parent == 0xFFFFFFFF if i == 0 else parent < i,
                "Pivot parent must precede its child; root must have no parent")
        require(all(math.isfinite(x) for x in rest), "Non-finite pivot")
        require(rest[3:] == [0., 0., 0., 0., 0., 0., 1.],
                "Exporter's rigid identity-pivot schema changed")
        pworld = list(rest[:3])
        if parent != 0xFFFFFFFF:
            pworld = [a + b for a, b in zip(pworld, pivot_world[parent])]
        pivots.append(name(pname))
        pivot_world.append(pworld)
    require(pivots == expected_bones, "Required bone names")
    mesh_info = {}
    for cid, mesh in top:
        if cid != 0:
            continue
        raw = one(mesh, 0x1F)
        require(len(raw) == 116, "W3dMeshHeader3Struct size")
        values = struct.unpack("<II16s16s4Ii4I10f", raw)
        version, flags, mname, container = values[:4]
        nt, nv, nm, nd, sort, prelit, future, vc, fc = values[4:13]
        lo, hi, center, radius = values[13:16], values[16:19], values[19:22], values[22]
        mname, cname = name(mname), name(container)
        require(version == 0x40002 and flags == 0x8000, "Mesh4.2 cast-shadow rigid mesh expected")
        require(cname == hname and 0 < nv < 65536 and 0 < nt < 65536,
                "Invalid mesh namespace or engine vertex/index budget")
        require((nm, nd, sort, prelit, future, vc, fc) == (1, 0, 0, 0, 0, 7, 1),
                "Unexpected mesh inventory/channels")
        vertices = vecs(one(mesh, 2))
        normals = vecs(one(mesh, 3))
        require(len(vertices) == len(normals) == nv, "Vertex/normal count")
        require(all(close(sum(x*x for x in n), 1., 2e-4) for n in normals), "Non-unit normal")
        actual_lo = [min(p[i] for p in vertices) for i in range(3)]
        actual_hi = [max(p[i] for p in vertices) for i in range(3)]
        require(all(close(a, b) for a, b in zip(lo + hi, actual_lo + actual_hi)), "Bounding box mismatch")
        require(all(sum((p[i] - center[i])**2 for i in range(3)) <= (radius + 1e-4)**2
                    for p in vertices), "Bounding sphere does not contain mesh")
        triangles_raw = one(mesh, 0x20)
        require(len(triangles_raw) == nt * 32, "W3dTriStruct count/size")
        for a, b, c, attr, nx, ny, nz, distance in struct.iter_unpack("<4I4f", triangles_raw):
            require(max(a, b, c) < nv and len({a, b, c}) == 3, "Triangle index invalid")
            p, q, r = vertices[a], vertices[b], vertices[c]
            u, v = [q[i] - p[i] for i in range(3)], [r[i] - p[i] for i in range(3)]
            area = (u[1]*v[2] - u[2]*v[1], u[2]*v[0] - u[0]*v[2], u[0]*v[1] - u[1]*v[0])
            mag = math.sqrt(sum(x*x for x in area))
            require(mag > 1e-8 and attr == 1, "Degenerate triangle or non-heavy-metal surface")
            n = (nx, ny, nz)
            require(all(close(area[i]/mag, n[i], 2e-4) for i in range(3)), "Triangle winding/normal mismatch")
            require(close(sum(n[i]*p[i] for i in range(3)), distance), "Triangle plane distance mismatch")
        require(one(mesh, 0x28) == struct.pack("<4I", 1, 1, 1, 1), "One material/pass/texture required")
        require(len(one(mesh, 0x29)) == 16, "W3dShaderStruct size")
        material = one(one(mesh, 0x2A), 0x2B)
        require(len(one(material, 0x2D)) == 32, "W3dVertexMaterialStruct size")
        texture = one(one(mesh, 0x30), 0x31)
        tname = one(texture, 0x32).rstrip(b"\0").decode("ascii")
        require(tname == expected_texture and (path.parent / tname).is_file(), "Missing texture dependency")
        require(len(one(texture, 0x33)) == 12, "W3dTextureInfoStruct size")
        material_pass = one(mesh, 0x38)
        require(one(material_pass, 0x39) == one(material_pass, 0x3A) == b"\0" * 4,
                "Invalid single material/shader IDs")
        stage = one(material_pass, 0x48)
        require(one(stage, 0x49) == b"\0" * 4, "Invalid texture IDs")
        uv = vecs(one(stage, 0x4A), 2)
        require(len(uv) == nv and all(0 <= x <= 1 for pair in uv for x in pair),
                "Vertex UV count/range invalid")
        mesh_info[cname + "." + mname] = {"vertices": nv, "triangles": nt, "local_bounds": [lo, hi]}
    hlod = one(top, 0x700)
    header = one(hlod, 0x701)
    require(len(header) == 40, "W3dHLodHeaderStruct size")
    version, lod_count, lod_name, hierarchy_name = struct.unpack("<II16s16s", header)
    require(version == 0x10000 and lod_count == 1 and name(lod_name) == name(hierarchy_name) == hname,
            "Invalid HLOD hierarchy/version/count")
    lod = one(hlod, 0x702)
    count, max_screen = struct.unpack("<If", one(lod, 0x703))
    require(count == len(mesh_info) and math.isfinite(max_screen) and max_screen > 1.e30,
            "HLOD subobject count or max screen size")
    objects = []
    for cid, payload in lod:
        if cid == 0x704:
            require(len(payload) == 36, "W3dHLodSubObjectStruct size")
            bone, raw_name = struct.unpack("<I32s", payload)
            objname = name(raw_name)
            require(bone < pivot_count and objname in mesh_info, "Invalid HLOD mesh/bone reference")
            objects.append(objname)
    require(set(objects) == set(mesh_info) and len(objects) == len(mesh_info), "Unconnected/duplicate mesh")
    require(grenade or hname + ".HOUSECOLOR" in mesh_info, "Native player-color mesh missing")
    tga = (path.parent / expected_texture).read_bytes()
    header = struct.unpack("<BBBHHBHHHHBB", tga[:18])
    require(header == (0, 0, 2, 0, 0, 0, 0, 0, 512, 512, 24, 0), "Unsupported TGA shape/encoding")
    require(len(tga) == 18 + 512 * 512 * 3, "Truncated TGA")
    return {"valid": True, "model": hname, "bones": pivots, "bone_world_positions": pivot_world,
            "meshes": mesh_info, "triangles": sum(m["triangles"] for m in mesh_info.values()),
            "vertices": sum(m["vertices"] for m in mesh_info.values()),
            "limitation": "Binary and geometry checks; original Zero Hour runtime validation still required"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path, nargs="?", default=Path(__file__).resolve().parents[2]
                        / "assets/generated/uwlongma.w3d")
    args = parser.parse_args()
    print(json.dumps(validate(args.path), indent=2))
