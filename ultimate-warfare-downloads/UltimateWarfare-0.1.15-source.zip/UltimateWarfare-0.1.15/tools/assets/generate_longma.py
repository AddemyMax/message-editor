#!/usr/bin/env python3
"""Original Longma model and classic W3D exporter. Python standard library only.

SPDX-License-Identifier: MIT
Binary layout checked against EA's released GeneralsMD WW3D2/w3d_file.h,
htree.cpp, hlod.cpp, meshmdlio.cpp, and WWLib/chunkio.cpp. This is an original
implementation of that documented layout, not copied engine/exporter code.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import random
import struct


NAME = "UWLONGMA"
TEXTURE = "uwlongma.tga"
UNIT_SCALE = 1.6
V3 = tuple[float, float, float]
BONES = [
    ("ROOTTRANSFORM", -1, (0.0, 0.0, 0.0)),
    ("TURRET", 0, (-0.2, 0.0, 5.0)),
    ("BARREL", 1, (3.4, 0.0, 1.8)),
    ("MUZZLE01", 2, (12.55, -1.35, 0.0)),
    ("MUZZLE02", 2, (12.55, 0.0, 0.0)),
    ("MUZZLE03", 2, (12.55, 1.35, 0.0)),
]
BONES = [(name, parent, tuple(x * UNIT_SCALE for x in pos)) for name, parent, pos in BONES]
ORIGINS = [tuple(x * UNIT_SCALE for x in pos) for pos in [(0., 0., 0.), (-.2, 0., 5.), (3.2, 0., 6.8)]]


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def normal(a, b, c):
    n = cross(sub(b, a), sub(c, a))
    mag = math.sqrt(dot(n, n))
    if mag < 1.e-8:
        raise ValueError("Degenerate geometry")
    return tuple(x / mag for x in n)


class Mesh:
    def __init__(self, name, bone):
        self.name, self.bone = name, bone
        self.vertices, self.normals, self.uvs, self.triangles = [], [], [], []

    def face(self, points, tile=0):
        """Weld within a polygon; split at normal/UV boundaries, as W3D needs."""
        n = normal(*points[:3])
        start = len(self.vertices)
        self.vertices.extend(points)
        self.normals.extend([n] * len(points))
        col, row = tile % 4, tile // 4
        # Texture is generated with a bottom-left origin. W3D stores MAX-style
        # bottom-left V; meshmdlio.cpp changes V to 1-V for Direct3D at load.
        for u, v in [(0.04, .04), (.96, .04), (.96, .96), (.04, .96)][:len(points)]:
            self.uvs.append(((col + u) / 4, (row + v) / 4))
        for i in range(1, len(points) - 1):
            self.triangles.append((start, start + i, start + i + 1))

    def box(self, center, size, tile=0, yaw=0., roll=0.):
        x, y, z = (v / 2 for v in size)
        pts = [(-x, -y, -z), (x, -y, -z), (x, y, -z), (-x, y, -z),
               (-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z)]
        converted = []
        for px, py, pz in pts:
            rx = px * math.cos(roll) + pz * math.sin(roll)
            rz = -px * math.sin(roll) + pz * math.cos(roll)
            converted.append(add(center, (rx * math.cos(yaw) - py * math.sin(yaw),
                                          rx * math.sin(yaw) + py * math.cos(yaw), rz)))
        for ids in [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                    (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]:
            self.face([converted[i] for i in ids], tile)

    def prism(self, bottom, top, z0, z1, tile=0):
        """Two CCW convex rings, beveled slopes if rings differ."""
        a = [(x, y, z0) for x, y in bottom]
        b = [(x, y, z1) for x, y in top]
        n = len(a)
        center_a = tuple(sum(p[j] for p in a) / n for j in range(3))
        center_b = tuple(sum(p[j] for p in b) / n for j in range(3))
        for i in range(n):
            j = (i + 1) % n
            self.face([a[i], a[j], b[j], b[i]], tile)
            self.face([center_a, a[j], a[i]], tile)
            self.face([center_b, b[i], b[j]], tile)

    def cylinder(self, center, radius, length, axis="z", segments=12, tile=4):
        def point(theta, end):
            c, s = radius * math.cos(theta), radius * math.sin(theta)
            off = {"x": (end, c, s), "y": (c, end, s), "z": (c, s, end)}[axis]
            return add(center, off)
        # Axis Y mapping has a negative determinant; reverse to retain CCW.
        angles = [i * math.tau / segments * (-1 if axis == "y" else 1)
                  for i in range(segments)]
        ring0 = [point(a, -length / 2) for a in angles]
        ring1 = [point(a, length / 2) for a in angles]
        center0, center1 = point(0., -length / 2), point(0., length / 2)
        # Use actual axis centers, not circumference points.
        offset = {"x": (length / 2, 0., 0.), "y": (0., length / 2, 0.),
                  "z": (0., 0., length / 2)}[axis]
        center0, center1 = sub(center, offset), add(center, offset)
        for i in range(segments):
            j = (i + 1) % segments
            self.face([ring0[i], ring0[j], ring1[j], ring1[i]], tile)
            self.face([center0, ring0[j], ring0[i]], tile)
            self.face([center1, ring1[i], ring1[j]], tile)


def tank():
    hull, turret, barrel = Mesh("HULL", 0), Mesh("TURRET", 1), Mesh("GUN", 2)
    housecolor = Mesh("HOUSECOLOR", 0)
    # Fresh fictional design: a low wedge hull, ERA cheek armor and rectangular
    # bustle. Every primitive and dimension is authored here, never imported.
    lower = [(-10.4, -3.7), (8.8, -3.7), (10.2, -2.9), (10.2, 2.9),
             (8.8, 3.7), (-10.4, 3.7), (-11., 2.8), (-11., -2.8)]
    upper = [(-10., -4.0), (7.3, -4.0), (9.4, -3.0), (9.4, 3.0),
             (7.3, 4.0), (-10., 4.0), (-10.6, 3.0), (-10.6, -3.0)]
    hull.prism(lower, upper, 1.6, 4.2, 0)
    hull.box((-5.8, 0., 4.3), (6., 7.7, .35), 1)
    hull.box((6.9, 0., 4.42), (4.0, 7.5, .5), 1, roll=-.12)
    # Engine deck grills, fenders and exhausts.
    for k in range(13):
        hull.box((-9.4 + .31 * k, 0., 4.56), (.12, 5.6, .1), 6)
    for sign in (-1, 1):
        y = sign * 4.85
        hull.box((-.4, y, 4.1), (20.6, 2.05, .3), 1)
        # The track path is a rounded rectangular loop around seven wheels.
        # Each link is a separate low-poly block with a proud grouser.
        for x in [(-8.4 + 2.8 * i) for i in range(7)]:
            hull.cylinder((x, y, 1.82), 1.42, 1.72, "y", 12, 4)
            hull.cylinder((x, y + sign * .89, 1.82), .64, .16, "y", 12, 7)
            hull.cylinder((x, y + sign * 1.0, 1.82), .22, .18, "y", 8, 5)
        path = []
        for i in range(26):
            path.append((-8.4 + 16.8 * i / 25, 3.39, 0.))
        for i in range(12):
            ang = math.pi / 2 - math.pi * (i + .5) / 12
            path.append((8.4 + 1.57 * math.cos(ang), 1.82 + 1.57 * math.sin(ang),
                         math.pi / 2 - ang))
        for i in range(26):
            path.append((8.4 - 16.8 * i / 25, .25, 0.))
        for i in range(12):
            ang = -math.pi / 2 - math.pi * (i + .5) / 12
            path.append((-8.4 + 1.57 * math.cos(ang), 1.82 + 1.57 * math.sin(ang),
                         math.pi / 2 - ang))
        for x, z, rot in path:
            hull.box((x, y, z), (.57, 1.95, .23), 6, roll=rot)
            hull.box((x, y, z + (.14 if z > 1.82 else -.14)), (.18, 2.05, .12), 5,
                     roll=rot)
        # Five broad side-skirt armor plates stay attached to the hull.
        for i in range(5):
            hull.box((-7.8 + 3.6 * i, sign * 5.95, 3.36), (3.4, .24, 1.65), i % 3)
        hull.box((-10.5, sign * 2.6, 3.1), (.5, 1.5, .75), 6)
        hull.box((8.2, sign * 3.2, 4.68), (.63, .57, .35), 8)
        # Tow-hook mounts: no insignia borrowed from another game.
        hull.box((9.9, sign * 2., 2.15), (.55, .38, .56), 5)
    hull.box((-10.4, 0., 4.25), (.44, 5.2, .44), 2)
    # Native W3DAssetManager::Recolor_Mesh recolors the vertex material of
    # meshes whose name starts HOUSECOLOR. Neutral atlas panels retain clear
    # owner colors without recoloring the entire olive camouflage texture.
    for sign in (-1, 1):
        for x in (-7.8, 3.0):
            housecolor.box((x, sign * 6.095, 3.4), (1.4, .05, .64), 10)
    housecolor.box((9.96, 0., 2.4), (.06, 1.1, .7), 10, roll=-.30)
    housecolor.box((-10.85, 0., 2.75), (.06, 1.2, .7), 10, roll=.1526)
    # Turret ring and faceted armored turret.
    turret.cylinder((-.2, 0., 4.72), 3.25, .62, "z", 24, 5)
    ring0 = [(-5.6, -3.), (1.7, -3.6), (4., -2.6), (4.4, -1.2),
             (4.4, 1.2), (4., 2.6), (1.7, 3.6), (-5.6, 3.)]
    ring1 = [(-5.1, -2.5), (1.2, -2.9), (3.4, -2.1), (3.5, -1.),
             (3.5, 1.), (3.4, 2.1), (1.2, 2.9), (-5.1, 2.5)]
    turret.prism(ring0, ring1, 5.04, 7.32, 0)
    turret.box((-4.6, 0., 6.1), (3.6, 6.3, 1.7), 2)
    # Cheek ERA blocks form a recognizable, original zig-zag armored silhouette.
    for sign in (-1, 1):
        for i in range(5):
            for j in range(2):
                turret.box((1. + i * .56, sign * (3.15 - i * .24), 5.7 + j * .76),
                           (.73, .73, .54), (i + j) % 3, yaw=-sign * .37)
        for i in range(8):
            turret.box((-4.8 + i * .57, sign * 3.25, 6.25), (.43, .47, 1.13), 2)
        # Six smoke-grenade barrels on each side.
        for i in range(6):
            turret.cylinder((-3.65 + i * .42, sign * 3.5, 7.02), .14, .55,
                            "z", 8, 5)
        turret.box((-5.8, sign * 2.85, 7.02), (1.5, .28, .15), 5)
    turret.cylinder((-1.4, 1.45, 7.45), .95, .22, "z", 16, 1)
    turret.cylinder((-.1, -1.25, 7.42), .86, .2, "z", 16, 1)
    turret.box((1.5, -.5, 7.72), (1.1, .68, .5), 2)
    turret.box((2.08, -.5, 7.75), (.08, .49, .3), 8)
    turret.box((.12, -1.4, 7.84), (1.3, .37, .25), 5)
    turret.cylinder((.74, -1.4, 7.9), .08, 1.4, "x", 8, 5)
    turret.cylinder((-4.85, -2., 8.65), .043, 2.5, "z", 6, 5)
    turret.box((-4.85, -2., 7.48), (.28, .28, .26), 7)
    turret.box((-4.9, 1., 7.44), (.9, 1.3, .26), 7)
    # A wide, faceted turret and three distinct armored cannon jackets give
    # the silhouette readable weight at the native RTS camera distance.
    for sign in (-1, 1):
        turret.box((-.5, sign * 3.65, 6.35), (6.8, 1.1, 1.5), 1, yaw=sign * .13)
        turret.box((-4.6, sign * 3.6, 6.6), (2.4, .9, 1.5), 2)
        hull.box((2.4, sign * 5.9, 3.8), (8.2, .36, 1.65), 1)
        hull.box((7.3, sign * 2.5, 4.55), (3.3, 1.55, .55), 3, roll=-.14)
    barrel.box((3.4, 0., 6.8), (2.05, 4.7, 1.8), 2)
    for y in (-1.35, 0., 1.35):
        barrel.cylinder((8.9, y, 6.8), .32, 12.1, "x", 12, 5)
        barrel.box((5.6, y, 6.8), (4.3, .95, .92), 1)
        barrel.box((8.5, y, 6.8), (1.15, .85, .82), 2)
        for x in (4.15, 7.6, 11.1):
            barrel.cylinder((x, y, 6.8), .43, .22, "x", 12, 7)
        barrel.box((14.9, y, 6.8), (1.6, .92, .82), 5)
        barrel.box((15.715, y, 6.8), (.04, .59, .48), 6)
        for x in (14.5, 15.0, 15.5):
            for sign in (-1, 1):
                barrel.box((x, y + sign * .465, 6.8), (.22, .025, .38), 6)
    for mesh in (hull, turret, barrel, housecolor):
        mesh.vertices = [tuple(value * UNIT_SCALE for value in point) for point in mesh.vertices]
    return [hull, turret, barrel, housecolor]


def fixed_name(name, length=16):
    raw = name.encode("ascii")
    if len(raw) >= length:
        raise ValueError(f"W3D name too long: {name}")
    return raw + b"\0" * (length - len(raw))


def chunk(cid, payload, container=False):
    if len(payload) >= 0x80000000:
        raise ValueError("W3D chunk too large")
    return struct.pack("<II", cid, len(payload) | (0x80000000 if container else 0)) + payload


def container(cid, children):
    return chunk(cid, b"".join(children), True)


def mesh_chunk(mesh):
    origin = ORIGINS[mesh.bone]
    verts = [sub(p, origin) for p in mesh.vertices]
    lo = tuple(min(p[i] for p in verts) for i in range(3))
    hi = tuple(max(p[i] for p in verts) for i in range(3))
    center = tuple((a + b) / 2 for a, b in zip(lo, hi))
    radius = max(math.sqrt(dot(sub(p, center), sub(p, center))) for p in verts)
    header = (struct.pack("<II", 0x40002, 0x8000)
              + fixed_name(mesh.name) + fixed_name(NAME)
              + struct.pack("<4Ii4I", len(mesh.triangles), len(verts), 1, 0, 0, 0, 0, 7, 1)
              + struct.pack("<10f", *lo, *hi, *center, radius))
    assert len(header) == 116
    vmat = (struct.pack("<I", 0) + bytes([255, 255, 255, 0] * 2)
            + bytes([36, 36, 36, 0, 0, 0, 0, 0]) + struct.pack("<3f", 14., 1., 0.))
    shader = bytes([3, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0])
    triangles = []
    for a, b, c in mesh.triangles:
        n = normal(verts[a], verts[b], verts[c])
        triangles.append(struct.pack("<4I4f", a, b, c, 1, *n, dot(n, verts[a])))
    return container(0, [
        chunk(0x1F, header),
        chunk(2, b"".join(struct.pack("<3f", *p) for p in verts)),
        chunk(3, b"".join(struct.pack("<3f", *p) for p in mesh.normals)),
        chunk(0x20, b"".join(triangles)),
        chunk(0x28, struct.pack("<4I", 1, 1, 1, 1)),
        chunk(0x29, shader),
        container(0x2A, [container(0x2B, [chunk(0x2C, b"LONGMA_PAINT\0"),
                                        chunk(0x2D, vmat)])]),
        container(0x30, [container(0x31, [chunk(0x32, TEXTURE.encode() + b"\0"),
                                        chunk(0x33, struct.pack("<HHIf", 0, 0, 1, 0.))])]),
        container(0x38, [chunk(0x39, struct.pack("<I", 0)), chunk(0x3A, struct.pack("<I", 0)),
                         container(0x48, [chunk(0x49, struct.pack("<I", 0)),
                                          chunk(0x4A, b"".join(struct.pack("<2f", *uv)
                                                              for uv in mesh.uvs))])]),
    ])


def w3d(meshes):
    hierarchy = container(0x100, [
        chunk(0x101, struct.pack("<I16sI3f", 0x40001, fixed_name(NAME), len(BONES), 0., 0., 0.)),
        chunk(0x102, b"".join(struct.pack("<16sI10f", fixed_name(name), parent & 0xFFFFFFFF,
                                          *pos, 0., 0., 0., 0., 0., 0., 1.)
                              for name, parent, pos in BONES)),
    ])
    hlod = container(0x700, [
        chunk(0x701, struct.pack("<II16s16s", 0x10000, 1, fixed_name(NAME), fixed_name(NAME))),
        container(0x702, [chunk(0x703, struct.pack("<If", len(meshes), 3.4028234663852886e38))]
                  + [chunk(0x704, struct.pack("<I32s", m.bone, fixed_name(NAME + "." + m.name, 32)))
                     for m in meshes]),
    ])
    # Asset manager processes definitions in file order: hierarchy, meshes, HLOD.
    return hierarchy + b"".join(mesh_chunk(m) for m in meshes) + hlod


def texture_tga():
    """Own 512px atlas: paint, rubber, steel and glass; seeded repeatable wear."""
    size = 512
    rng = random.Random(50430)
    colors = [(84, 99, 78), (118, 132, 108), (55, 68, 60), (165, 153, 114),
              (32, 37, 38), (61, 69, 73), (18, 23, 25), (158, 139, 93),
              (76, 158, 181), (89, 42, 33), (205, 205, 205), (127, 139, 100),
              (76, 90, 62), (98, 114, 95), (72, 83, 73), (114, 126, 104)]
    pixels = bytearray()
    for y in range(size):
        for x in range(size):
            tile = (y // 128) * 4 + x // 128
            px, py = x % 128, y % 128
            base = colors[tile]
            grain = rng.randint(-5, 5)
            # Small nicks at plate edges and understated camo patches.
            if tile < 4 or tile > 10:
                camo = (math.sin(px * .049 + py * .04) + math.sin(py * .067 - px * .034))
                grain += 9 if camo > .92 else (-9 if camo < -.9 else 0)
            if min(px, py, 127 - px, 127 - py) < 3:
                grain -= 15
            if tile == 6 and (py % 19 < 2 or px % 32 < 2):
                grain += 22
            if tile == 8:
                grain += int((px + py) * .12)
            rgb = [max(0, min(255, c + grain)) for c in base]
            pixels.extend(reversed(rgb))
    # Uncompressed 24-bit RGB; origin bit=0 (bottom-left), no alpha channel.
    return struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, size, size, 24, 0) + pixels


def muzzle_tga():
    """Original radial burst, RGB falloff for SAGE's ONE+ONE additive shader.

    The native additive particle preset ignores texture alpha in its blend
    factors, so RGB must fall to black at the edges as well as storing alpha.
    """
    size = 64
    pixels = bytearray()
    for y in range(size):
        for x in range(size):
            fx, fy = (x + .5 - size / 2) / (size / 2), (y + .5 - size / 2) / (size / 2)
            r = math.hypot(fx, fy)
            ang = math.atan2(fy, fx)
            core = max(0., 1. - r / .48) ** 1.5
            rays = max(0., math.cos(ang * 6)) ** 14 * max(0., 1. - r) ** 1.7
            alpha = min(1., core * 1.45 + rays * .9)
            red, green, blue = 255, int(158 + 97 * core), int(48 + 207 * core)
            pixels.extend((round(blue * alpha), round(green * alpha),
                           round(red * alpha), round(alpha * 255)))
    return struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, size, size, 32, 8) + pixels


def cameo_tga(meshes, texture):
    """Small genuine rendering of our geometry, using only a stdlib z-buffer."""
    size = 256
    direction = (32., -38., 24.)
    length = math.sqrt(dot(direction, direction))
    direction = tuple(x / length for x in direction)
    right = cross((0., 0., 1.), direction)
    length = math.sqrt(dot(right, right))
    right = tuple(x / length for x in right)
    up = cross(direction, right)
    illumination = (.35, -.52, .77)
    projected = [[(dot(v, right), dot(v, up), dot(v, direction)) for v in m.vertices]
                 for m in meshes]
    values = [p for item in projected for p in item]
    xmin, xmax = min(p[0] for p in values), max(p[0] for p in values)
    ymin, ymax = min(p[1] for p in values), max(p[1] for p in values)
    scale = (size - 30) / max(xmax - xmin, ymax - ymin)
    cx, cy = (xmax + xmin) / 2, (ymax + ymin) / 2
    image = [(24 + y // 20, 29 + y // 22, 22 + y // 32) for y in range(size) for _ in range(size)]
    depth = [-math.inf] * (size * size)
    for m, screen in zip(meshes, projected):
        positions = [((p[0] - cx) * scale + size / 2, (p[1] - cy) * scale + size / 2, p[2])
                     for p in screen]
        for indices in m.triangles:
            a, b, c = [positions[i] for i in indices]
            n = m.normals[indices[0]]
            if dot(n, direction) <= 0:
                continue
            area = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
            if abs(area) < 1.e-8:
                continue
            brightness = .48 + .62 * max(0., dot(n, illumination))
            uv = [m.uvs[i] for i in indices]
            for py in range(max(0, math.floor(min(a[1], b[1], c[1]))),
                            min(size, math.ceil(max(a[1], b[1], c[1])))):
                for px in range(max(0, math.floor(min(a[0], b[0], c[0]))),
                                min(size, math.ceil(max(a[0], b[0], c[0])))):
                    w0 = ((b[1] - c[1]) * (px + .5 - c[0]) + (c[0] - b[0]) * (py + .5 - c[1])) / area
                    w1 = ((c[1] - a[1]) * (px + .5 - c[0]) + (a[0] - c[0]) * (py + .5 - c[1])) / area
                    w2 = 1 - w0 - w1
                    if min(w0, w1, w2) < 0:
                        continue
                    z = w0 * a[2] + w1 * b[2] + w2 * c[2]
                    index = py * size + px
                    if z <= depth[index]:
                        continue
                    depth[index] = z
                    tx = min(511, int(sum(w * t[0] for w, t in zip((w0, w1, w2), uv)) * 512))
                    ty = min(511, int(sum(w * t[1] for w, t in zip((w0, w1, w2), uv)) * 512))
                    start = 18 + 3 * (ty * 512 + tx)
                    rgb = list(reversed(texture[start:start + 3]))
                    image[index] = tuple(min(255, int(ch * brightness)) for ch in rgb)
    pixels = bytearray()
    for y in range(128):
        for x in range(128):
            rgb = [sum(image[(y * 2 + dy) * size + x * 2 + dx][channel]
                       for dy in (0, 1) for dx in (0, 1)) // 4 for channel in range(3)]
            if x in (1, 126) or y in (1, 126):
                rgb = [143, 150, 102]
            pixels.extend(reversed(rgb))
    return struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, 128, 128, 24, 0) + pixels


def write_obj(meshes, output):
    lines = ["# Original procedural Longma; asset license CC0-1.0", "mtllib uwlongma.mtl"]
    offset = 1
    for m in meshes:
        lines += ["o " + m.name, "usemtl LONGMA_PAINT"]
        lines += ["v %.6f %.6f %.6f" % p for p in m.vertices]
        lines += ["vt %.6f %.6f" % p for p in m.uvs]
        lines += ["vn %.6f %.6f %.6f" % p for p in m.normals]
        for face in m.triangles:
            lines.append("f " + " ".join(f"{i + offset}/{i + offset}/{i + offset}" for i in face))
        offset += len(m.vertices)
    (output / "uwlongma.obj").write_text("\n".join(lines) + "\n")
    (output / "uwlongma.mtl").write_text("newmtl LONGMA_PAINT\nKa 1 1 1\nKd 1 1 1\nKs .14 .14 .14\nNs 14\nd 1\nmap_Kd uwlongma.tga\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[2] / "assets/generated")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    meshes = tank()
    (args.output / "uwlongma.w3d").write_bytes(w3d(meshes))
    texture = texture_tga()
    (args.output / TEXTURE).write_bytes(texture)
    (args.output / "uwmflash.tga").write_bytes(muzzle_tga())
    (args.output / "uwlmcameo.tga").write_bytes(cameo_tga(meshes, texture))
    write_obj(meshes, args.output)
    all_vertices = [v for m in meshes for v in m.vertices]
    bounds = {"min": [min(v[i] for v in all_vertices) for i in range(3)],
              "max": [max(v[i] for v in all_vertices) for i in range(3)]}
    data = {"model": NAME, "asset_license": "CC0-1.0", "front": "+X", "up": "+Z",
            "triangles": sum(len(m.triangles) for m in meshes),
            "vertices": sum(len(m.vertices) for m in meshes), "rigid_meshes": len(meshes),
            "texture": TEXTURE,
            "bounds": bounds, "bones": [{"name": n, "parent": p, "translation": t}
                                           for n, p, t in BONES],
            "meshes": [{"name": m.name, "bone": m.bone, "origin": ORIGINS[m.bone],
                        "vertex_count": len(m.vertices), "triangle_count": len(m.triangles),
                        "vertices": m.vertices, "normals": m.normals,
                        "uvs": m.uvs, "triangles": m.triangles} for m in meshes]}
    (args.output / "uwlongma.mesh.json").write_text(json.dumps(data, separators=(",", ":")) + "\n")
    print(json.dumps({"model": NAME, "triangles": sum(len(m.triangles) for m in meshes),
                      "vertices": sum(len(m.vertices) for m in meshes), "bounds": bounds}))


if __name__ == "__main__":
    main()
