"""Compiler integration against authored fixtures, NOT native game testing.

These deliberately minimal objects are invented test data. No commercial INI,
game executable, or third-party model is embedded or executed by this suite.
"""

from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import unittest

# Mirror tools/build_mod.py's sibling-module lookup without installing packages.
PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "tools"))

from uwmod.archive import read_big, write_big
from uwmod.ini import IniError, parse_ini
from uwmod.project import BuildError, GameSource, MONOLITHIC, compile_project, main, validate_archive


def invented_game_files():
    """Stock-shaped syntax with invented values/resources for compiler tests."""
    return {
        "Data/INI/CommandSet.ini": b"""; Authored fixture menu.
CommandSet FixtureUnrelated
  1 = Command_Unrelated
End
CommandSet FixtureFactoryCommands
  1 = Command_Original
  3 = Command_OriginalUpgrade
  13 = Command_Rally
  14 = Command_Sell
End
""",
        "Data/INI/CommandButton.ini": b"""CommandButton Command_Original
  Command = UNIT_BUILD
  Object = ChinaTankBattleMaster
End
""",
        "Data/INI/Weapon.ini": b"""Weapon FixtureGun
  PrimaryDamage = 40
  AttackRange = 150
  DelayBetweenShots = 1000
  FireFX = FixtureMuzzle
End
Weapon FixtureEliteGun
  PrimaryDamage = 80
  AttackRange = 160
  DelayBetweenShots = 900
  FireFX = FixtureMuzzle
End
""",
        "Data/INI/Armor.ini": b"""Armor FixtureArmor
  Armor = DEFAULT 100%
  Armor = SMALL_ARMS 50%
End
""",
        "Data/INI/Locomotor.ini": b"""Locomotor FixtureLocomotor
  Speed = 30
  SpeedDamaged = 20
End
""",
        "Data/INI/FXList.ini": b"""FXList FixtureMuzzle
  Sound
    Name = FixtureFiringSound
  End
End
""",
        "Data/INI/ParticleSystem.ini": b"""ParticleSystem FixtureParticle
  Priority = WEAPON_EXPLOSION
End
""",
        "Data/INI/Object/FixtureSource.ini": b"""; Invented minimal test objects.
Object ChinaTankBattleMaster
  Draw = W3DModelDraw ModuleTag_Draw
    DefaultConditionState
      Model = FixtureOriginal
      Turret = FixtureTurret
    End
    AliasConditionState = REALLYDAMAGED
  End
  WeaponSet
    Conditions = NONE
    Weapon = PRIMARY FixtureGun
  End
  WeaponSet
    Conditions = HERO
    Weapon = PRIMARY FixtureEliteGun
  End
  ArmorSet
    Conditions = NONE
    Armor = FixtureArmor
    DamageFX = FixtureTankDamageFX
  End
  Body = ActiveBody ModuleTag_Body
    MaxHealth = 400
    InitialHealth = 400
  End
  Behavior = AIUpdateInterface ModuleTag_AI
    Turret
      ControlledWeaponSlots = PRIMARY
      TurretTurnRate = 100
    End
  End
  Locomotor = SET_NORMAL FixtureLocomotor
  Behavior = PhysicsBehavior ModuleTag_Physics
    Mass = 30
  End
  BuildCost = 800
  BuildTime = 12
End
Object ChinaWarFactory
  CommandSet = FixtureFactoryCommands
End
Object ChinaPropagandaCenter
  BuildCost = 2000
End
""",
        "Data/Generals.str": b'ORIGINAL:Fixture\n"Original fixture label"\nEND\n',
    }


class ProjectIntegrationTests(unittest.TestCase):
    def test_three_gun_salvo_preserves_armor_and_uses_separate_muzzle_bones(self):
        files, report = compile_project(GameSource(self.game), self.project)
        obj, = parse_ini(files['Data\\INI\\Object\\ChinaTankUWLongma.ini']).blocks
        draw = next(child for child in obj.children if child.kind.lower() == 'draw')
        self.assertEqual(draw.children[0].find_fields('WeaponLaunchBone')[0].value, 'PRIMARY MUZZLE')
        self.assertEqual(obj.find_fields('GeometryMajorRadius')[0].value, '17.6')
        weapons = parse_ini(files['Data\\INI\\Weapon.ini'])
        for new in report['units'][0]['weapons'].values():
            weapon = weapons.find_block('Weapon', new)
            self.assertEqual(weapon.find_fields('ClipSize')[0].value, '3')
            self.assertEqual(weapon.find_fields('ShotsPerBarrel')[0].value, '1')
            self.assertEqual(weapon.find_fields('DelayBetweenShots')[0].value, '180')
            self.assertEqual(weapon.find_fields('ClipReloadTime')[0].value, '6300')
        # Binary muzzle positions must be distinct, forward-facing, and share
        # the barrel pitch parent so all three move with the weapon cradle.
        from tools.assets.validate_w3d import chunks
        hierarchy = next(payload for cid, payload in chunks(files['Art\\W3D\\uwlongma.w3d']) if cid == 0x100)
        pivots = next(payload for cid, payload in hierarchy if cid == 0x102)
        muzzle = [record for record in struct.iter_unpack('<16sI10f', pivots)
                  if record[0].startswith(b'MUZZLE')]
        self.assertEqual(len(muzzle), 3)
        self.assertTrue(all(record[1] == 2 for record in muzzle))
        self.assertEqual(len({round(record[3], 3) for record in muzzle}), 3)
        self.assertTrue(all(record[2] > 20 for record in muzzle))
        self.assert_original_unchanged()

    def test_longma_decal_shadow_replaces_source_volume_without_editing_original_tank(self):
        # Locate the authored source object, independent of fixture filename.
        path = next(name for name, data in self.fixture.items()
                    if name.lower().startswith('data/ini/object/') and b'Object ChinaTankBattleMaster\n' in data)
        self.fixture[path] = self.fixture[path].replace(b'Object ChinaTankBattleMaster\n',
            b'Object ChinaTankBattleMaster\n  Shadow = SHADOW_VOLUME\n  ShadowSizeX = 99\n  ShadowSizeY = 98\n  ShadowTexture = FixtureShadow\n')
        self.write_fixture()
        files, _ = compile_project(GameSource(self.game), self.project)
        obj, = parse_ini(files['Data\\INI\\Object\\ChinaTankUWLongma.ini']).blocks
        self.assertEqual([f.value for f in obj.find_fields('Shadow')], ['SHADOW_DECAL'])
        self.assertEqual([f.value for f in obj.find_fields('ShadowTexture')], ['shadow'])
        self.assertEqual([f.value for f in obj.find_fields('ShadowSizeX')], ['48'])
        self.assertEqual([f.value for f in obj.find_fields('ShadowSizeY')], ['26'])
        self.assertIn(b'Shadow = SHADOW_VOLUME', GameSource(self.game).read(path))
        self.assertNotIn(path.replace('/', '\\'), files)
        self.assert_original_unchanged()

    def test_full_factory_and_legacy_csf_build_without_rewriting_localized_records(self):
        from test_localization import make_csf
        self.fill_factory()
        del self.fixture["Data/Generals.str"]
        original = make_csf([(b"FIXTURE:\xc0\xff", [("Авторская строка", b"FixtureSpeech")]),
                             (b"fixture:\xc0\xff", [("Вторая авторская строка", None)])])
        original = original[:12] + struct.pack("<I", 1) + original[16:]
        self.fixture["Data/Russian/Generals.csf"] = original
        self.write_fixture()
        files, report = compile_project(GameSource(self.game), self.project)
        actual = files["Data\\Russian\\Generals.csf"]
        self.assertEqual(actual[24:len(original)], original[24:])
        self.assertEqual(struct.unpack_from("<II", actual, 8), (5, 5))
        self.assertEqual(report["units"][0]["production_slot"], 15)
        output = self.root / "LegacyLocale.big"
        output.write_bytes(write_big(files))
        self.assertEqual(validate_archive(output)["status"], "structurally_valid")
        self.assert_original_unchanged()

    def fill_factory(self):
        self.fixture["Data/INI/CommandSet.ini"] = (
            b"CommandSet FixtureFactoryCommands\n" +
            b"".join(f"  {slot} = Command_Fixture{slot}\n".encode("ascii") for slot in range(1, 15)) + b"End\n")
        from test_interface import authored_panel
        self.fixture["Window/ControlBar.wnd"] = authored_panel()
        self.write_fixture()

    def test_full_factory_gets_matching_ui_and_preserves_original_commands(self):
        self.fill_factory()
        files, report = compile_project(GameSource(self.game), self.project)
        self.assertEqual(report["units"][0]["production_slot"], 15)
        original = self.fixture["Data/INI/CommandSet.ini"]
        self.assertEqual(files["Data\\INI\\CommandSet.ini"].replace(b"  15 = Command_ConstructUWLongma\n", b""), original)
        self.assertIn(b"ButtonCommand15", files["Window\\ControlBar.wnd"])
        output = self.root / "Extended.big"
        output.write_bytes(write_big(files))
        self.assertEqual(validate_archive(output)["status"], "structurally_valid")
        del files["Window\\ControlBar.wnd"]
        output.unlink()
        output.write_bytes(write_big(files))
        with self.assertRaisesRegex(BuildError, "lacks its control bar"):
            validate_archive(output)
        self.assert_original_unchanged()

    def test_extended_factory_rejects_occupied_slot_and_unknown_layout(self):
        self.fill_factory()
        self.fixture["Data/INI/CommandSet.ini"] = self.fixture["Data/INI/CommandSet.ini"].replace(b"End\n", b"  15 = Command_KeepExisting\nEnd\n")
        self.write_fixture()
        with self.assertRaisesRegex(IniError, "No free production slot"):
            compile_project(GameSource(self.game), self.project)
        self.assert_original_unchanged()
        self.fill_factory()
        self.fixture["Window/ControlBar.wnd"] = self.fixture["Window/ControlBar.wnd"].replace(b"189 492", b"190 492")
        self.write_fixture()
        with self.assertRaisesRegex(IniError, "geometry"):
            compile_project(GameSource(self.game), self.project)
        self.assert_original_unchanged()

    def test_extended_factory_rejects_loose_ui_that_would_mask_mod(self):
        self.fill_factory()
        loose = self.game / "Window/ControlBar.wnd"
        loose.parent.mkdir()
        loose.write_bytes(b"Existing local UI, preserve me")
        with self.assertRaisesRegex(BuildError, "Loose"):
            compile_project(GameSource(self.game), self.project)
        self.assertEqual(loose.read_bytes(), b"Existing local UI, preserve me")
        self.assert_original_unchanged()

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.game = self.root / "SyntheticGame"
        self.game.mkdir()
        self.archive_path = self.game / "INIZH.big"
        self.fixture = invented_game_files()
        self.write_fixture()
        self.project = self.root / "AuthoredProject"
        shutil.copytree(PROJECT / "content", self.project / "content")
        generated = self.project / "assets/generated"
        generated.mkdir(parents=True)
        spec = json.loads((self.project / "content/units/longma.json").read_text())
        for asset in spec["asset_files"]:
            shutil.copyfile(PROJECT / "assets/generated" / asset, generated / asset)

    def write_fixture(self):
        self.archive_path.write_bytes(write_big(self.fixture))
        self.original_bytes = self.archive_path.read_bytes()
        self.original_hash = hashlib.sha256(self.original_bytes).hexdigest()

    def assert_original_unchanged(self):
        self.assertEqual(self.archive_path.read_bytes(), self.original_bytes)
        self.assertEqual(hashlib.sha256(self.archive_path.read_bytes()).hexdigest(), self.original_hash)

    def run_cli(self, *arguments):
        stdout, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            status = main(list(arguments))
        return status, stdout.getvalue(), stderr.getvalue()

    def test_complete_synthetic_build_validate_and_preserve_source(self):
        output = self.root / "Build/FixtureMod.big"
        status, stdout, stderr = self.run_cli("build", "--game-dir", str(self.game), "--output", str(output))
        self.assertEqual(status, 0, stderr)
        report = json.loads(stdout)
        self.assertFalse(report["in_game_tested"])
        self.assertFalse(report["game_version_verified"])
        self.assertEqual(report["units"][0]["production_slot"], 2)
        self.assertEqual(json.loads(output.with_suffix(".manifest.json").read_text())["archive_sha256"],
                         hashlib.sha256(output.read_bytes()).hexdigest())
        self.assertEqual(validate_archive(output)["status"], "structurally_valid")
        packaged = read_big(output)
        for name in MONOLITHIC:
            original = self.fixture[f"Data/INI/{name}.ini"]
            actual = packaged.read(f"Data/INI/{name}.ini")
            if name == "CommandSet":
                insertion = b"  2 = Command_ConstructUWLongma\n"
                self.assertEqual(actual.replace(insertion, b"", 1), original)
            else:
                self.assertTrue(actual.startswith(original), name)
            source_report = report["sources"][f"Data\\INI\\{name}.ini"]
            self.assertEqual(source_report["sha256"], hashlib.sha256(original).hexdigest())
        # Localized source is complete, with only authored additions appended.
        self.assertTrue(packaged.read("Data/Generals.str").startswith(self.fixture["Data/Generals.str"]))
        self.assert_original_unchanged()

    def test_derived_unit_graph_health_damage_armor_and_locomotor(self):
        files, report = compile_project(GameSource(self.game), self.project)
        unit = report["units"][0]
        body = parse_ini(files["Data\\INI\\Object\\ChinaTankUWLongma.ini"]).blocks[0]
        self.assertEqual(body.name, "ChinaTankUWLongma")
        self.assertEqual(body.find_fields("BuildCost")[0].value, "2200")
        self.assertEqual(body.find_fields("BuildTime")[0].value, "24")
        active = next(child for child in body.children if child.kind.lower() == "body")
        self.assertEqual(active.find_fields("MaxHealth")[0].value, "950")
        self.assertEqual(active.find_fields("InitialHealth")[0].value, "950")
        self.assertEqual([c.find_fields("Weapon")[0].value.split()[1] for c in body.children
                          if c.kind.lower() == "weaponset"], list(unit["weapons"].values()))
        weapons = parse_ini(files["Data\\INI\\Weapon.ini"])
        for original, expected_damage in (("FixtureGun", 64), ("FixtureEliteGun", 128)):
            clone = weapons.find_block("Weapon", unit["weapons"][original])
            self.assertEqual(float(clone.find_fields("PrimaryDamage")[0].value), expected_damage)
            self.assertEqual(clone.find_fields("FireFX")[0].value, "FX_UWLongmaMuzzle")
        armor = parse_ini(files["Data\\INI\\Armor.ini"]).find_block("Armor", unit["armor"]["FixtureArmor"])
        self.assertEqual([f.value for f in armor.find_fields("Armor")], ["DEFAULT 85%", "SMALL_ARMS 42.5%"])
        locomotor = parse_ini(files["Data\\INI\\Locomotor.ini"]).find_block("Locomotor", unit["locomotors"]["FixtureLocomotor"])
        self.assertEqual(locomotor.find_fields("Speed")[0].value, "27")
        self.assertEqual(locomotor.find_fields("SpeedDamaged")[0].value, "18")
        self.assertEqual(body.find_fields("Locomotor")[0].value.split()[1], locomotor.name)
        draw = next(c for c in body.children if c.kind.lower() == "draw")
        self.assertEqual(draw.children[0].find_fields("Model")[0].value, "UWLONGMA")
        state = draw.children[0]
        pitch_bones = {field.value.lower() for field in state.find_fields("TurretPitch")}
        recoil_bones = {field.value.split()[-1].lower() for field in state.find_fields("WeaponRecoilBone")}
        # Native SAGE overwrites bone control matrices when recoil is applied
        # after pitch; these drivers must never target the same pivot.
        self.assertTrue(pitch_bones.isdisjoint(recoil_bones))
        self.assertEqual(pitch_bones, {"barrel"})
        self.assertNotIn("GeometryOffset", [f.key for f in body.fields])
        self.assert_original_unchanged()

    def test_output_inside_installation_rejected_without_changes(self):
        output = self.game / "OriginalFilesMustStayUntouched.big"
        status, _, stderr = self.run_cli("build", "--game-dir", str(self.game), "--output", str(output))
        self.assertEqual(status, 1)
        self.assertIn("inside the game installation", stderr)
        self.assertFalse(output.exists())
        self.assert_original_unchanged()

    def test_existing_output_is_preserved(self):
        output = self.root / "existing.big"
        output.write_bytes(b"An existing user file")
        status, _, stderr = self.run_cli("build", "--game-dir", str(self.game), "--output", str(output))
        self.assertEqual(status, 1)
        self.assertIn("already exists", stderr)
        self.assertEqual(output.read_bytes(), b"An existing user file")
        self.assert_original_unchanged()

    def test_loose_overlay_or_object_masks_rejected_without_writes(self):
        for relative in ("Data/INI/Weapon.ini", "Data/INI/Object/LooseFixture.ini", "Data/Generals.str"):
            with self.subTest(path=relative):
                path = self.game / relative
                path.parent.mkdir(parents=True, exist_ok=True)
                sentinel = b"Local user file must remain untouched"
                path.write_bytes(sentinel)
                try:
                    with self.assertRaisesRegex(BuildError, "Loose game files"):
                        compile_project(GameSource(self.game), self.project)
                    self.assertEqual(path.read_bytes(), sentinel)
                    self.assert_original_unchanged()
                finally:
                    path.unlink()

    def test_missing_weapon_reference_rejected(self):
        key = "Data/INI/Object/FixtureSource.ini"
        self.fixture[key] = self.fixture[key].replace(b"PRIMARY FixtureGun", b"PRIMARY MissingFixtureWeapon")
        self.write_fixture()
        with self.assertRaisesRegex(IniError, "MissingFixtureWeapon"):
            compile_project(GameSource(self.game), self.project)
        self.assert_original_unchanged()

    def test_new_object_id_virtual_path_and_mapped_image_collisions(self):
        collisions = [
            ("Data/INI/Object/ExistingOther.ini", b"Object ChinaTankUWLongma\n  BuildCost = 1\nEnd\n", "New object already exists"),
            ("Data/INI/Object/ChinaTankUWLongma.ini", b"Object FixtureUnrelated\n  BuildCost = 1\nEnd\n", "virtual path"),
            ("Data/INI/MappedImages/HandCreated/UltimateWarfare.ini", b"MappedImage FixtureImage\n  Texture = fixture.tga\nEnd\n", "mapped-image file"),
            ("Data/INI/MappedImages/HandCreated/Existing.ini", b"MappedImage UWLongmaCameo\n  Texture = fixture.tga\nEnd\n", "mapped-image name"),
        ]
        for path, data, expected in collisions:
            with self.subTest(path=path):
                self.fixture = invented_game_files()
                self.fixture[path] = data
                self.write_fixture()
                with self.assertRaisesRegex(BuildError, expected):
                    compile_project(GameSource(self.game), self.project)
                self.assert_original_unchanged()

    def test_duplicate_unit_catalog_entry_rejected(self):
        path = self.project / "content/catalog.json"
        catalog = json.loads(path.read_text())
        catalog["units"] *= 2
        path.write_text(json.dumps(catalog))
        with self.assertRaisesRegex(BuildError, "Duplicate unit catalog id"):
            compile_project(GameSource(self.game), self.project)
        self.assert_original_unchanged()

    def test_unrelated_object_with_spectre_decals_does_not_block_compilation(self):
        self.fixture["Data/INI/Object/FixtureSpectre.ini"] = b"""Object FixtureSpectre
  Behavior = SpectreGunshipUpdate ModuleTag_Visual
    AttackAreaDecal
      Texture = FixtureTexture
      Style = SHADOW_ALPHA_DECAL
      Color = R:10 G:20 B:30
    End
    TargetingReticleDecal
      Texture = FixtureReticle
      OpacityMax = 50%
    End
    AttackAreaRadius = 70
  End
End
"""
        self.write_fixture()
        files, report = compile_project(GameSource(self.game), self.project)
        self.assertEqual(report["units"][0]["id"], "ChinaTankUWLongma")
        self.assertNotIn("Data\\INI\\Object\\FixtureSpectre.ini", files)
        self.assert_original_unchanged()

    def test_percentage_behavior_field_survives_clone_without_rewriting_source(self):
        name = "Data/INI/Object/FixtureSource.ini"
        insertion = b"  Behavior = TransportContain FixtureContain\n    HealthRegen%PerSec  = 25\n  End\n"
        self.fixture[name] = self.fixture[name].replace(b"  BuildCost = 800\n", insertion + b"  BuildCost = 800\n")
        self.write_fixture()
        files, report = compile_project(GameSource(self.game), self.project)
        clone = files["Data\\INI\\Object\\ChinaTankUWLongma.ini"]
        self.assertIn(insertion, clone)
        self.assertEqual(report["units"][0]["id"], "ChinaTankUWLongma")
        self.assert_original_unchanged()

    def test_annotated_behavior_end_survives_clone_and_source_bytes_are_unchanged(self):
        name = "Data/INI/Object/FixtureSource.ini"
        insertion = (b"  Behavior = ObjectCreationUpgrade FixtureUpgrade\n"
                     b"    TriggeredBy = Upgrade_Fixture\n"
                     b"  End Upgrade_Fixture\n")
        self.fixture[name] = self.fixture[name].replace(b"  BuildCost = 800\n", insertion + b"  BuildCost = 800\n")
        self.write_fixture()
        files, report = compile_project(GameSource(self.game), self.project)
        self.assertIn(insertion, files["Data\\INI\\Object\\ChinaTankUWLongma.ini"])
        self.assertEqual(report["units"][0]["id"], "ChinaTankUWLongma")
        self.assert_original_unchanged()

    def test_source_vfs_native_within_archive_last_and_cross_archive_first(self):
        name = b"Data\\INI\\FixtureStandalone.ini"
        payloads = (b"inside-archive-first", b"inside-archive-last")
        index_size = 16 + 2 * (8 + len(name) + 1)
        total_size = index_size + sum(map(len, payloads))
        directory = bytearray(struct.pack(">4sIII", b"BIGF", total_size, 2, index_size))
        offset = index_size
        for payload in payloads:
            directory.extend(struct.pack(">II", offset, len(payload)) + name + b"\0")
            offset += len(payload)
        (self.game / "Alpha.big").write_bytes(bytes(directory) + b"".join(payloads))
        (self.game / "Zeta.big").write_bytes(write_big({name.decode(): b"later-archive"}))
        # Native EA ZH does not load BIG4, even though the offline reader can.
        (self.game / "Aardvark.big").write_bytes(write_big({name.decode(): b"unsupported-BIG4"}, magic=b"BIG4"))
        source = GameSource(self.game)
        self.assertEqual(source.read(name.decode()), b"inside-archive-last")
        self.assertEqual(source.source(name.decode()), "Alpha.big")
        self.assertEqual(source.skipped, [str(self.game / "Aardvark.big")])
        self.assert_original_unchanged()

    def test_prelaunch_structural_check_rejects_new_loose_mask(self):
        output = self.root / "FixtureMod.big"
        status, _, stderr = self.run_cli("build", "--game-dir", str(self.game), "--output", str(output))
        self.assertEqual(status, 0, stderr)
        # An invented executable marker is never run: this command is preflight.
        (self.game / "generals.exe").write_bytes(b"Not an executable; test marker only")
        status, stdout, stderr = self.run_cli("check-launch", "--game-dir", str(self.game), "--archive", str(output))
        self.assertEqual(status, 0, stderr)
        self.assertFalse(json.loads(stdout)["in_game_tested"])
        loose = self.game / "Data/INI/CommandSet.ini"
        loose.parent.mkdir(parents=True)
        loose.write_bytes(b"Loose user menu sentinel")
        status, _, stderr = self.run_cli("check-launch", "--game-dir", str(self.game), "--archive", str(output))
        self.assertEqual(status, 1)
        self.assertIn("mask mod entries", stderr)
        self.assertEqual(loose.read_bytes(), b"Loose user menu sentinel")
        self.assert_original_unchanged()


if __name__ == "__main__":
    unittest.main()
