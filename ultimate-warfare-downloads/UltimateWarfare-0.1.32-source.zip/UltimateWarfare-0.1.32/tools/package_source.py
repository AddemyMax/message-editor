#!/usr/bin/env python3
"""Package only original source/artwork; never package privately built BIGs."""
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
VERSION = "0.1.32"
EXCLUDED = {"dist", "private", ".cache", ".git", "__pycache__"}
ALLOWED_SUFFIXES = {".py", ".json", ".ini", ".md", ".ps1", ".tga", ".w3d", ".obj", ".mtl", ".blend", ".png"}
ROOT_NAMES = {"LICENSE", ".gitignore"}


def package(output: Path) -> tuple[int, str]:
    output = output.resolve()
    if output.exists():
        raise ValueError("Source ZIP already exists; choose a new output path")
    files = []
    for path in PROJECT.rglob("*"):
        relative = path.relative_to(PROJECT)
        if any(part in EXCLUDED for part in relative.parts) or not path.is_file():
            continue
        if path.is_symlink():
            raise ValueError("Do not package symlinks: " + str(relative))
        if path.suffix.lower() in ALLOWED_SUFFIXES or str(relative) in ROOT_NAMES:
            files.append((relative.as_posix(), path))
    output.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            created = True
            for relative, path in sorted(files):
                info = zipfile.ZipInfo(f"UltimateWarfare-{VERSION}/" + relative, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, path.read_bytes())
    except BaseException:
        if created:
            output.unlink(missing_ok=True)
        raise
    with zipfile.ZipFile(output) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise ValueError("ZIP CRC check failed: " + bad)
        if any(name.lower().endswith((".big", ".exe", ".dat", ".csf")) for name in archive.namelist()):
            raise ValueError("Private game content must not enter source kit")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    return len(files), digest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PROJECT / "dist" / f"UltimateWarfare-{VERSION}-source.zip")
    args = parser.parse_args()
    count, digest = package(args.output)
    print(f"Source kit: {args.output}\nFiles: {count}\nSHA256: {digest}")
