#!/usr/bin/env python3
"""Original Longma model and classic W3D exporter. Python standard library only.

SPDX-License-Identifier: MIT
Binary layout checked against EA's released GeneralsMD WW3D2/w3d_file.h,
htree.cpp, hlod.cpp, meshmdlio.cpp, and WWLib/chunkio.cpp. This is an original
implementation of that documented layout, not copied engine/exporter code.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import random
import struct


NAME = "UWLONGMA"
TEXTURE = "uwlongma.tga"
UNIT_SCALE = 2.1
V3 = tuple[float, float, float]
BONES = [
    ("ROOTTRANSFORM", -1, (0.0, 0.0, 0.0)),
    ("TURRET", 0, (-0.2, 0.0, 5.0)),
    ("BARREL", 1, (3.4, 0.0, 1.8)),
    ("MUZZLE01", 2, (12.55, -1.35, 0.0)),
    ("MUZZLE02", 2, (12.55, 0.0, 0.0)),
    ("MUZZLE03", 2, (12.55, 1.35, 0.0)),
]
BONES = [(name, parent, tuple(x * UNIT_SCALE for x in pos)) for name, parent, pos in BONES]
ORIGINS = [tuple(x * UNIT_SCALE for x in pos) for pos in [(0., 0., 0.), (-.2, 0., 5.), (3.2, 0., 6.8)]]


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def normal(a, b, c):
    n = cross(sub(b, a), sub(c, a))
    mag = math.sqrt(dot(n, n))
    if mag < 1.e-8:
        raise ValueError("Degenerate geometry")
    return tuple(x / mag for x in n)


class Mesh:
    def __init__(self, name, bone):
        self.name, self.bone = name, bone
        self.vertices, self.normals, self.uvs, self.triangles = [], [], [], []

    def face(self, points, tile=0, uv=None):
        """Weld within a polygon; split at normal/UV boundaries, as W3D needs."""
        n = normal(*points[:3])
        start = len(self.vertices)
        self.vertices.extend(points)
        self.normals.extend([n] * len(points))
        col, row = tile % 4, tile // 4
        # Texture is generated with a bottom-left origin. W3D stores MAX-style
        # bottom-left V; meshmdlio.cpp changes V to 1-V for Direct3D at load.
        coordinates = uv if uv is not None else [(0, 0), (1, 0), (1, 1), (0, 1)][:len(points)]
        for u, v in coordinates:
            u, v = .04 + .92 * u, .04 + .92 * v
            self.uvs.append(((col + u) / 4, (row + v) / 4))
        for i in range(1, len(points) - 1):
            self.triangles.append((start, start + i, start + i + 1))

    def box(self, center, size, tile=0, yaw=0., roll=0.):
        x, y, z = (v / 2 for v in size)
        pts = [(-x, -y, -z), (x, -y, -z), (x, y, -z), (-x, y, -z),
               (-x, -y, z), (x, -y, z), (x, y, z), (-x, y, z)]
        converted = []
        for px, py, pz in pts:
            rx = px * math.cos(roll) + pz * math.sin(roll)
            rz = -px * math.sin(roll) + pz * math.cos(roll)
            converted.append(add(center, (rx * math.cos(yaw) - py * math.sin(yaw),
                                          rx * math.sin(yaw) + py * math.cos(yaw), rz)))
        for ids in [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                    (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)]:
            face_tile = 12 if tile == 0 and ids == (4, 5, 6, 7) else tile
            self.face([converted[i] for i in ids], face_tile)

    def prism(self, bottom, top, z0, z1, tile=0):
        """Two CCW convex rings, beveled slopes if rings differ."""
        a = [(x, y, z0) for x, y in bottom]
        b = [(x, y, z1) for x, y in top]
        n = len(a)
        center_a = tuple(sum(p[j] for p in a) / n for j in range(3))
        center_b = tuple(sum(p[j] for p in b) / n for j in range(3))
        xmin, xmax = min(x for x, _ in bottom + top), max(x for x, _ in bottom + top)
        ymin, ymax = min(y for _, y in bottom + top), max(y for _, y in bottom + top)
        def cap_uv(points):
            return [((p[0]-xmin)/(xmax-xmin), (p[1]-ymin)/(ymax-ymin)) for p in points]
        for i in range(n):
            j = (i + 1) % n
            self.face([a[i], a[j], b[j], b[i]], tile)
            low, high = [center_a, a[j], a[i]], [center_b, b[i], b[j]]
            self.face(low, tile, cap_uv(low))
            self.face(high, 12 if tile == 0 else tile, cap_uv(high))

    def cylinder(self, center, radius, length, axis="z", segments=12, tile=4):
        def point(theta, end):
            c, s = radius * math.cos(theta), radius * math.sin(theta)
            off = {"x": (end, c, s), "y": (c, end, s), "z": (c, s, end)}[axis]
            return add(center, off)
        # Axis Y mapping has a negative determinant; reverse to retain CCW.
        angles = [i * math.tau / segments * (-1 if axis == "y" else 1)
                  for i in range(segments)]
        ring0 = [point(a, -length / 2) for a in angles]
        ring1 = [point(a, length / 2) for a in angles]
        center0, center1 = point(0., -length / 2), point(0., length / 2)
        # Use actual axis centers, not circumference points.
        offset = {"x": (length / 2, 0., 0.), "y": (0., length / 2, 0.),
                  "z": (0., 0., length / 2)}[axis]
        center0, center1 = sub(center, offset), add(center, offset)
        for i in range(segments):
            j = (i + 1) % segments
            self.face([ring0[i], ring0[j], ring1[j], ring1[i]], tile,
                      [(i/segments,0),((i+1)/segments,0),((i+1)/segments,1),(i/segments,1)])
            ci, si = math.cos(2*math.pi*i/segments), math.sin(2*math.pi*i/segments)
            cj, sj = math.cos(2*math.pi*j/segments), math.sin(2*math.pi*j/segments)
            self.face([center0, ring0[j], ring0[i]], tile, [(.5,.5),(.5+.5*cj,.5+.5*sj),(.5+.5*ci,.5+.5*si)])
            self.face([center1, ring1[i], ring1[j]], tile, [(.5,.5),(.5+.5*ci,.5+.5*si),(.5+.5*cj,.5+.5*sj)])


def tank():
    """Original Generals-style silhouette: broad chassis, slab turret, heavy guns.

    These primitives evoke the game's exaggerated Chinese heavy armor without
    copying its proprietary meshes or textures into the distributed source kit.
    """
    hull, turret, barrel = Mesh("HULL", 0), Mesh("TURRET", 1), Mesh("GUN", 2)
    housecolor = Mesh("HOUSECOLOR", 0)
    turret_color = Mesh("HOUSECOLOR_T", 1)
    hull.prism([(-11,-4.4),(7.8,-4.4),(10.6,-3.2),(10.6,3.2),(7.8,4.4),(-11,4.4)],
               [(-10.3,-4.0),(7.2,-4.0),(9.2,-3.0),(9.2,3.0),(7.2,4.0),(-10.3,4.0)], 1.3,4.8,0)
    # Clearly separated armor planes, rather than a forest of tiny modern ERA blocks.
    hull.box((6.6,0,4.86),(5.5,7.5,.55),1,roll=-.18)
    hull.box((-7.1,0,4.92),(5.7,7.3,.36),2)
    for i in range(9):
        hull.box((-9.35+i*.5,0,5.15),(.19,5.5,.13),6)
    for sign in (-1,1):
        y=sign*5.2
        # Broad dark tracks and large roadwheels retain the game's readable scale.
        for i in range(6):
            x=-8.5+i*3.35
            hull.cylinder((x,y,1.8),1.48,2.0,"y",10,4)
            hull.cylinder((x,y+sign*1.02,1.8),.7,.12,"y",10,5)
            hull.cylinder((x,y+sign*1.1,1.8),.25,.13,"y",8,7)
        path=[]
        for i in range(20):
            path.extend([(-8.5+16.75*i/19,3.37,0),(8.25-16.75*i/19,.23,0)])
        for end,offset in ((1,8.25),(-1,-8.5)):
            for i in range(8):
                angle=math.pi/2-math.pi*(i+.5)/8
                path.append((offset+end*1.57*math.cos(angle),1.8+1.57*math.sin(angle),end*(math.pi/2-angle)))
        for x,z,angle in path:
            hull.box((x,y,z),(.7,2.35,.25),4,roll=angle)
            hull.box((x,y,z+(.14 if z>1.8 else -.14)),(.13,2.2,.12),5,roll=angle)
        # Four large trapezoid side panels; upper fender forms one clear silhouette.
        hull.box((-.4,y,4.1),(21.7,2.7,.55),2)
        for i in range(4):
            x=-8.1+i*5.1
            hull.box((x,sign*6.48,3.7),(4.85,.35,1.95),0)
            hull.box((x,sign*6.69,4.59),(4.7,.12,.14),3)
        hull.box((8.8,sign*3.0,5.16),(.58,.72,.32),8)
        hull.cylinder((-10.7,sign*3.2,3.8),.44,1.6,"z",8,5)
        housecolor.box((-.2,sign*6.71,3.75),(3.3,.055,.62),10)
    # Heavy faceted turret: more vertical armor and chamfered corners, in the
    # same broad design language as Overlord, with an original three-gun front.
    turret.cylinder((-.2,0,4.86),3.95,.62,"z",16,5)
    bottom=[(-6.4,-3.9),(2.8,-3.9),(4.7,-2.6),(4.7,2.6),(2.8,3.9),(-6.4,3.9),(-7,2.8),(-7,-2.8)]
    top=[(-5.8,-3.3),(2.4,-3.3),(4,-2.2),(4,2.2),(2.4,3.3),(-5.8,3.3),(-6.3,2.5),(-6.3,-2.5)]
    turret.prism(bottom,top,5.2,8.05,0)
    for sign in (-1,1):
        turret.box((-.3,sign*3.7,6.55),(6.4,.55,1.8),1,yaw=-sign*.06)
        turret.box((-.3,sign*4.01,7.36),(6.1,.12,.16),3)
        turret_color.box((-.3,sign*4.06,6.55),(3.9,.055,.42),10,yaw=-sign*.06)
        turret.box((-5.2,sign*3.68,6.8),(2.4,.4,1.7),2)
        for i in range(3):
            turret.cylinder((-4.7+i*.65,sign*4.1,7.65),.22,.75,"z",8,5)
    turret.box((-5.8,0,7.4),(2.2,6.6,1.2),2)
    turret.cylinder((-2.4,1.5,8.16),1.0,.25,"z",12,2)
    turret.box((.3,-1.3,8.3),(1.6,1.05,.55),2)
    turret.box((1.12,-1.3,8.35),(.08,.8,.28),8)
    turret.cylinder((-4.9,-2.0,9.15),.055,2.2,"z",6,5)
    # Three separated, thick cannons; keep the centre gun slightly longer in
    # its shroud, while all muzzle bones share one pitch cradle at z=6.8.
    barrel.box((4.1,0,6.8),(1.8,5.4,1.95),2)
    for y in (-1.35,0,1.35):
        barrel.cylinder((9.6,y,6.8),.42,11.6,"x",10,5)
        barrel.cylinder((6.3,y,6.8),.57,4.1,"x",10,0)
        barrel.cylinder((10.0,y,6.8),.5,1.0,"x",10,2)
        barrel.cylinder((15.05,y,6.8),.6,1.1,"x",8,5)
        barrel.cylinder((15.615,y,6.8),.36,.035,"x",8,6)
        barrel.cylinder((13.9,y,6.8),.48,.18,"x",10,7)
    for mesh in (hull,turret,barrel,housecolor,turret_color):
        mesh.vertices=[tuple(value*UNIT_SCALE for value in point) for point in mesh.vertices]
    return [hull,turret,barrel,housecolor,turret_color]


def fixed_name(name, length=16):
    raw = name.encode("ascii")
    if len(raw) >= length:
        raise ValueError(f"W3D name too long: {name}")
    return raw + b"\0" * (length - len(raw))


def chunk(cid, payload, container=False):
    if len(payload) >= 0x80000000:
        raise ValueError("W3D chunk too large")
    return struct.pack("<II", cid, len(payload) | (0x80000000 if container else 0)) + payload


def container(cid, children):
    return chunk(cid, b"".join(children), True)


def mesh_chunk(mesh):
    origin = ORIGINS[mesh.bone]
    verts = [sub(p, origin) for p in mesh.vertices]
    lo = tuple(min(p[i] for p in verts) for i in range(3))
    hi = tuple(max(p[i] for p in verts) for i in range(3))
    center = tuple((a + b) / 2 for a, b in zip(lo, hi))
    radius = max(math.sqrt(dot(sub(p, center), sub(p, center))) for p in verts)
    header = (struct.pack("<II", 0x40002, 0x8000)
              + fixed_name(mesh.name) + fixed_name(NAME)
              + struct.pack("<4Ii4I", len(mesh.triangles), len(verts), 1, 0, 0, 0, 0, 7, 1)
              + struct.pack("<10f", *lo, *hi, *center, radius))
    assert len(header) == 116
    vmat = (struct.pack("<I", 0) + bytes([255, 255, 255, 0] * 2)
            + bytes([36, 36, 36, 0, 0, 0, 0, 0]) + struct.pack("<3f", 14., 1., 0.))
    shader = bytes([3, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0])
    triangles = []
    for a, b, c in mesh.triangles:
        n = normal(verts[a], verts[b], verts[c])
        triangles.append(struct.pack("<4I4f", a, b, c, 1, *n, dot(n, verts[a])))
    return container(0, [
        chunk(0x1F, header),
        chunk(2, b"".join(struct.pack("<3f", *p) for p in verts)),
        chunk(3, b"".join(struct.pack("<3f", *p) for p in mesh.normals)),
        chunk(0x20, b"".join(triangles)),
        chunk(0x28, struct.pack("<4I", 1, 1, 1, 1)),
        chunk(0x29, shader),
        container(0x2A, [container(0x2B, [chunk(0x2C, b"LONGMA_PAINT\0"),
                                        chunk(0x2D, vmat)])]),
        container(0x30, [container(0x31, [chunk(0x32, TEXTURE.encode() + b"\0"),
                                        chunk(0x33, struct.pack("<HHIf", 0, 0, 1, 0.))])]),
        container(0x38, [chunk(0x39, struct.pack("<I", 0)), chunk(0x3A, struct.pack("<I", 0)),
                         container(0x48, [chunk(0x49, struct.pack("<I", 0)),
                                          chunk(0x4A, b"".join(struct.pack("<2f", *uv)
                                                              for uv in mesh.uvs))])]),
    ])


def w3d(meshes):
    hierarchy = container(0x100, [
        chunk(0x101, struct.pack("<I16sI3f", 0x40001, fixed_name(NAME), len(BONES), 0., 0., 0.)),
        chunk(0x102, b"".join(struct.pack("<16sI10f", fixed_name(name), parent & 0xFFFFFFFF,
                                          *pos, 0., 0., 0., 0., 0., 0., 1.)
                              for name, parent, pos in BONES)),
    ])
    hlod = container(0x700, [
        chunk(0x701, struct.pack("<II16s16s", 0x10000, 1, fixed_name(NAME), fixed_name(NAME))),
        container(0x702, [chunk(0x703, struct.pack("<If", len(meshes), 3.4028234663852886e38))]
                  + [chunk(0x704, struct.pack("<I32s", m.bone, fixed_name(NAME + "." + m.name, 32)))
                     for m in meshes]),
    ])
    # Asset manager processes definitions in file order: hierarchy, meshes, HLOD.
    return hierarchy + b"".join(mesh_chunk(m) for m in meshes) + hlod


def texture_tga():
    """Authored classic-RTS diffuse atlas with painted seams and baked wear.

    No camouflage blobs or external game artwork. Contrast is in the diffuse
    texture so panel edges remain readable under SAGE's simple lighting.
    """
    size = 512
    rng = random.Random(50430)
    colors = [(143,151,121),(171,178,146),(70,80,65),(182,188,157),
              (29,34,31),(83,94,87),(17,23,20),(121,130,112),
              (54,132,147),(142,34,27),(200,200,200),(133,144,112),
              (154,165,134),(121,135,109),(97,110,89),(170,176,147)]
    paint = {0,1,2,3,11,12,13,14,15}
    pixels = bytearray()
    for y in range(size):
        for x in range(size):
            tile = (y//128)*4+x//128
            px, py = x%128, y%128
            base = colors[tile]
            shade = rng.randint(-3,3)
            if tile in paint:
                # Broad light/dark planes, greasy lower edge and worn upper
                # bevels emulate painted 2003-era unit textures, not PBR.
                shade += int((py-64)*.08 - 5*abs(math.sin(px*.07+py*.025)))
                edge = min(px-5,py-5,122-px,122-py)
                if edge < 2:
                    shade -= 75
                elif edge < 4:
                    shade += 42 if py>64 or px<64 else -32
                elif edge < 7:
                    shade -= 12
                # Painted inset panels have a dark groove and a lit lip.
                if tile in (0,11,13) and 19<=px<=108 and 24<=py<=103:
                    inset=min(px-19,108-px,py-24,103-py)
                    if inset<2: shade-=45
                    elif inset<4: shade+=22 if py>64 else -12
                if tile==12:
                    for seam in (43,85):
                        if abs(px-seam)<1.2 and 9<py<119: shade-=52
                        elif abs(px-seam-2)<1 and 9<py<119: shade+=26
                    if abs(py-64)<1.2 and 9<px<119: shade-=48
                    # A printed vent and access hatch occupy distinct roof
                    # UV regions, instead of repeating once per triangle.
                    if 12<=px<=37 and 18<=py<=48:
                        shade-=28
                        if py%6<3: shade-=55
                        elif py%6==3: shade+=22
                    if 92<=px<=114 and 81<=py<=110:
                        hatch=min(px-92,114-px,py-81,110-py)
                        if hatch<2: shade-=55
                        elif hatch<4: shade+=25
                for bx,by in ((14,14),(113,14),(14,113),(113,113)):
                    distance=(px-bx)**2+(py-by)**2
                    if distance<10: shade-=45
                    if distance<3: shade+=68
                # Small deterministic scratches; never large camo islands.
                if 9<px<119 and 9<py<119 and rng.random()<.009:
                    shade+=28
            elif tile==4:
                shade+=int(7*math.sin(py*.23))
                if py%25<3: shade-=12
            elif tile in (5,7):
                shade+=int(17*math.cos((px-64)*math.pi/128))
                if py%32<2: shade-=23
                elif py%32==2: shade+=15
                if min(px,127-px)<7: shade-=18
            elif tile==6:
                if py%13<2: shade+=7
            elif tile==8:
                shade+=int((px+py)*.19)-18
                if 21<px+py<30: shade+=55
            elif tile==10:
                # Neutral modulated texture for the native HOUSECOLOR path.
                edge=min(px-5,py-5,122-px,122-py)
                shade-=45 if edge<3 else 0
                shade+=12 if 3<=edge<5 else 0
            rgb=[max(0,min(255,c+shade)) for c in base]
            pixels.extend(reversed(rgb))
    return struct.pack("<BBBHHBHHHHBB",0,0,2,0,0,0,0,0,size,size,24,0)+pixels


def muzzle_tga():
    """Original radial burst, RGB falloff for SAGE's ONE+ONE additive shader.

    The native additive particle preset ignores texture alpha in its blend
    factors, so RGB must fall to black at the edges as well as storing alpha.
    """
    size = 64
    pixels = bytearray()
    for y in range(size):
        for x in range(size):
            fx, fy = (x + .5 - size / 2) / (size / 2), (y + .5 - size / 2) / (size / 2)
            r = math.hypot(fx, fy)
            ang = math.atan2(fy, fx)
            core = max(0., 1. - r / .48) ** 1.5
            rays = max(0., math.cos(ang * 6)) ** 14 * max(0., 1. - r) ** 1.7
            alpha = min(1., core * 1.45 + rays * .9)
            red, green, blue = 255, int(158 + 97 * core), int(48 + 207 * core)
            pixels.extend((round(blue * alpha), round(green * alpha),
                           round(red * alpha), round(alpha * 255)))
    return struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, size, size, 32, 8) + pixels


def cameo_tga(meshes, texture):
    """Small genuine rendering of our geometry, using only a stdlib z-buffer."""
    size = 256
    direction = (32., -38., 24.)
    length = math.sqrt(dot(direction, direction))
    direction = tuple(x / length for x in direction)
    right = cross((0., 0., 1.), direction)
    length = math.sqrt(dot(right, right))
    right = tuple(x / length for x in right)
    up = cross(direction, right)
    illumination = (.35, -.52, .77)
    projected = [[(dot(v, right), dot(v, up), dot(v, direction)) for v in m.vertices]
                 for m in meshes]
    values = [p for item in projected for p in item]
    xmin, xmax = min(p[0] for p in values), max(p[0] for p in values)
    ymin, ymax = min(p[1] for p in values), max(p[1] for p in values)
    scale = (size - 30) / max(xmax - xmin, ymax - ymin)
    cx, cy = (xmax + xmin) / 2, (ymax + ymin) / 2
    image = [(24 + y // 20, 29 + y // 22, 22 + y // 32) for y in range(size) for _ in range(size)]
    depth = [-math.inf] * (size * size)
    for m, screen in zip(meshes, projected):
        positions = [((p[0] - cx) * scale + size / 2, (p[1] - cy) * scale + size / 2, p[2])
                     for p in screen]
        for indices in m.triangles:
            a, b, c = [positions[i] for i in indices]
            n = m.normals[indices[0]]
            if dot(n, direction) <= 0:
                continue
            area = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1])
            if abs(area) < 1.e-8:
                continue
            brightness = .48 + .62 * max(0., dot(n, illumination))
            uv = [m.uvs[i] for i in indices]
            for py in range(max(0, math.floor(min(a[1], b[1], c[1]))),
                            min(size, math.ceil(max(a[1], b[1], c[1])))):
                for px in range(max(0, math.floor(min(a[0], b[0], c[0]))),
                                min(size, math.ceil(max(a[0], b[0], c[0])))):
                    w0 = ((b[1] - c[1]) * (px + .5 - c[0]) + (c[0] - b[0]) * (py + .5 - c[1])) / area
                    w1 = ((c[1] - a[1]) * (px + .5 - c[0]) + (a[0] - c[0]) * (py + .5 - c[1])) / area
                    w2 = 1 - w0 - w1
                    if min(w0, w1, w2) < 0:
                        continue
                    z = w0 * a[2] + w1 * b[2] + w2 * c[2]
                    index = py * size + px
                    if z <= depth[index]:
                        continue
                    depth[index] = z
                    tx = min(511, int(sum(w * t[0] for w, t in zip((w0, w1, w2), uv)) * 512))
                    ty = min(511, int(sum(w * t[1] for w, t in zip((w0, w1, w2), uv)) * 512))
                    start = 18 + 3 * (ty * 512 + tx)
                    rgb = list(reversed(texture[start:start + 3]))
                    image[index] = tuple(min(255, int(ch * brightness)) for ch in rgb)
    pixels = bytearray()
    for y in range(128):
        for x in range(128):
            rgb = [sum(image[(y * 2 + dy) * size + x * 2 + dx][channel]
                       for dy in (0, 1) for dx in (0, 1)) // 4 for channel in range(3)]
            if x in (1, 126) or y in (1, 126):
                rgb = [143, 150, 102]
            pixels.extend(reversed(rgb))
    return struct.pack("<BBBHHBHHHHBB", 0, 0, 2, 0, 0, 0, 0, 0, 128, 128, 24, 0) + pixels


def write_obj(meshes, output):
    lines = ["# Original procedural Longma; asset license CC0-1.0", "mtllib uwlongma.mtl"]
    offset = 1
    for m in meshes:
        lines += ["o " + m.name, "usemtl LONGMA_PAINT"]
        lines += ["v %.6f %.6f %.6f" % p for p in m.vertices]
        lines += ["vt %.6f %.6f" % p for p in m.uvs]
        lines += ["vn %.6f %.6f %.6f" % p for p in m.normals]
        for face in m.triangles:
            lines.append("f " + " ".join(f"{i + offset}/{i + offset}/{i + offset}" for i in face))
        offset += len(m.vertices)
    (output / "uwlongma.obj").write_text("\n".join(lines) + "\n")
    (output / "uwlongma.mtl").write_text("newmtl LONGMA_PAINT\nKa 1 1 1\nKd 1 1 1\nKs .14 .14 .14\nNs 14\nd 1\nmap_Kd uwlongma.tga\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[2] / "assets/generated")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    meshes = tank()
    (args.output / "uwlongma.w3d").write_bytes(w3d(meshes))
    texture = texture_tga()
    (args.output / TEXTURE).write_bytes(texture)
    (args.output / "uwmflash.tga").write_bytes(muzzle_tga())
    (args.output / "uwlmcameo.tga").write_bytes(cameo_tga(meshes, texture))
    write_obj(meshes, args.output)
    all_vertices = [v for m in meshes for v in m.vertices]
    bounds = {"min": [min(v[i] for v in all_vertices) for i in range(3)],
              "max": [max(v[i] for v in all_vertices) for i in range(3)]}
    data = {"model": NAME, "asset_license": "CC0-1.0", "front": "+X", "up": "+Z",
            "triangles": sum(len(m.triangles) for m in meshes),
            "vertices": sum(len(m.vertices) for m in meshes), "rigid_meshes": len(meshes),
            "texture": TEXTURE,
            "bounds": bounds, "bones": [{"name": n, "parent": p, "translation": t}
                                           for n, p, t in BONES],
            "meshes": [{"name": m.name, "bone": m.bone, "origin": ORIGINS[m.bone],
                        "vertex_count": len(m.vertices), "triangle_count": len(m.triangles),
                        "vertices": m.vertices, "normals": m.normals,
                        "uvs": m.uvs, "triangles": m.triangles} for m in meshes]}
    (args.output / "uwlongma.mesh.json").write_text(json.dumps(data, separators=(",", ":")) + "\n")
    print(json.dumps({"model": NAME, "triangles": sum(len(m.triangles) for m in meshes),
                      "vertices": sum(len(m.vertices) for m in meshes), "bounds": bounds}))


if __name__ == "__main__":
    main()
