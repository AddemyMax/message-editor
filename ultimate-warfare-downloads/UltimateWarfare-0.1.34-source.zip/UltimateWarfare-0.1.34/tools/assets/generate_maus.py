#!/usr/bin/env python3
"""Authored Panzer VIII Maus interpretation; no third-party mesh or texture.

Code MIT; generated artwork CC0-1.0. +X forward, +Z up.
"""
import json
import math
from pathlib import Path
import struct
from generate_longma import Mesh,w3d,cameo_tga,chunk,container

OUTPUT=Path(__file__).resolve().parents[2]/'assets/generated'
BONES=[('ROOTTRANSFORM',-1,(0.,0.,0.)),('TURRET',0,(-1.,0.,4.25)),
       ('GUN_PITCH',1,(3.65,0.,1.95)),('GUN_RECOIL',2,(0.,0.,0.)),
       ('MUZZLE01',3,(8.57,-.55,0.))]
ORIGINS=[]
for _,parent,pos in BONES:
    ORIGINS.append(tuple(v+(ORIGINS[parent][i] if parent>=0 else 0) for i,v in enumerate(pos)))


def vehicle():
    hull=Mesh('HULL',0);turret=Mesh('TURRET_BODY',1);gun=Mesh('GUNS',3)
    color=Mesh('HOUSECOLOR',0)
    # Long, slab-sided hull and a steeply sloped glacis, not a modern MBT.
    hull.prism([(-7.5,-3.25),(7.5,-3.25),(7.5,3.25),(-7.5,3.25)],
               [(-7.15,-3.1),(5.25,-3.1),(5.25,3.1),(-7.15,3.1)],1.45,4.15,0)
    hull.box((-5.55,0,4.23),(2.7,5.9,.18),1)
    hull.cylinder((-1,0,4.25),3.1,.22,'z',24,5)
    for side in (-1,1):
        # Deep side skirts enclose the wheel suspension, with track ends open.
        hull.box((-.1,side*3.80,2.63),(12.9,.18,2.18),0)
        hull.box((-.1,side*3.87,3.85),(13.8,.20,.20),1)
        for x in (-6.1,-3.75,-1.4,.95,3.3,5.65):
            hull.box((x,side*3.93,2.73),(.045,.08,1.85),5)
            for z in (1.98,3.42):hull.cylinder((x+.22,side*3.97,z),.075,.09,'y',6,6)
        for x in (-5.7,-4.9,-4.1):
            hull.box((x,side*2.18,4.36),(.12,1.28,.12),5)
        hull.box((-5.2,side*1.5,4.37),(3.05,1.40,.13),8)
        for x in (-6.35,-5.95,-5.55,-5.15,-4.75,-4.35):
            hull.box((x,side*1.5,4.46),(.12,1.15,.12),5)
        # Tow shackles, fenders and lamps: small readable metallic details.
        for x in (-7.25,6.95):
            hull.cylinder((x,side*2.55,1.98),.24,.36,'y',10,6)
            hull.box((x,side*3.47,3.82),(.65,.65,.15),1)
        hull.cylinder((6.1,side*2.65,3.55),.22,.22,'x',12,5)
        hull.cylinder((6.23,side*2.65,3.55),.17,.05,'x',12,11)
        hull.cylinder((-7.2,side*2.35,3.25),.26,1.1,'z',12,5)
        hull.cylinder((-7.2,side*2.35,3.82),.29,.12,'z',12,7)
        color.box((1.25,side*3.98,3.47),(2.1,.045,.20),10)
        hull.box((1.25,side*3.99,2.68),(1.40,.05,.95),13)
    hull.box((4.35,0,4.12),(1.35,1.55,.16),1)
    hull.box((4.35,0,4.25),(.7,.10,.09),6)
    # Large high turret, curved mantlet, two coaxial guns and rear overhang.
    turret.prism([(-5.25,-2.95),(1.80,-2.95),(3.10,-1.95),(3.10,1.95),(1.80,2.95),(-5.25,2.95)],
                 [(-4.95,-2.65),(1.70,-2.65),(2.60,-1.80),(2.60,1.80),(1.70,2.65),(-4.95,2.65)],4.35,7.70,0)
    turret.cylinder((2.60,0,6.20),1.35,4.05,'y',24,1)
    turret.cylinder((-2.75,-.7,7.78),.91,.19,'z',20,1)
    turret.cylinder((-.15,.95,7.78),.75,.19,'z',20,1)
    for x,y in ((-2.75,-.7),(-.15,.95)):
        turret.box((x,y,7.92),(.65,.10,.09),6)
    for side in (-1,1):
        turret.box((-3.6,side*2.85,6.3),(.85,.12,.70),1)
        turret.cylinder((-.25,side*2.88,5.7),.22,.12,'y',12,5)
        turret.cylinder((-.25,side*2.97,5.7),.11,.08,'y',10,7)
        turret.box((-1.,side*2.91,4.72),(6.4,.06,.07),5)
        for x in (-4.4,-1.6,1.1):
            turret.cylinder((x,side*2.85,7.25),.07,.07,'y',6,6)
        # External service cable and brackets on the thick hull skirts.
        hull.box((-1.6,side*4.0,2.1),(5.8,.08,.08),5)
        for x in (-4.4,1.2):hull.cylinder((x,side*4.,2.1),.16,.10,'y',10,5)
        hull.box((3.8,side*3.95,2.7),(2.4,.08,.13),6)
        hull.box((4.8,side*3.99,2.7),(.35,.08,.48),5)
        for x in (-3.8,-1.4,.5):
            turret.box((x,side*2.87,7.05),(.65,.13,.10),6)
        # Spare track links along the turret's rear shoulders.
        for x in (-4.3,-3.8,-3.3):
            turret.box((x,side*2.83,5.15),(.35,.16,.55),4)
        turret.box((-4.91,side*1.65,7.08),(.12,.55,.40),5)
    for x,y in ((-3.4,-.7),(-2.1,-.7),(-2.75,-1.38),(-2.75,-.02)):
        turret.box((x,y,7.96),(.21,.17,.16),5)
    turret.box((1.6,-1.1,7.75),(.5,.8,.18),2)
    turret.box((1.6,-1.1,7.87),(.35,.4,.12),3)
    turret.cylinder((-4.45,1.6,8.1),.055,1.1,'z',8,5)
    gun.cylinder((3.7,-.55,6.2),.52,2.1,'x',20,1)
    gun.cylinder((7.6,-.55,6.2),.25,7.0,'x',16,2)
    gun.cylinder((10.95,-.55,6.2),.32,.40,'x',16,5)
    gun.cylinder((11.18,-.55,6.2),.23,.08,'x',16,7)
    gun.cylinder((5.2,1.0,6.2),.15,4.3,'x',12,2)
    gun.cylinder((7.38,1.0,6.2),.18,.12,'x',12,7)
    tracks=[]
    for side in (-1,1):
        tread=Mesh('TREADSL' if side<0 else 'TREADSR',0)
        # Open belt wraps around visible end wheels; middle road wheels sit
        # behind the historical deep skirts. Belt alone gets scrolling UVs.
        profile=[(-7.7,1.15),(-6.65,.18),(6.35,.18),(7.55,1.28),(7.55,2.75),(6.5,3.45),(-6.6,3.45),(-7.7,2.65)]
        for i,(x,z) in enumerate(profile):
            xx,zz=profile[(i+1)%len(profile)]
            u0=i/len(profile);u1=(i+1)/len(profile)
            points=[(x,side*3.0,z),(xx,side*3.0,zz),(xx,side*3.85,zz),(x,side*3.85,z)]
            uv=[(u0,0),(u1,0),(u1,1),(u0,1)]
            if side>0:
                points.reverse();uv=[(1-u,v) for u,v in reversed(uv)]
            tread.face(points,uv=uv)
        for x in (-6.6,6.45):
            hull.cylinder((x,side*3.4,1.78),1.30,.92,'y',18,4)
            hull.cylinder((x,side*3.9,1.78),.83,.12,'y',16,2)
            hull.cylinder((x,side*3.99,1.78),.28,.12,'y',12,6)
        tracks.append(tread)
    return [hull,turret,gun,*tracks,color]


def texture(tread=False):
    colors=[(117,124,93),(149,152,119),(68,75,61),(22,30,33),
            (39,43,40),(59,63,59),(117,120,103),(12,16,15),
            (49,57,45),(129,135,105),(185,190,167),(220,219,191),
            (128,135,102),(115,122,93),(132,125,85),(109,38,31)]
    pixels=bytearray()
    for y in range(512):
        for x in range(512):
            tile=(y//128)*4+x//128;u=x%128;v=y%128
            shade=((x*31+y*79)%13-6)*.5
            if tread:
                seam=x%32
                val=37+(13 if 5<seam<24 else -15)+(8 if y%64<6 else 0)
                rgb=(val,val+2,val)
            else:
                edge=min(u,v,127-u,127-v)
                if tile in (0,1,2,9,12,13,14):
                    shade+=(-30 if edge<7 else 19 if edge<10 else 0)+(v-64)*.20
                    # Baked weld lines, screw heads and chipped paint remain
                    # readable under SAGE's simple diffuse lighting.
                    if v in (18,19):shade-=20
                    if v==20:shade+=12
                    if (u<20 or u>107) and (v<20 or v>107):
                        dx=min(abs(u-15),abs(u-112));dy=min(abs(v-15),abs(v-112))
                        if dx*dx+dy*dy<12:shade+=30
                    if v<34 and (u*7+v*13)%31<9:shade-=12
                    if (u*19+v*7)%1459<4:shade+=20
                if tile==8:shade+=-23 if v%16<10 else 9
                rgb=tuple(max(0,min(255,int(c+shade))) for c in colors[tile])
                if tile==13:
                    # A subdued USA star identifies its new faction. No decals
                    # or emblems from historical extremist organizations.
                    star=[(64+(42 if i%2==0 else 18)*math.sin(i*math.pi/5),64+(42 if i%2==0 else 18)*math.cos(i*math.pi/5)) for i in range(10)]
                    inside=False
                    for i,(ax,ay) in enumerate(star):
                        bx,by=star[(i+1)%10]
                        if (ay>v)!=(by>v) and u<(bx-ax)*(v-ay)/(by-ay)+ax:inside=not inside
                    if inside:rgb=(195,199,174)
            pixels.extend(reversed(rgb))
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,512,512,24,0)+pixels


def main():
    from uwmod.kitbash import unpack,pack
    OUTPUT.mkdir(parents=True,exist_ok=True);meshes=vehicle();tex=texture()
    raw=w3d(meshes,model_name='UWMAUS',texture_name='uwmaus.tga',bones=BONES,origins=ORIGINS)
    data=unpack(raw)
    # Native W3DTankDraw discovers TREADSL/R and requires a linear-offset mapper.
    for cid,payload in data:
        if cid!=0:continue
        header=next(p for i,p in payload if i==0x1f)
        if not header[8:24].split(b'\0')[0].startswith(b'TREADS'):continue
        materials=next(p for i,p in payload if i==0x2a)
        mat=next(p for i,p in materials if i==0x2b)
        for j,(i,p) in enumerate(mat):
            if i==0x2d:mat[j]=(i,struct.pack('<I',0x40000)+p[4:])
        mat.append((0x2e,b'UPerSec=0\nVPerSec=0\0'))
        textures=next(p for i,p in payload if i==0x30)
        texture_block=next(p for i,p in textures if i==0x31)
        for j,(i,p) in enumerate(texture_block):
            if i==0x32:texture_block[j]=(i,b'uwmatread.tga\0')
    (OUTPUT/'uwmaus.w3d').write_bytes(pack(data))
    (OUTPUT/'uwmaus.tga').write_bytes(tex);(OUTPUT/'uwmatread.tga').write_bytes(texture(True))
    (OUTPUT/'uwmacameo.tga').write_bytes(cameo_tga(meshes,tex))
    verts=[v for m in meshes for v in m.vertices]
    report={'model':'UWMAUS','texture':'uwmaus.tga','asset_license':'CC0-1.0','front':'+X','up':'+Z',
        'triangles':sum(len(m.triangles) for m in meshes),'vertices':len(verts),'rigid_meshes':len(meshes),
        'bounds':{'min':[min(v[i] for v in verts) for i in range(3)],'max':[max(v[i] for v in verts) for i in range(3)]},
        'bones':[{'name':n,'parent':p,'translation':t} for n,p,t in BONES],
        'meshes':[{'name':m.name,'bone':m.bone,'origin':ORIGINS[m.bone],'vertices':m.vertices,'normals':m.normals,
            'uvs':m.uvs,'triangles':m.triangles,'texture':'uwmatread.tga' if m.name.startswith('TREADS') else 'uwmaus.tga'} for m in meshes]}
    (OUTPUT/'uwmaus.mesh.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
    lines=['# Authored Maus interpretation; CC0-1.0','mtllib uwmaus.mtl'];offset=1
    for m in meshes:
        lines+=['o '+m.name,'usemtl TREADS' if m.name.startswith('TREADS') else 'usemtl MAUS']
        lines+=['v %.6f %.6f %.6f'%p for p in m.vertices]
        lines+=['vt %.6f %.6f'%p for p in m.uvs]
        lines+=['vn %.6f %.6f %.6f'%p for p in m.normals]
        lines+=['f '+' '.join(f'{i+offset}/{i+offset}/{i+offset}' for i in f) for f in m.triangles];offset+=len(m.vertices)
    (OUTPUT/'uwmaus.obj').write_text('\n'.join(lines)+'\n')
    (OUTPUT/'uwmaus.mtl').write_text('newmtl MAUS\nKd 1 1 1\nmap_Kd uwmaus.tga\nnewmtl TREADS\nKd 1 1 1\nmap_Kd uwmatread.tga\n')
    print(json.dumps({k:report[k] for k in ('model','triangles','vertices','bounds')}))

if __name__=='__main__':
    import sys
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    main()
