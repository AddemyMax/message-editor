"""Read-only, privacy-preserving structural diagnosis of a local installation.

No game binary is executed or verified. Compilation happens in memory, and a
temporary BIG used for structural validation is removed before returning.
Reports contain neither original file contents nor installation paths.
"""

from __future__ import annotations

import errno
import json
from pathlib import Path
import tempfile

from .archive import BigError, write_big
from .ini import IniError
from .localization import LocalizationError


def _check(identifier: str, status: str, message: str) -> dict:
    return {"id": identifier, "status": status, "message": message}


def _failure_message(exc: Exception, stage: str) -> str:
    """Classify errors without copying possibly private source/path text."""
    if isinstance(exc, OSError):
        if exc.errno in (errno.EACCES, errno.EPERM):
            return "Permission denied while reading the selected inputs; make them readable and retry."
        if exc.errno == errno.ENOENT:
            return "A required input is missing; check the installation and authored project files."
        return "A filesystem operation failed; check input readability and available temporary storage."
    if isinstance(exc, BigError):
        return "A BIG archive was rejected as malformed or unsupported by this reader; check archive_error before changing any game files."
    if isinstance(exc, LocalizationError):
        return "Original localization cannot be preserved safely; use complete, compatible STR or CSF sources."
    if isinstance(exc, IniError):
        text = str(exc).lower()
        if "no free production slot" in text:
            return "The factory has no free production slot 1..12; all original commands were preserved."
        return "An INI definition is malformed, missing, duplicated, or unsupported; restore compatible original definitions."
    # Inspect error categories only. Never return exception messages, which may
    # contain absolute paths, localized original text or whole source fields.
    text = str(exc).lower()
    if "loose" in text:
        return "Loose local files mask the mod or its source; use a separate clean installation. No files were changed."
    if "no native bigf" in text:
        return "No native BIGF game archives were found; select the installed Zero Hour folder."
    if "symlink" in text:
        return "The selected game tree contains unsupported symlinks; use a separate ordinary installation directory."
    if "already exists" in text or "collid" in text or "duplicate" in text:
        return "A new unit, resource or definition conflicts with existing content; use compatible authored manifests and a clean installation."
    if "missing" in text or "found 0" in text:
        return "Required original definitions or authored assets are missing; restore the complete inputs and retry."
    if stage == "prototype_compilation":
        return "The prototype cannot be compiled safely from these inputs; check original definitions and authored manifests."
    return "Generated BIGF failed structural validation; repair the authored prototype inputs before building."


def _finish(report: dict) -> dict:
    report["status"] = "failed" if any(item["status"] == "failed" for item in report["checks"]) else "passed"
    if report["status"] == "passed":
        report["next_step"] = (
            "Build the separate BIGF, then run native Windows Zero Hour 1.04 tests; gameplay remains untested."
        )
    elif any(item["id"] in ("game_directory", "executable_presence", "game_data_presence")
             and item["status"] == "failed" for item in report["checks"]):
        report["next_step"] = (
            "Select the installed Zero Hour folder containing generals.exe and game.dat, then run doctor again."
        )
    elif any(item["id"] == "report_output" and item["status"] == "failed" for item in report["checks"]):
        report["next_step"] = (
            "Choose a new writable report path outside the game installation, or omit --report, then run doctor again."
        )
    elif "archive_error" in report:
        report["next_step"] = (
            "Share this diagnostic JSON, including archive_error, to investigate reader compatibility. Do not upload or replace game archives."
        )
    else:
        report["next_step"] = (
            "Resolve the reported input or content conflicts in a separate installation, then run doctor again."
        )
    return report


def diagnose(game_dir: Path, *, project: Path | None = None) -> dict:
    """Explain structural readiness without retaining a mod or changing inputs."""
    # Local import keeps the CLI integration free of a circular module import.
    from .project import BuildError, GameSource, PROJECT, compile_project, validate_archive

    expected_errors = (BuildError, BigError, IniError, LocalizationError,
                       OSError, ValueError, KeyError, TypeError, IndexError)
    selected_project = PROJECT if project is None else project
    project_version = "unknown"
    try:
        metadata = json.loads((selected_project / "content/catalog.json").read_text(encoding="utf-8"))
        candidate_version = metadata.get("version") if isinstance(metadata, dict) else None
        if isinstance(candidate_version, str) and len(candidate_version) <= 80:
            project_version = candidate_version
    except expected_errors:
        # Compilation below reports malformed project input as a failed check.
        pass
    report = {
        "schema_version": 1,
        "project_version": project_version,
        "target_game": "Zero Hour 1.04",
        "status": "failed",
        "checks": [],
        "game_version_verified": False,
        "in_game_tested": False,
        "native_runtime": "unrun",
        "source_archive_count": 0,
        "units": [],
        "next_step": "",
    }
    checks = report["checks"]
    resolved_game = None
    try:
        resolved_game = Path(game_dir).resolve(strict=True)
        if not resolved_game.is_dir():
            raise BuildError("not a directory")
        checks.append(_check("game_directory", "passed", "The selected game directory exists and is a directory."))
    except (OSError, RuntimeError, ValueError, BuildError):
        checks.append(_check("game_directory", "failed", "The selected game directory is missing, inaccessible, or not a directory."))
    if checks[0]["status"] == "failed":
        for identifier in ("executable_presence", "game_data_presence", "source_archives",
                           "prototype_compilation", "generated_archive_validation"):
            checks.append(_check(identifier, "skipped", "Requires an accessible game directory."))
        return _finish(report)
    assert resolved_game is not None

    for identifier, filename in (("executable_presence", "generals.exe"), ("game_data_presence", "game.dat")):
        try:
            present = any(path.name.lower() == filename and path.is_file() for path in resolved_game.iterdir())
            if present:
                message = filename + " is present; only file presence was checked, not version or executable integrity."
            else:
                message = filename + " is missing; select the installed Zero Hour folder."
            checks.append(_check(identifier, "passed" if present else "failed", message))
        except OSError:
            checks.append(_check(identifier, "failed", "Cannot inspect required binary presence; check directory readability."))

    source = None
    try:
        source = GameSource(resolved_game)
        report["source_archive_count"] = len(source.archives)
        if source.archive_warnings:
            report["archive_warnings"] = source.archive_warnings
        checks.append(_check("source_archives", "passed", f"Indexed {len(source.archives)} native BIGF archives without changing them."))
    except expected_errors as exc:
        checks.append(_check("source_archives", "failed", _failure_message(exc, "source_archives")))
        if hasattr(exc, "details"):
            report["archive_error"] = exc.details
    if source is None:
        checks.append(_check("prototype_compilation", "skipped", "Requires successfully indexed native BIGF sources."))
        checks.append(_check("generated_archive_validation", "skipped", "Requires a safely compiled prototype."))
        return _finish(report)

    files = None
    try:
        files, compiled = compile_project(source, PROJECT if project is None else project)
        report["units"] = [{"id": item["id"], "production_slot": item["production_slot"]}
                           for item in compiled["units"]]
        checks.append(_check("prototype_compilation", "passed", "Compiled the prototype in memory, preserving original source files and commands."))
    except expected_errors as exc:
        checks.append(_check("prototype_compilation", "failed", _failure_message(exc, "prototype_compilation")))
        if hasattr(exc, "details"):
            report["archive_error"] = exc.details
    if files is None:
        checks.append(_check("generated_archive_validation", "skipped", "Requires a safely compiled prototype."))
        return _finish(report)

    try:
        # Default temporary storage can itself be inside an unusually selected
        # game directory. Select a base outside that directory before creating
        # anything, including the temporary directory.
        bases = (Path(tempfile.gettempdir()), PROJECT if project is None else project)
        temporary = None
        for base in bases:
            base = base.resolve()
            if base.is_relative_to(resolved_game):
                continue
            try:
                temporary = tempfile.TemporaryDirectory(prefix="uw-doctor-", dir=base)
                break
            except OSError:
                continue
        if temporary is None:
            raise BuildError("No writable temporary workspace outside the game directory")
        with temporary as directory:
            generated = Path(directory) / "prototype.big"
            with generated.open("xb") as handle:
                handle.write(write_big(files))
            validate_archive(generated)
        checks.append(_check("generated_archive_validation", "passed", "Temporary BIGF passed structural checks and was removed. Native runtime remains unrun."))
    except expected_errors as exc:
        checks.append(_check("generated_archive_validation", "failed", _failure_message(exc, "generated_archive_validation")))
    return _finish(report)


def run_doctor(game_dir: Path, *, report_path: Path | None = None, project: Path | None = None) -> dict:
    """Diagnose and optionally write one exclusive JSON report outside the game."""
    report = diagnose(game_dir, project=project)
    if report_path is None:
        return report
    check = _check("report_output", "passed", "Diagnostic report saved outside the game installation.")
    report["checks"].append(check)
    _finish(report)
    destination = None
    created = False
    try:
        requested = Path(report_path)
        if requested.exists() or requested.is_symlink():
            raise FileExistsError("existing report")
        destination = requested.resolve()
        if destination.is_relative_to(Path(game_dir).resolve()):
            raise ValueError("report inside installation")
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as handle:
            created = True
            handle.write((json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    except (OSError, RuntimeError, ValueError):
        if created and destination is not None:
            destination.unlink(missing_ok=True)
        check["status"] = "failed"
        check["message"] = (
            "Cannot save the report: use a new writable path outside the game installation; existing files are never overwritten."
        )
        _finish(report)
    return report
