import unittest

from tools.uwmod.ini import IniError, parse_ini, patch_command_set


NESTED = b"""; Synthetic test data, not redistributed game data.
Object FixtureTank
  Draw = W3DModelDraw ModuleTag_Draw
    DefaultConditionState
      Model = fixture
      Turret = TURRETBONE
    End
    ConditionState = RUBBLE
      Model = fixture_rubble
    End
    AliasConditionState = REALLYDAMAGED RUBBLE
    TransitionState = NORMAL FIRING
      Model = fixture
    End
  End
  WeaponSet
    Conditions = NONE
    Weapon = PRIMARY FixtureGun
  End
  ArmorSet
    Conditions = NONE
    Armor = FixtureArmor
    DamageFX = FixtureDamageFX
  End
  Prerequisites
    Object = FixtureFactory
  End
  Body = ActiveBody ModuleTag_Body
    MaxHealth = 500.0
  End
  Behavior = AIUpdateInterface ModuleTag_AI
    Turret
      TurretTurnRate = 100
      ControlledWeaponSlots = PRIMARY
    End
    AltTurret
      ControlledWeaponSlots = SECONDARY
    End
  End
  Locomotor = SET_NORMAL FixtureLocomotor
  BuildCost = 900
End

Weapon FixtureGun
  PrimaryDamage = 50
End

CommandButton Command_Fixture
  Command = UNIT_BUILD
  Object = FixtureTank
End
"""


class IniTests(unittest.TestCase):
    def test_nested_blocks_and_scalar_alias_turret(self):
        doc = parse_ini(NESTED)
        tank = doc.find_block("object", "fixturetank")
        self.assertEqual([child.kind for child in tank.children],
                         ["Draw", "WeaponSet", "ArmorSet", "Prerequisites", "Body", "Behavior"])
        draw = tank.children[0]
        self.assertEqual([child.kind for child in draw.children],
                         ["DefaultConditionState", "ConditionState", "TransitionState"])
        self.assertEqual(draw.find_fields("AliasConditionState")[0].value, "REALLYDAMAGED RUBBLE")
        state = draw.children[0]
        self.assertEqual(state.children, ())
        self.assertEqual(state.find_fields("Turret")[0].value, "TURRETBONE")
        self.assertEqual([child.kind for child in tank.children[-1].children], ["Turret", "AltTurret"])
        self.assertEqual(tank.find_fields("Locomotor")[0].value, "SET_NORMAL FixtureLocomotor")

    def test_byte_spans_extract_exact_original_content(self):
        doc = parse_ini(NESTED)
        block = doc.find_block("Weapon", "FixtureGun")
        self.assertEqual(doc.source(block), b"Weapon FixtureGun\n  PrimaryDamage = 50\nEnd\n")
        self.assertEqual(doc.extract_block("Weapon", "FixtureGun"), NESTED[block.start:block.end])
        self.assertEqual(NESTED[block.start:block.header_end], b"Weapon FixtureGun\n")
        self.assertEqual(NESTED[block.end_start:block.end], b"End\n")
        field = block.fields[0]
        self.assertEqual(NESTED[field.start:field.end], b"  PrimaryDamage = 50\n")
        self.assertGreater(block.end_line, block.start_line)

    def test_patch_full_file_first_free_production_slot_exact_preservation(self):
        original = (b"; localized comment \xe9\r\nCommandSet Other\r\n  1 = Command_Other\r\nEnd\r\n\r\n"
                    b"CommandSet ChinaWarFactoryCommandSet ; comment\r\n"
                    b"    1 = Command_OriginalTank ; original comment\r\n"
                    b"    3 = Command_OriginalUpgrade\r\n"
                    b"    13 = Command_Rally\r\n    14 = Command_Sell\r\nEnd\r\n"
                    b"; tail retained without newline")
        patch = patch_command_set(original, "ChinaWarFactoryCommandSet", "Command_UWNewTank")
        self.assertEqual(patch.slot, 2)
        insertion = b"    2 = Command_UWNewTank\r\n"
        self.assertEqual(patch.data.replace(insertion, b"", 1), original)
        target = parse_ini(patch.data).find_block("CommandSet", "ChinaWarFactoryCommandSet")
        self.assertEqual([field.key for field in target.fields], ["1", "3", "13", "14", "2"])
        self.assertEqual(parse_ini(patch.data).extract_block("CommandSet", "Other"),
                         parse_ini(original).extract_block("CommandSet", "Other"))

    def test_case_insensitive_names_end_and_no_final_newline(self):
        source = b"commandset Factory\n  1 = Command_One\neNd"
        patch = patch_command_set(source, "factory", "Command_Two")
        self.assertEqual(patch.data, b"commandset Factory\n  1 = Command_One\n  2 = Command_Two\neNd")

    def test_no_production_slot_does_not_repurpose_rally_sell(self):
        data = b"CommandSet Factory\n" + b"".join(
            f"  {slot} = Command_{slot}\n".encode() for slot in range(1, 13)) + b"End\n"
        with self.assertRaisesRegex(IniError, "No free production slot"):
            patch_command_set(data, "Factory", "Command_New")

    def test_reject_duplicate_targets_slots_and_existing_button(self):
        cases = [b"CommandSet Factory\nEnd\nCommandSet factory\nEnd\n",
                 b"CommandSet Factory\n  1 = Command_One\n  01 = Command_Two\nEnd\n",
                 b"CommandSet Factory\n  19 = Command_One\nEnd\n",
                 b"CommandSet Factory\n  1 = Command_New\nEnd\n",
                 b"CommandSet Factory\n  Garbage = Command_One\nEnd\n",
                 b"CommandSet Factory Extra\nEnd\n",
                 b"CommandSet Factory\n  1 = Command_One Command_Two\nEnd\n"]
        for data in cases:
            with self.subTest(data=data), self.assertRaises(IniError):
                patch_command_set(data, "Factory", "Command_New")

    def test_reject_injected_names_and_invalid_slot_overrides(self):
        data = b"CommandSet Factory\nEnd\n"
        for name in ("Command_New\nEnd\nObject Evil", "Command_New;comment", "Command_New=Bad", "Command New"):
            with self.subTest(name=name), self.assertRaises(IniError):
                patch_command_set(data, "Factory", name)
        for slots in ([13], [14], [0], [1, 1], [], [True]):
            with self.subTest(slots=slots), self.assertRaises(IniError):
                patch_command_set(data, "Factory", "Command_New", slots)

    def test_reject_malformed_structure_and_unsupported_directives(self):
        for data in (b"Object Missing\n  BuildCost = 1\n", b"End\n", b"Weapon One\nEnd junk\n",
                     b"#include other.ini\n", b"Object = Wrong\nEnd\n", b"Object Wrong\n  Empty =\nEnd\n",
                     b"Object Wrong\0\nEnd\n", b"\xff\xfeO\0b\0"):
            with self.subTest(data=data), self.assertRaises(IniError):
                parse_ini(data)

    def test_damagefx_armor_fx_and_ocl_structural_blocks(self):
        data = b"""Armor FixtureArmor
  Armor = DEFAULT 100%
End
DamageFX FixtureDamageFX
  ThrottleTime = DEFAULT 100
  AmountForMajorFX = DEFAULT 1.0
  MajorFX = DEFAULT FixtureHit
End
FXList FixtureHit
  ParticleSystem
    Name = FixtureParticle
  End
  LightPulse
    Color = R:255 G:200 B:120
    Radius = 15
  End
End
ObjectCreationList FixtureDebris
  CreateDebris
    ModelNames = fixture
    ObjectCount = 1
  End
  ApplyRandomForce
    MinForceMagnitude = 1
    MaxForceMagnitude = 2
  End
End
"""
        doc = parse_ini(data)
        self.assertEqual(len(doc.blocks), 4)
        self.assertEqual(len(doc.find_block("DamageFX", "FixtureDamageFX").fields), 3)
        self.assertEqual([child.kind for child in doc.find_block("FXList", "FixtureHit").children],
                         ["ParticleSystem", "LightPulse"])
        self.assertEqual([child.kind for child in doc.find_block("ObjectCreationList", "FixtureDebris").children],
                         ["CreateDebris", "ApplyRandomForce"])

    def test_engine_semicolon_behavior_and_utf8_bom_preservation(self):
        data = b'\xef\xbb\xbfCommandButton Example\r\n  TextLabel = "label; engine truncates\r\nEnd\r\n'
        doc = parse_ini(data)
        self.assertEqual(doc.data, data)
        self.assertEqual(doc.blocks[0].fields[0].value, '"label')


if __name__ == "__main__":
    unittest.main()
