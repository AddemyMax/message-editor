"""Resolve the authored native ability graph, not a simulation of Zero Hour."""
import json
import struct
import unittest
import test_project as fixtures
from uwmod.project import GameSource,compile_project,validate_archive,BuildError
from uwmod.ini import parse_ini,IniError
from uwmod.archive import write_big
from assets.validate_w3d import validate


class TumblerSystemsTests(unittest.TestCase):
    setUp=fixtures.ProjectIntegrationTests.setUp
    write_fixture=fixtures.ProjectIntegrationTests.write_fixture
    assert_original_unchanged=fixtures.ProjectIntegrationTests.assert_original_unchanged

    def compile(self):
        return compile_project(GameSource(self.game),self.project)

    def validate_files(self,files):
        path=self.root/'Systems.big';path.write_bytes(write_big(files));return validate_archive(path)

    def test_primary_cannons_and_veterancy_are_preserved_with_independent_minigun_and_smoke(self):
        files,report=self.compile()
        original,_=GameSource(self.game).find_object('ChinaTankOverlord')
        before,=parse_ini(original).blocks
        after,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        original_sets=[c for c in before.children if c.kind.lower()=='weaponset']
        new_sets=[c for c in after.children if c.kind.lower()=='weaponset']
        self.assertEqual(len(original_sets),len(new_sets))
        for old,new in zip(original_sets,new_sets):
            self.assertEqual([f.value for f in old.find_fields('Conditions')],[f.value for f in new.find_fields('Conditions')])
            self.assertEqual([f.value for f in old.find_fields('Weapon') if f.value.startswith('PRIMARY ')],
                             [f.value for f in new.find_fields('Weapon') if f.value.startswith('PRIMARY ')])
            self.assertIn('TERTIARY NONE',[f.value for f in new.find_fields('AutoChooseSources')])
        doc=parse_ini(files['Data\\INI\\Weapon.ini'])
        source=doc.extract_block('Weapon','FixtureHumveeGun')
        copied=doc.extract_block('Weapon','UWTumblerMinigun')
        self.assertEqual(source.split(b'\n',1)[1],copied.split(b'\n',1)[1])
        self.assertEqual(report['units'][1]['cost'],2137)
        self.assert_original_unchanged()

    def test_stealth_can_move_but_firing_or_damage_reveals(self):
        files,_=self.compile();obj,=parse_ini(files['Data\\INI\\Object\\AmericaVehicleUWTumbler.ini']).blocks
        stealth=next(c for c in obj.children if c.kind.lower()=='behavior' and c.value.startswith('StealthUpdate '))
        self.assertEqual(stealth.find_fields('InnateStealth')[0].value,'Yes')
        forbidden=stealth.find_fields('StealthForbiddenConditions')[0].value.split()
        self.assertNotIn('MOVING',forbidden)
        self.assertIn('TAKING_DAMAGE',forbidden)
        for slot in ('PRIMARY','SECONDARY','TERTIARY'):self.assertIn('FIRING_'+slot,forbidden)

    def test_smoke_is_manual_and_timed_with_enemy_only_non_hp_status_effect(self):
        files,_=self.compile();weapons=parse_ini(files['Data\\INI\\Weapon.ini'])
        launcher=weapons.find_block('Weapon','UWTumblerSmokeLauncher')
        self.assertEqual(launcher.find_fields('ClipSize')[0].value,'1')
        self.assertEqual(launcher.find_fields('ClipReloadTime')[0].value,'30000')
        effect=weapons.find_block('Weapon','UWTumblerSmokeBlind')
        self.assertEqual(effect.find_fields('DamageType')[0].value,'STATUS')
        self.assertEqual(effect.find_fields('DamageStatusType')[0].value,'NO_ATTACK')
        self.assertEqual(effect.find_fields('RadiusDamageAffects')[0].value,'ENEMIES')
        self.assertLess(float(effect.find_fields('DelayBetweenShots')[0].value),float(effect.find_fields('PrimaryDamage')[0].value))
        cloud,=parse_ini(files['Data\\INI\\Object\\UWTumblerSmokeCloud.ini']).blocks
        self.assertNotIn('SELECTABLE',cloud.find_fields('KindOf')[0].value.split())
        lifetime=next(c for c in cloud.children if c.kind.lower()=='behavior' and c.value.startswith('LifetimeUpdate '))
        self.assertEqual(lifetime.find_fields('MaxLifetime')[0].value,'8000')
        self.assertEqual(self.validate_files(files)['status'],'structurally_valid')

    def test_original_ocl_records_are_retained(self):
        key='Data/INI/ObjectCreationList.ini'
        self.fixture[key]=b'; Own preserved fixture\nObjectCreationList FixtureKeep\n  CreateObject\n    ObjectNames = FixtureUnrelated\n    Count = 2\n  End\nEnd\n'
        self.write_fixture();files,_=self.compile()
        self.assertTrue(files[key.replace('/','\\')].startswith(self.fixture[key]))
        self.assert_original_unchanged()

    def test_missing_cloud_particle_and_button_fail_archive_validation(self):
        files,_=self.compile()
        for missing in ('Data\\INI\\Object\\UWTumblerSmokeCloud.ini','Art\\Textures\\uwsmoke.tga'):
            broken=dict(files);del broken[missing]
            with self.assertRaises(BuildError):self.validate_files(broken)
        broken=dict(files);key='Data\\INI\\Object\\UWTumblerSmokeCloud.ini'
        broken[key]=broken[key].replace(b'NONE UWTumblerSmoke',b'NONE UWDoesNotExist')
        with self.assertRaises(IniError):self.validate_files(broken)
        broken=dict(files);key='Data\\INI\\CommandSet.ini'
        broken[key]=broken[key].replace(b' = Command_UWTumblerSmoke',b' = Command_FixtureStop')
        with self.assertRaisesRegex(BuildError,'no visible unit command'):self.validate_files(broken)

    def test_roof_gun_rig_and_grenade_binary_are_connected(self):
        result=validate(fixtures.PROJECT/'assets/generated/uwtumbler.w3d')
        for bone in ('MG_TURRET','MG_PITCH','MG_MUZZLE','SMOKEMZ'):self.assertIn(bone,result['bones'])
        self.assertIn('UWTUMBLER.WHEEL_ARMOR',result['meshes'])
        self.assertIn('UWTUMBLER.MINIGUN',result['meshes'])
        data=json.loads((fixtures.PROJECT/'assets/generated/uwtumbler.mesh.json').read_text())
        self.assertEqual(data['bones'][10]['parent'],9)
        self.assertEqual(data['bones'][11]['parent'],10)
        gun=next(m for m in data['meshes'] if m['name']=='MINIGUN')
        self.assertEqual(gun['bone'],10)
        self.assertTrue(validate(fixtures.PROJECT/'assets/generated/uwsmkgren.w3d')['valid'])
        smoke=(fixtures.PROJECT/'assets/generated/uwsmoke.tga').read_bytes()
        self.assertEqual(struct.unpack_from('<HHBB',smoke,12),(64,64,32,8))
        self.assertEqual(len(smoke),18+64*64*4)

if __name__=='__main__':unittest.main()
