"""Local compilation of additive units against the actual installed SAGE data.

No commercial data is shipped with this source kit. Full monolithic overlays
are assembled privately from the owner's game; original files are read only.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import tempfile

from .archive import BigError, normalize_path, read_big, write_big
from .ini import IniError, IniBlock, parse_ini, patch_command_set
from .interface import compact_production_panel, windows
from .localization import LocalizationError, append_labels, append_str_labels

PROJECT = Path(__file__).resolve().parents[2]
IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z", re.ASCII)
MONOLITHIC = ("CommandSet", "CommandButton", "Weapon", "Armor", "Locomotor", "FXList", "ParticleSystem")


class BuildError(ValueError):
    pass


class SourceArchiveError(BigError):
    """An input archive was rejected; expose metadata without game contents."""
    def __init__(self, path: Path, reason: BigError):
        error = str(reason).partition(":")[0]
        self.details = {"archive_name": path.name, "reason": error}
        if hasattr(reason, "entry_details"):
            self.details.update(reason.entry_details)
        try:
            with path.open("rb") as handle:
                header = handle.read(16)
                self.details["physical_size_bytes"] = os.fstat(handle.fileno()).st_size
            if len(header) == 16:
                magic, declared_size, count, final_field = struct.unpack(">4sIII", header)
                self.details.update({"magic": magic.decode("ascii", errors="replace"),
                                     "declared_size_big_endian": declared_size,
                                     "declared_size_little_endian": struct.unpack_from("<I", header, 4)[0],
                                     "entry_count": count,
                                     "final_header_field": final_field})
        except OSError:
            pass
        super().__init__("Cannot access source archive " + path.name + ": " + error)


def _inside(path: Path, root: Path) -> bool:
    return path.resolve().is_relative_to(root.resolve())


def _json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _decode(data: bytes) -> bytes:
    # Original INI entries are generally text. Support compressed source data
    # without ever producing compressed INI overlays for the native engine.
    from .compression import decode_payload
    return decode_payload(data)


@dataclass(frozen=True)
class SourceEntry:
    archive: object
    name: str
    archive_path: Path


class GameSource:
    """Native first-archive-wins VFS with bounded lazy BIG reads."""
    def __init__(self, game_dir: Path):
        self.game_dir = game_dir.resolve(strict=True)
        if not self.game_dir.is_dir():
            raise BuildError("Game directory is not a directory")
        paths = []
        for current, dirs, files in os.walk(self.game_dir, followlinks=False,
                                           onerror=lambda e: (_ for _ in ()).throw(e)):
            for name in dirs + files:
                if (Path(current) / name).is_symlink():
                    raise BuildError("Symlinks in the game tree are unsupported: " + str(Path(current) / name))
            paths.extend(Path(current) / name for name in files if name.lower().endswith(".big"))
        self.entries: dict[str, SourceEntry] = {}
        self.archives = []
        self.skipped = []
        self.archive_warnings = []
        self._objects = None
        self.object_names = set()
        self.dependencies = {}
        for path in sorted(paths, key=lambda p: str(p).replace("/", "\\").lower()):
            with path.open("rb") as handle:
                magic = handle.read(4)
            if magic != b"BIGF":
                self.skipped.append(str(path))
                continue  # Native 1.04 loader accepts BIGF only.
            try:
                archive = read_big(path, strict=False)
            except BigError as exc:
                raise SourceArchiveError(path, exc) from exc
            self.archives.append(path)
            if archive.invalid_entries:
                self.archive_warnings.append({"archive_name": path.name,
                                              "inconsistent_entry_count": len(archive.invalid_entries),
                                              "message": "Inconsistent payload records indexed without reading them; requested data still requires valid physical bounds."})
            for entry in archive.entries:
                self.entries.setdefault(entry.name.lower(), SourceEntry(archive, entry.name, path))
        if not self.archives:
            raise BuildError("No native BIGF archives found. Supply the installed Zero Hour directory, not the React project or an empty folder.")

    def read(self, name: str) -> bytes:
        key = normalize_path(name, allow_windows_special=True).lower()
        try:
            entry = self.entries[key]
        except KeyError as exc:
            raise BuildError("Required original game file is missing: " + name) from exc
        try:
            payload = entry.archive.read(entry.name)
        except BigError as exc:
            raise SourceArchiveError(entry.archive_path, exc) from exc
        data = _decode(payload)
        self.dependencies[entry.name] = {"archive": str(entry.archive_path.relative_to(self.game_dir)),
                                         "sha256": hashlib.sha256(data).hexdigest()}
        return data

    def source(self, name: str) -> str:
        return str(self.entries[normalize_path(name, allow_windows_special=True).lower()].archive_path.relative_to(self.game_dir))

    def loose_conflicts(self, virtual_paths) -> list[str]:
        wanted = {normalize_path(name).lower() for name in virtual_paths}
        found = []
        for current, _, files in os.walk(self.game_dir, onerror=lambda e: (_ for _ in ()).throw(e)):
            for name in files:
                path = Path(current) / name
                relative = str(path.relative_to(self.game_dir)).replace("/", "\\").lower()
                if relative in wanted:
                    found.append(str(path))
        return sorted(found)

    def find_object(self, name: str) -> tuple[bytes, str]:
        if self._objects is None:
            self._objects = {}
            for key in sorted(self.entries):
                if key.startswith("data\\ini\\object\\") and key.endswith(".ini"):
                    raw = self.read(key)
                    try:
                        doc = parse_ini(raw)
                    except IniError as exc:
                        # Structural provenance only, never source contents.
                        exc.source_virtual_path = self.entries[key].name
                        exc.archive_name = self.entries[key].archive_path.name
                        raise
                    for block in doc.blocks:
                        if block.kind.lower() in ("object", "objectreskin"):
                            self.object_names.add(block.name.lower())
                        if block.kind.lower() == "object":
                            self._objects.setdefault(block.name.lower(), []).append((doc.source(block), key))
        matches = self._objects.get(name.lower(), [])
        if len(matches) != 1:
            raise BuildError(f"Expected exactly one original Object {name}; found {len(matches)}. Use a clean Zero Hour 1.04 installation.")
        return matches[0]


def _newline(data: bytes) -> bytes:
    return b"\r\n" if b"\r\n" in data else b"\n"


def _edit(data: bytes, changes: list[tuple[int, int, bytes]]) -> bytes:
    previous = len(data) + 1
    for start, end, replacement in sorted(changes, reverse=True):
        if not 0 <= start <= end <= len(data) or end > previous:
            raise BuildError("Overlapping or invalid compiler edit")
        data = data[:start] + replacement + data[end:]
        previous = start
    return data


def _fields(data: bytes, block: IniBlock, updates: dict[str, str | None]) -> bytes:
    changes = []
    additions = []
    nl = _newline(data)
    for key, value in updates.items():
        existing = block.find_fields(key)
        if len(existing) > 1:
            raise BuildError(f"Ambiguous scalar {key} in {block.kind} {block.name}")
        if existing:
            item = existing[0]
            raw = data[item.start:item.end]
            indent = raw[:len(raw) - len(raw.lstrip(b" \t"))]
            replacement = b"" if value is None else indent + key.encode("ascii") + b" = " + value.encode("ascii") + nl
            changes.append((item.start, item.end, replacement))
        elif value is not None:
            additions.append(b"  " + key.encode("ascii") + b" = " + value.encode("ascii") + nl)
    if additions:
        changes.append((block.end_start, block.end_start, b"".join(additions)))
    return _edit(data, changes)


def _scalar(block: IniBlock, key: str) -> str:
    fields = block.find_fields(key)
    if len(fields) != 1:
        raise BuildError(f"Expected one {key} in {block.kind} {block.name}")
    return fields[0].value


def _rename(data: bytes, kind: str, name: str) -> bytes:
    if not IDENTIFIER.fullmatch(name):
        raise BuildError("Unsafe new definition name: " + name)
    block, = parse_ini(data).blocks
    if block.kind.lower() != kind.lower():
        raise BuildError("Unexpected source definition type")
    return kind.encode("ascii") + b" " + name.encode("ascii") + _newline(data) + data[block.header_end:]


def _append(original: bytes, definitions: list[bytes]) -> bytes:
    doc = parse_ini(original)
    names = {(b.kind.lower(), b.name.lower()) for b in doc.blocks}
    for definition in definitions:
        for block in parse_ini(definition).blocks:
            key = (block.kind.lower(), block.name.lower())
            if key in names:
                raise BuildError("New definition already exists: " + block.kind + " " + block.name)
            names.add(key)
    nl = _newline(original)
    return original + nl + nl.join(d.rstrip(b"\r\n") for d in definitions) + nl


def _manifest(path: Path) -> dict:
    value = _json(path)
    for key in ("id", "source_object", "production_object", "prerequisite", "button", "model", "image", "fire_fx", "size_reference_object"):
        if not IDENTIFIER.fullmatch(value[key]):
            raise BuildError("Invalid manifest identifier: " + key)
    for key in ("health", "build_cost", "build_time", "attack_range", "delay_between_shots", "clip_reload_ms",
                "damage_multiplier", "armor_multiplier", "speed_multiplier", "size_reference_ratio"):
        if type(value[key]) not in (int, float) or not 0 < value[key] < 100000:
            raise BuildError("Invalid positive manifest number: " + key)
    for key in ("major_radius", "minor_radius", "height"):
        value_number = value["geometry"][key]
        if type(value_number) not in (int, float) or not 0 < value_number < 100000:
            raise BuildError("Invalid manifest geometry: " + key)
    return value


def compile_project(source: GameSource, project: Path = PROJECT) -> tuple[dict[str, bytes], dict]:
    catalog = _json(project / "content/catalog.json")
    manifests = []
    for relative in catalog["units"]:
        path = (project / "content" / relative).resolve()
        if not _inside(path, project / "content"):
            raise BuildError("Unit manifest escapes content directory")
        manifests.append(_manifest(path))
    if not manifests:
        raise BuildError("Unit catalog is empty")
    original = {name: source.read(f"Data\\INI\\{name}.ini") for name in MONOLITHIC}
    output = {name: raw for name, raw in original.items()}
    added = {name: [] for name in MONOLITHIC}
    files: dict[str, bytes] = {}
    labels = {}
    summary = []
    effect_paths = set()
    asset_names = set()
    images = []
    unit_ids = set()

    for unit_index, spec in enumerate(manifests):
        if spec["id"].lower() in unit_ids:
            raise BuildError("Duplicate unit catalog id: " + spec["id"])
        unit_ids.add(spec["id"].lower())
        effect_path = (project / "content" / spec["effect_file"]).resolve()
        if not _inside(effect_path, project / "content"):
            raise BuildError("Effect file escapes content directory")
        if effect_path not in effect_paths:
            effect_paths.add(effect_path)
            effect_doc = parse_ini(effect_path.read_bytes())
            for block in effect_doc.blocks:
                if block.kind.lower() not in ("particlesystem", "fxlist"):
                    raise BuildError("Unit effects may declare only ParticleSystem or FXList")
                target = "ParticleSystem" if block.kind.lower() == "particlesystem" else "FXList"
                added[target].append(effect_doc.source(block))
        asset_names.update(spec["asset_files"])
        if Path(spec["cameo_file"]).name != spec["cameo_file"]:
            raise BuildError("Cameo must be a generated asset filename")
        images.append(f"""MappedImage {spec['image']}
  Texture = {spec['cameo_file']}
  TextureWidth = 128
  TextureHeight = 128
  Coords = Left:0 Top:0 Right:128 Bottom:128
  Status = NONE
End
""".encode("ascii"))
        seed, object_path = source.find_object(spec["source_object"])
        if spec["id"].lower() in source.object_names:
            raise BuildError("New object already exists in installed game: " + spec["id"])
        factory, factory_path = source.find_object(spec["production_object"])
        reference, reference_path = source.find_object(spec["size_reference_object"])
        reference_block, = parse_ini(reference).blocks
        dimension_keys = {"major_radius": "GeometryMajorRadius", "minor_radius": "GeometryMinorRadius", "height": "GeometryHeight"}
        reference_geometry = {key: float(_scalar(reference_block, field)) for key, field in dimension_keys.items()}
        if any(not math.isfinite(value) or value <= 0 for value in reference_geometry.values()):
            raise BuildError("Invalid size reference geometry")
        # Asset Scale affects rendering; explicit collision dimensions and the
        # decal are enlarged with it. Use local Overlord geometry as a lower
        # bound, rather than assuming every installation has identical sizes.
        size_factor = max(1.0, *(spec["size_reference_ratio"] * reference_geometry[key] / spec["geometry"][key]
                                 for key in dimension_keys))
        geometry = {key: value * size_factor for key, value in spec["geometry"].items()}
        source.find_object(spec["prerequisite"])
        factory_block, = parse_ini(factory).blocks
        command_set = _scalar(factory_block, "CommandSet")
        if not IDENTIFIER.fullmatch(command_set):
            raise BuildError("Invalid source factory command set")
        try:
            patch = patch_command_set(output["CommandSet"], command_set, spec["button"])
        except IniError as exc:
            if str(exc) != "No free production slot 1..12; original commands were preserved":
                raise
            # A native command-set slot alone would be invisible: build its
            # matching private WND overlay before allowing that slot.
            patch = patch_command_set(output["CommandSet"], command_set, spec["button"], slots=(15,))
            ui_path = "Window\\ControlBar.wnd"
            if ui_path.lower() not in source.entries:
                raise IniError("No free production slot 1..12; compact panel requires original Window/ControlBar.wnd")
            if ui_path not in files:
                files[ui_path] = compact_production_panel(source.read(ui_path))
        output["CommandSet"] = patch.data
        clone = _rename(seed, "Object", spec["id"])
        body, = parse_ini(clone).blocks
        physics = [c for c in body.children if c.kind.lower() == "behavior" and c.value.split()[0].lower() == "physicsbehavior"]
        ai = [c for c in body.children if c.kind.lower() == "behavior" and "aiupdate" in c.value.split()[0].lower()]
        bodies = [c for c in body.children if c.kind.lower() == "body"]
        if len(physics) != 1 or len(ai) != 1 or len(bodies) != 1:
            raise BuildError("Source tank must have exactly one Body, PhysicsBehavior and AIUpdate")
        if not body.find_fields("Locomotor") or any(f.start < ai[0].end for f in body.find_fields("Locomotor")):
            raise BuildError("Source locomotor must follow the AIUpdate module")
        # Replace visual modules only in the NEW object, not the original tank.
        old_draws = [c for c in body.children if c.kind.lower() == "draw"]
        if not old_draws:
            raise BuildError("Source tank has no Draw module")
        track_marks = old_draws[0].find_fields("TrackMarks")
        track_line = f"    TrackMarks = {track_marks[0].value}\n" if track_marks else ""
        # SAGE applies recoil after turret pitch and replaces the bone's
        # control matrix. BARREL must serve pitch alone; visual recoil needs
        # a separate child pivot in a future revision of the authored model.
        draw = f"""  Draw = W3DTankDraw UWLongmaDraw
    DefaultConditionState
      Model = {spec['model']}
      Turret = TURRET
      TurretPitch = BARREL
      WeaponFireFXBone = PRIMARY MUZZLE
      WeaponLaunchBone = PRIMARY MUZZLE
    End
    ConditionState = RUBBLE
      Model = NONE
    End
{track_line}\
  End
""".encode("ascii").replace(b"\n", _newline(clone))
        clone = _edit(clone, [(c.start, c.end, draw if index == 0 else b"") for index, c in enumerate(old_draws)])
        body, = parse_ini(clone).blocks
        prereqs = [c for c in body.children if c.kind.lower() == "prerequisites"]
        requirement = f"  Prerequisites\n    Object = {spec['prerequisite']}\n  End\n".encode("ascii").replace(b"\n", _newline(clone))
        if len(prereqs) > 1:
            raise BuildError("Multiple source prerequisite blocks")
        if prereqs:
            clone = _edit(clone, [(prereqs[0].start, prereqs[0].end, requirement)])
        else:
            clone = _edit(clone, [(body.header_end, body.header_end, requirement)])
        body, = parse_ini(clone).blocks
        clone = _fields(clone, body, {
            "DisplayName": spec["display_label"], "SelectPortrait": spec["image"], "ButtonImage": spec["image"],
            "BuildCost": str(spec["build_cost"]), "BuildTime": str(spec["build_time"]), "Scale": f"{size_factor:g}",
            "BuildVariations": None, "Geometry": "BOX", "GeometryMajorRadius": f"{geometry['major_radius']:g}",
            "GeometryMinorRadius": f"{geometry['minor_radius']:g}", "GeometryHeight": f"{geometry['height']:g}",
            # Longma's detailed geometry exceeds the legacy dynamic shadow
            # buffer budget. Use the engine's standard decal texture instead
            # of extruding the full model into a stencil shadow volume.
            "GeometryIsSmall": "No", "Shadow": "SHADOW_DECAL",
            "ShadowSizeX": f"{64 * size_factor:g}", "ShadowSizeY": f"{34 * size_factor:g}", "ShadowTexture": "shadow",
        })
        body, = parse_ini(clone).blocks
        active = next(c for c in body.children if c.kind.lower() == "body")
        active_source = clone[active.start:active.end]
        # Editing nested byte spans works without reconstructing other modules.
        active_local, = parse_ini(b"Object Temporary\n" + active_source + b"End\n").blocks
        wrapper = b"Object Temporary\n" + active_source + b"End\n"
        wrapper = _fields(wrapper, active_local.children[0], {"MaxHealth": str(spec["health"]), "InitialHealth": str(spec["health"])})
        wrapped, = parse_ini(wrapper).blocks
        replacement = wrapper[wrapped.children[0].start:wrapped.children[0].end]
        clone = _edit(clone, [(active.start, active.end, replacement)])
        body, = parse_ini(clone).blocks
        edits = []
        weapon_map = {}
        armor_map = {}
        locomotive_map = {}
        for weapon_set in (c for c in body.children if c.kind.lower() == "weaponset"):
            for field in weapon_set.find_fields("Weapon"):
                tokens = field.value.split()
                if len(tokens) != 2 or tokens[1].upper() == "NONE":
                    if len(tokens) == 2 and tokens[1].upper() == "NONE":
                        continue
                    raise BuildError("Unsupported source Weapon field: " + field.value)
                old = tokens[1]
                if old not in weapon_map:
                    new = f"UWLM{unit_index}_W{len(weapon_map)}"
                    raw = parse_ini(original["Weapon"]).extract_block("Weapon", old)
                    raw = _rename(raw, "Weapon", new)
                    weapon, = parse_ini(raw).blocks
                    damage = float(_scalar(weapon, "PrimaryDamage")) * spec["damage_multiplier"]
                    raw = _fields(raw, weapon, {"PrimaryDamage": f"{damage:g}", "AttackRange": str(spec["attack_range"]),
                                               "DelayBetweenShots": str(spec["delay_between_shots"]), "FireFX": spec["fire_fx"],
                                               "ClipSize": "3", "ShotsPerBarrel": "1", "AutoReloadsClip": "Yes",
                                               "ClipReloadTime": str(spec["clip_reload_ms"])})
                    # Preserve the source firing sound through copied Sound FX
                    # nuggets (names only; no commercial audio is distributed).
                    if not weapon_map:
                        old_fx = weapon.find_fields("FireFX")
                        if old_fx and old_fx[0].value.upper() != "NONE":
                            sound_doc = parse_ini(original["FXList"])
                            candidates = [b for b in sound_doc.blocks if b.kind.lower() == "fxlist" and b.name.lower() == old_fx[0].value.lower()]
                            if not candidates and "data\\ini\\default\\fxlist.ini" in source.entries:
                                sound_doc = parse_ini(source.read("Data\\INI\\Default\\FXList.ini"))
                                candidates = [b for b in sound_doc.blocks if b.kind.lower() == "fxlist" and b.name.lower() == old_fx[0].value.lower()]
                            if len(candidates) != 1:
                                raise BuildError("Source firing FX definition is missing or ambiguous: " + old_fx[0].value)
                            fx, = candidates
                            sounds = [sound_doc.source(c) for c in fx.children if c.kind.lower() == "sound"]
                            if sounds:
                                fx_index = next((i for i, raw in enumerate(added["FXList"]) if parse_ini(raw).blocks[0].name.lower() == spec["fire_fx"].lower()), None)
                                if fx_index is None:
                                    raise BuildError("Authored firing FX is not declared")
                                fx_raw = added["FXList"][fx_index]
                                fx_block, = parse_ini(fx_raw).blocks
                                added["FXList"][fx_index] = _edit(fx_raw, [(fx_block.end_start, fx_block.end_start, b"".join(sounds))])
                    added["Weapon"].append(raw)
                    weapon_map[old] = new
                edits.append((field.start, field.end, f"    Weapon = {tokens[0]} {weapon_map[old]}\n".encode("ascii").replace(b"\n", _newline(clone))))
        if not weapon_map:
            raise BuildError("Source object has no primary weapon to clone")
        for armor_set in (c for c in body.children if c.kind.lower() == "armorset"):
            for field in armor_set.find_fields("Armor"):
                old = field.value
                if old not in armor_map:
                    new = f"UWLM{unit_index}_A{len(armor_map)}"
                    raw = _rename(parse_ini(original["Armor"]).extract_block("Armor", old), "Armor", new)
                    armor, = parse_ini(raw).blocks
                    modifications = []
                    for entry in armor.find_fields("Armor"):
                        tokens = entry.value.split()
                        if len(tokens) != 2 or not tokens[1].endswith("%"):
                            raise BuildError("Unsupported source armor percentage")
                        percent = float(tokens[1][:-1]) * spec["armor_multiplier"]
                        modifications.append((entry.start, entry.end, f"  Armor = {tokens[0]} {percent:g}%\n".encode("ascii").replace(b"\n", _newline(raw))))
                    added["Armor"].append(_edit(raw, modifications))
                    armor_map[old] = new
                edits.append((field.start, field.end, f"    Armor = {armor_map[old]}\n".encode("ascii").replace(b"\n", _newline(clone))))
        for field in body.find_fields("Locomotor"):
            tokens = field.value.split()
            if len(tokens) != 2:
                raise BuildError("Unsupported source Locomotor field")
            old = tokens[1]
            if old not in locomotive_map:
                new = f"UWLM{unit_index}_L{len(locomotive_map)}"
                raw = _rename(parse_ini(original["Locomotor"]).extract_block("Locomotor", old), "Locomotor", new)
                locomotor, = parse_ini(raw).blocks
                speeds = {"Speed": f"{float(_scalar(locomotor, 'Speed')) * spec['speed_multiplier']:g}"}
                if locomotor.find_fields("SpeedDamaged"):
                    speeds["SpeedDamaged"] = f"{float(_scalar(locomotor, 'SpeedDamaged')) * spec['speed_multiplier']:g}"
                raw = _fields(raw, locomotor, speeds)
                added["Locomotor"].append(raw)
                locomotive_map[old] = new
            edits.append((field.start, field.end, f"  Locomotor = {tokens[0]} {locomotive_map[old]}\n".encode("ascii").replace(b"\n", _newline(clone))))
        clone = _edit(clone, edits)
        object_virtual = f"Data\\INI\\Object\\{spec['id']}.ini"
        if object_virtual.lower() in source.entries:
            raise BuildError("New object file collides with an installed virtual path: " + object_virtual)
        files[object_virtual] = clone
        added["CommandButton"].append(f"""CommandButton {spec['button']}
  Command = UNIT_BUILD
  Object = {spec['id']}
  TextLabel = {spec['button_label']}
  ButtonImage = {spec['image']}
  ButtonBorderType = BUILD
  DescriptLabel = {spec['tooltip_label']}
End
""".encode("ascii"))
        added["CommandSet"] = []
        for key, text in spec["labels"].items():
            if key.lower() in {label.lower() for label in labels}:
                raise BuildError("Duplicate new label: " + key)
            labels[key] = text
        summary.append({"id": spec["id"], "factory": spec["production_object"], "command_set": command_set,
                        "model_scale": size_factor, "geometry": geometry,
                        "size_reference": {"object": spec["size_reference_object"], "source_file": reference_path,
                                           "geometry": reference_geometry, "minimum_ratio": spec["size_reference_ratio"]},
                        "production_slot": patch.slot, "source_object_file": object_path, "source_factory_file": factory_path,
                        "health": spec["health"], "cost": spec["build_cost"], "build_seconds": spec["build_time"],
                        "weapons": weapon_map, "armor": armor_map, "locomotors": locomotive_map})

    for name, definitions in added.items():
        files[f"Data\\INI\\{name}.ini"] = _append(output[name], definitions) if definitions else output[name]
    image_virtual = "Data\\INI\\MappedImages\\HandCreated\\UltimateWarfare.ini"
    if image_virtual.lower() in source.entries:
        raise BuildError("New mapped-image file already exists: " + image_virtual)
    image_names = {spec["image"].lower() for spec in manifests}
    if len(image_names) != len(manifests):
        raise BuildError("Duplicate new mapped-image name in unit catalog")
    for key in source.entries:
        if key.startswith("data\\ini\\mappedimages\\") and key.endswith(".ini"):
            if any(b.kind.lower() == "mappedimage" and b.name.lower() in image_names
                   for b in parse_ini(source.read(key)).blocks):
                raise BuildError("New mapped-image name already exists in " + key)
    files[image_virtual] = b"\n".join(images)
    for name in sorted(asset_names):
        if Path(name).name != name or not re.fullmatch(r"[A-Za-z0-9_-]+\.(w3d|tga)", name, re.IGNORECASE):
            raise BuildError("Only generated W3D/TGA asset filenames are supported")
        virtual = ("Art\\W3D\\" if name.endswith(".w3d") else "Art\\Textures\\") + name
        path = project / "assets/generated" / name
        if not path.is_file():
            raise BuildError("Generated original asset missing: " + str(path))
        if virtual.lower() in source.entries:
            raise BuildError("Original asset name collides with installed game: " + virtual)
        files[virtual] = path.read_bytes()
    localization = []
    if "data\\generals.str" in source.entries:
        name = "Data\\Generals.str"
        files[name] = append_str_labels(source.read(name), labels)
        localization.append(name)
    else:
        for key in sorted(source.entries):
            if re.fullmatch(r"data\\[^\\]+\\generals\.csf", key):
                files[source.entries[key].name] = append_labels(source.read(key), labels)
                localization.append(source.entries[key].name)
        if not localization:
            raise BuildError("Original locale Generals.csf (or full Generals.str) not found; original UI text cannot safely be preserved.")
    conflicts = source.loose_conflicts(files)
    # Object files also shadow archived source; reject all loose object INIs
    # instead of silently deriving a clone from a different effective source.
    for current, _, names in os.walk(source.game_dir, onerror=lambda e: (_ for _ in ()).throw(e)):
        for name in names:
            relative = str((Path(current) / name).relative_to(source.game_dir)).replace("/", "\\").lower()
            if relative.startswith("data\\ini\\object\\") and relative.endswith(".ini"):
                conflicts.append(str(Path(current) / name))
            if relative == "data\\generals.str" and "data\\generals.str" not in source.entries:
                conflicts.append(str(Path(current) / name))
    if conflicts:
        raise BuildError("Loose game files would override the mod or its source. Use a clean separate installation; no originals were changed: " + "; ".join(sorted(set(conflicts))))
    report = {"version": catalog["version"], "game_target": catalog["target_game"], "game_version_verified": False,
              "in_game_tested": False, "native_tests": "requires Windows Zero Hour 1.04",
              "units": summary, "overlay_paths": sorted(files), "localization": localization,
              "sources": dict(sorted(source.dependencies.items())),
              "preservation": "Existing definitions retained; new cloned objects only. No AI, maps, campaigns, economy, factions or generals edited."}
    return files, report


def validate_archive(path: Path) -> dict:
    archive = read_big(path)
    if archive.magic != b"BIGF":
        raise BuildError("Zero Hour 1.04 requires BIGF, not BIG4")
    names = {entry.name.lower(): entry.name for entry in archive.entries}
    documents = {}
    for name in MONOLITHIC:
        key = f"data\\ini\\{name.lower()}.ini"
        if key not in names:
            raise BuildError("Required full overlay missing: " + key)
        documents[name] = parse_ini(archive.read(names[key]))
    objects = []
    models = []
    for key, name in names.items():
        if key.startswith("data\\ini\\object\\"):
            doc = parse_ini(archive.read(name))
            objects.extend(block.name for block in doc.blocks if block.kind.lower() == "object")
            for block in doc.blocks:
                if block.kind.lower() != "object":
                    raise BuildError("New object file must contain only complete new Objects")
                for child in block.children:
                    if child.kind.lower() == "weaponset":
                        for field in child.find_fields("Weapon"):
                            ref = field.value.split()[-1]
                            if ref.upper() != "NONE":
                                documents["Weapon"].find_block("Weapon", ref)
                    elif child.kind.lower() == "armorset":
                        for field in child.find_fields("Armor"):
                            documents["Armor"].find_block("Armor", field.value)
                    elif child.kind.lower() == "draw":
                        for state in child.children:
                            for field in state.find_fields("Model"):
                                if field.value.upper() != "NONE":
                                    models.append((field.value, state))
                for field in block.find_fields("Locomotor"):
                    documents["Locomotor"].find_block("Locomotor", field.value.split()[-1])
    if not objects:
        raise BuildError("Archive contains no new Object")
    for command_set in documents["CommandSet"].blocks:
        if any(field.key == "15" and field.value == "Command_ConstructUWLongma" for field in command_set.fields):
            ui_key = "window\\controlbar.wnd"
            if ui_key not in names:
                raise BuildError("Extended production command lacks its control bar overlay")
            extra = [node for node in windows(archive.read(names[ui_key]))
                     if node.name == "ControlBar.wnd:ButtonCommand15"]
            if len(extra) != 1 or extra[0].parent is None or extra[0].parent.name != "ControlBar.wnd:CommandWindow":
                raise BuildError("Extended production command lacks a matching command window")
    required_assets = ["art\\w3d\\uwlongma.w3d", "art\\textures\\uwlongma.tga",
                       "art\\textures\\uwlmcameo.tga", "art\\textures\\uwmflash.tga"]
    for key in required_assets:
        if key not in names:
            raise BuildError("Original generated asset missing: " + key)
    from assets.validate_w3d import chunks
    for model, state in models:
        key = "art\\w3d\\" + model.lower() + ".w3d"
        if key not in names:
            raise BuildError("Draw model is absent from archive: " + model)
        top = chunks(archive.read(names[key]))
        trees = [payload for cid, payload in top if cid == 0x100]
        if len(trees) != 1:
            raise BuildError("New model requires one hierarchy")
        headers = [payload for cid, payload in trees[0] if cid == 0x101]
        pivots = [payload for cid, payload in trees[0] if cid == 0x102]
        if len(headers) != 1 or len(headers[0]) != 36 or len(pivots) != 1 or len(pivots[0]) % 60:
            raise BuildError("Invalid new model hierarchy header/pivots")
        _, model_name, count, *_ = struct.unpack("<I16sI3f", headers[0])
        if model_name.split(b"\x00")[0].decode("ascii").lower() != model.lower() or len(pivots[0]) != count * 60:
            raise BuildError("Model name or pivot count mismatch")
        bones = {pivots[0][start:start+16].split(b"\x00")[0].decode("ascii").lower()
                 for start in range(0, len(pivots[0]), 60)}
        for field in state.fields:
            if field.key.lower() in ("turret", "turretpitch", "weaponfirefxbone", "weaponlaunchbone", "weaponrecoilbone"):
                ref = field.value.split()[-1].lower()
                numbered = field.key.lower() in ("weaponfirefxbone", "weaponlaunchbone", "weaponrecoilbone")
                if ref not in bones and not (numbered and all(f"{ref}{i:02d}" in bones for i in range(1, 4))):
                    raise BuildError("Draw references a missing model bone: " + field.value)
    return {"status": "structurally_valid", "magic": "BIGF", "bytes": archive.size,
            "entries": len(archive.entries), "objects": objects, "models": sorted({m for m, _ in models}), "in_game_tested": False}


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        raise BuildError("Output already exists; choose a new path or remove your previous build explicitly: " + str(path))
    fd, temporary = tempfile.mkstemp(prefix=".uw-build-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        # Refuse overwrite even if another process creates the destination.
        created = False
        try:
            with path.open("xb") as handle:
                created = True
                handle.write(Path(temporary).read_bytes())
        except BaseException:
            if created:
                path.unlink(missing_ok=True)
            raise
    finally:
        Path(temporary).unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for verb in ("inspect", "build", "check-launch", "doctor"):
        command = sub.add_parser(verb)
        command.add_argument("--game-dir", type=Path, required=True)
        if verb == "build":
            command.add_argument("--output", type=Path, default=PROJECT / "dist/UltimateWarfare.big")
        elif verb == "check-launch":
            command.add_argument("--archive", type=Path, required=True)
        elif verb == "doctor":
            command.add_argument("--report", type=Path)
    validate = sub.add_parser("validate")
    validate.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.command == "doctor":
        from .diagnostics import run_doctor
        result = run_doctor(args.game_dir, report_path=args.report)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] == "passed" else 1
    try:
        if args.command == "validate":
            result = validate_archive(args.archive)
        elif args.command == "check-launch":
            result = validate_archive(args.archive)
            source = GameSource(args.game_dir)
            if _inside(args.archive, source.game_dir):
                raise BuildError("Mod archive must stay outside the game installation so vanilla startup stays untouched")
            archive = read_big(args.archive)
            conflicts = source.loose_conflicts(entry.name for entry in archive.entries)
            if conflicts:
                raise BuildError("Loose files mask mod entries: " + "; ".join(conflicts))
            manifest_path = args.archive.with_suffix(".manifest.json")
            if not manifest_path.is_file():
                raise BuildError("Companion build manifest missing; build this archive with the project tool before launching")
            manifest = _json(manifest_path)
            if hashlib.sha256(args.archive.read_bytes()).hexdigest() != manifest.get("archive_sha256"):
                raise BuildError("Archive checksum no longer matches its build manifest")
            for virtual, info in manifest.get("sources", {}).items():
                if hashlib.sha256(source.read(virtual)).hexdigest() != info["sha256"]:
                    raise BuildError("Original game configuration changed since build; rebuild against this installation: " + virtual)
            executable = next((p for p in source.game_dir.iterdir() if p.name.lower() == "generals.exe"), None)
            if executable is None:
                raise BuildError("Original generals.exe not found in game directory")
            result["launch"] = "preflight_passed; actual runtime not tested by this command"
        else:
            source = GameSource(args.game_dir)
            files, result = compile_project(source)
            result["archives_indexed"] = len(source.archives)
            result["non_native_archives_skipped"] = source.skipped
            if args.command == "build":
                output = args.output.resolve()
                if _inside(output, source.game_dir):
                    raise BuildError("Refusing to write a BIG inside the game installation (including original archives)")
                report_path = output.with_suffix(".manifest.json")
                if report_path.exists():
                    raise BuildError("Build report already exists: " + str(report_path))
                data = write_big(files)
                _atomic_write(output, data)
                try:
                    result["archive"] = str(output)
                    result["archive_sha256"] = hashlib.sha256(data).hexdigest()
                    result["validation"] = validate_archive(output)
                    _atomic_write(report_path, (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                except BaseException:
                    # This archive was created by this operation only.
                    output.unlink(missing_ok=True)
                    raise
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (BuildError, BigError, IniError, LocalizationError, ValueError, OSError, KeyError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
