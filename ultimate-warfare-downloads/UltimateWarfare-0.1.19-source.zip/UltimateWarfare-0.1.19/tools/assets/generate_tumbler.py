#!/usr/bin/env python3
"""Original procedural fan interpretation of the Batman Begins Tumbler.

No film mesh, third-party model or commercial texture is imported.
SPDX-License-Identifier: MIT (code); authored mesh/atlas CC0-1.0.
"""
import json
import math
from pathlib import Path
import struct
from generate_longma import Mesh, w3d, cameo_tga

OUTPUT = Path(__file__).resolve().parents[2] / 'assets/generated'
NAME, TEXTURE, SCALE = 'UWTUMBLER', 'uwtumbler.tga', 1.25
CENTERS = [(7.1,-4.1,2.35),(7.1,4.1,2.35),(-6.1,-5.05,3.05),(-6.1,5.05,3.05),(-6.1,-3.35,3.05),(-6.1,3.35,3.05)]
BONES = [('ROOTTRANSFORM',-1,(0,0,0))] + [(n,0,c) for n,c in zip(('WHEEL_FL','WHEEL_FR','WHEEL_RL','WHEEL_RR','WHEEL_ML','WHEEL_MR'),CENTERS)] + [('MUZZLE01',0,(5.3,-1.1,3.7)),('MUZZLE02',0,(5.3,1.1,3.7))]
BONES = [(n,p,tuple(x*SCALE for x in c)) for n,p,c in BONES]
ORIGINS = [c for _,_,c in BONES]


def vehicle():
    hull, detail, color = Mesh('BODY',0), Mesh('HARDWARE',0), Mesh('HOUSECOLOR',0)
    hull.prism([(-8.7,-3.4),(3.9,-3.3),(6.0,-1.7),(6.0,1.7),(3.9,3.3),(-8.7,3.4)],
               [(-8.0,-3.7),(2.6,-3.5),(4.7,-1.9),(4.7,1.9),(2.6,3.5),(-8.0,3.7)],2.0,4.55,0)
    hull.prism([(-6.7,-2.8),(3.8,-2.8),(4.6,-1.8),(4.6,1.8),(3.8,2.8),(-6.7,2.8)],
               [(-5.7,-2.2),(-1.0,-2.3),(.5,-1.7),(.5,1.7),(-1.,2.3),(-5.7,2.2)],4.5,7.0,1)
    # Split sloping windshield, center spine and separate side windows.
    for s in (-1,1):
        pts=[(4.38,s*.18,4.71),(4.10,s*1.65,4.89),(.68,s*1.6,6.97),(.68,s*.18,6.97)]
        if s<0: pts.reverse()
        hull.face(pts,3)
        pts=[(-4.8,s*2.80,5.12),(2.75,s*2.90,4.75),(-1.3,s*2.49,6.74),(-4.8,s*2.47,6.82)]
        if s>0: pts.reverse()
        hull.face(pts,3)
        # Layered angular side armor, wedge front fenders, a narrow open center nose.
        hull.prism([(-7.7,s*3.3),(-1.0,s*3.2),(2.5,s*4.5),(-5.8,s*4.55)],
                   [(-7.2,s*3.15),(-1.4,s*3.3),(1.5,s*3.85),(-5.5,s*4.15)],2.6,5.1,2) if s>0 else hull.prism(
                   [(-5.8,s*4.55),(2.5,s*4.5),(-1.,s*3.2),(-7.7,s*3.3)],
                   [(-5.5,s*4.15),(1.5,s*3.85),(-1.4,s*3.3),(-7.2,s*3.15)],2.6,5.1,2)
        f=[(3.0,s*3.0),(9.0,s*3.0),(9.4,s*5.7),(2.4,s*5.3)]
        t=[(3.3,s*3.0),(8.5,s*3.1),(7.3,s*5.35),(2.7,s*4.6)]
        if s<0: f.reverse();t.reverse()
        hull.prism(f,t,2.5,3.65,1)
        for x in (4.9,6.0):
            detail.box((x,s*2.7,2.6),(.26,3.8,.24),5,yaw=s*.28)
        detail.box((4.4,s*2.9,3.2),(.35,2.4,.35),6,yaw=s*.48)
        detail.box((5.2,s*1.1,3.75),(1.3,.6,.6),4)
        detail.cylinder((5.87,s*1.1,3.75),.17,.07,'x',12,7)
        # Visible diagonal armor ribs and recessed door panels.
        hull.box((-1.6,s*3.53,4.7),(4.4,.18,.24),2,roll=-.32)
        hull.box((-4.8,s*3.73,4.1),(2.8,.18,.22),1,roll=.45)
        detail.box((-3.7,s*3.91,3.5),(2.2,.08,.9),4)
        for vent in range(4):
            detail.box((-4.45+vent*.47,s*3.97,3.5),(.17,.09,.7),5)
        for x in (-6.,-3.2,.2):
            detail.cylinder((x,s*3.65,4.9),.075,.12,'y',6,5)
        # Separate rear aero flaps, supported above the armor.
        for x in (-7.0,-4.6):
            detail.box((x,s*3.5,6.35),(.22,.22,1.7),6,roll=.2)
        for x in (-7.3,-4.7):
            hull.box((x,s*3.8,7.15),(1.85,2.8,.16),2,roll=-.16)
        for x in (-6.0,-4.5,-3.0):
            detail.box((x,s*3.8,4.6),(.65,.12,.12),5)
        color.box((-1.7,s*3.57,4.28),(1.4,.05,.12),10)
        # Visible white headlights placed at the front outer fenders.
        detail.box((8.48,s*3.4,3.48),(.12,.42,.18),11)
    # Central rear jet, ring and dark recessed aperture, radiator louvers.
    detail.cylinder((-8.8,0,3.7),1.45,1.8,'x',20,5)
    detail.cylinder((-9.73,0,3.7),1.18,.10,'x',20,6)
    detail.cylinder((-9.8,0,3.7),.92,.12,'x',20,7)
    for x in (-7.6,-7.0,-6.4,-5.8):
        detail.box((x,0,7.12),(.24,3.5,.16),4)
    meshes=[hull,detail,color]
    for i,(x,y,z) in enumerate(CENTERS):
        tire=Mesh('TIRE'+str(i),i+1)
        radius=2.35 if i<2 else 3.05
        width=2.15 if i<2 else 1.58
        tire.cylinder((x,y,z),radius,width,'y',24,4)
        tire.cylinder((x,y,z),radius*.58,width+.07,'y',16,5)
        tire.cylinder((x,y,z),radius*.36,width+.12,'y',12,7)
        # Front road tires have finer grooves; rear tires have broad lugs.
        steps=36 if i<2 else 24
        for k in range(steps):
            a=k*math.tau/steps
            for offset in (-width*.255,width*.255):
                tire.box((x+radius*math.sin(a),y+offset,z+radius*math.cos(a)),
                         (.17 if i<2 else .40,width*.47,.07 if i<2 else .16),4,roll=-a)
        for side in (-1,1):
            for k in range(5):
                a=k*math.tau/5
                tire.box((x+.62*math.sin(a),y+side*(width/2+.09),z+.62*math.cos(a)),
                         (.18,.1,1.0),6,roll=-a)
        for k in range(6):
            a=k*math.tau/6
            tire.cylinder((x+.72*math.cos(a),y+(-1 if y<0 else 1)*(width/2+.10),z+.72*math.sin(a)),.10,.08,'y',6,6)
        meshes.append(tire)
    for m in meshes:
        m.vertices=[tuple(v*SCALE for v in p) for p in m.vertices]
    return meshes


def texture():
    colors=[(40,43,47),(49,52,56),(34,37,42),(17,30,42),(22,24,26),(97,101,104),(116,99,69),(8,10,12),(40,43,47),(40,43,47),(170,170,170),(210,219,225),(44,47,51),(40,43,47),(40,43,47),(40,43,47)]
    pixels=bytearray()
    for y in range(512):
        for x in range(512):
            tile=(y//128)*4+x//128; u,v=x%128,y%128
            noise=((x*73+y*151)%11-5)*.42
            edge=9 if min(u,v,127-u,127-v)<3 else 0
            scratch=9 if (u*7+v*23)%997==0 else 0
            rgb=[max(0,min(255,int(c+noise-edge+scratch))) for c in colors[tile]]
            if tile in (0,1,2,12) and (u in (7,120) or v in (7,120)): rgb=[max(0,c-12) for c in rgb]
            pixels.extend(reversed(rgb))
    return struct.pack('<BBBHHBHHHHBB',0,0,2,0,0,0,0,0,512,512,24,0)+pixels


def main():
    OUTPUT.mkdir(parents=True,exist_ok=True)
    meshes=vehicle(); tex=texture()
    (OUTPUT/TEXTURE).write_bytes(tex)
    (OUTPUT/'uwtumbler.w3d').write_bytes(w3d(meshes,model_name=NAME,texture_name=TEXTURE,bones=BONES,origins=ORIGINS))
    (OUTPUT/'uwtbcameo.tga').write_bytes(cameo_tga(meshes,tex))
    lines=['# Original authored fan model; CC0-1.0','mtllib uwtumbler.mtl'];offset=1
    for m in meshes:
        lines+=['o '+m.name,'usemtl TUMBLER']
        lines+=['v %.6f %.6f %.6f'%p for p in m.vertices]
        lines+=['vt %.6f %.6f'%p for p in m.uvs]
        lines+=['vn %.6f %.6f %.6f'%p for p in m.normals]
        lines+=['f '+' '.join(f'{i+offset}/{i+offset}/{i+offset}' for i in f) for f in m.triangles]
        offset+=len(m.vertices)
    (OUTPUT/'uwtumbler.obj').write_text('\n'.join(lines)+'\n')
    (OUTPUT/'uwtumbler.mtl').write_text('newmtl TUMBLER\nKd 1 1 1\nmap_Kd uwtumbler.tga\n')
    verts=[v for m in meshes for v in m.vertices]
    data={'model':NAME,'asset_license':'CC0-1.0','front':'+X','up':'+Z','texture':TEXTURE,
          'triangles':sum(len(m.triangles) for m in meshes),'vertices':len(verts),'rigid_meshes':len(meshes),
          'bounds':{'min':[min(v[i] for v in verts) for i in range(3)],'max':[max(v[i] for v in verts) for i in range(3)]},
          'bones':[{'name':n,'parent':p,'translation':t} for n,p,t in BONES],
          'meshes':[{'name':m.name,'bone':m.bone,'origin':ORIGINS[m.bone],'vertices':m.vertices,'normals':m.normals,'uvs':m.uvs,'triangles':m.triangles,'vertex_count':len(m.vertices),'triangle_count':len(m.triangles)} for m in meshes]}
    (OUTPUT/'uwtumbler.mesh.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
    print(json.dumps({k:data[k] for k in ('model','triangles','vertices','bounds')}))

if __name__=='__main__': main()
